# Module audit — v0.7.4

- Combat: Aim Assist (head/chest/body target point and weapons-only option), Auto Weapon, Aura, Trigger Bot, Criticals, Reach, Velocity/Anti-KB, Auto Armor, Auto GApple, Auto Potion, Pot Refill, Auto Soup and Auto Totem.
- Visuals/HUD: Target HUD, Potion Effects, FPS, Coordinates, Keystrokes, Armor, Active Modules and existing visual modules.
- `Back Track`, `Timer`, `Auto Brew`, `Blink` and `Free Camera` remain explicitly unavailable placeholders and are not presented as implemented.
- Auto Weapon is a client-side hotbar selector; server-side combat rules still apply.
- Static validation is not a substitute for a successful Gradle build or in-game testing.


## v0.7.6 additions
- `weapon_hud`, `weapon_durability_hud`, `attack_cooldown_hud`: implemented in `UtilityModules.renderHud`.
- These are informational HUDs, not combat automation. Compile/in-game verification remains pending.
