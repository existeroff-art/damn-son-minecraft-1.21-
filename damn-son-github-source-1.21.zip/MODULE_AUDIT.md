# Module validation and reference-video scope

This project contains a catalog of combat, movement, visual, player and HUD modules. The reference URLs supplied in chat are used as feature inspiration, not as proof that every frame or every hidden setting was inspected; public page metadata does not expose a reliable frame-by-frame transcript for every linked video.

## What CI now checks before compiling

- JSON descriptors parse correctly.
- Module IDs in `ModuleCatalog` are unique.
- Core modules (Aim Assist, Auto Potion, Pot Refill, Trigger Bot, Auto Armor, Auto Totem and HUD modules) remain present.
- Java source delimiters are balanced (a lightweight sanity check only).
- Gradle compilation runs afterward in GitHub Actions against the configured Java/Fabric toolchain.

## Verification boundary

A catalog entry is not proof of complete runtime behavior. Static validation does not verify Minecraft mappings, mixin injection success, server compatibility, combat timing, or inventory behavior. Those require a successful CI build and in-game testing. Review `TEST_REPORT.md` and the Actions build log before installing the resulting JAR.
