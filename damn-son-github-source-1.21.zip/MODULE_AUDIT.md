# Module audit — v0.7.4

- Combat: Aim Assist (head/chest/body target point and weapons-only option), Auto Weapon, Aura, Trigger Bot, Criticals, Reach, Velocity/Anti-KB, Auto Armor, Auto GApple, Auto Potion, Pot Refill, Auto Soup and Auto Totem.
- Visuals/HUD: Target HUD, Potion Effects, FPS, Coordinates, Keystrokes, Armor, Active Modules and existing visual modules.
- `Back Track`, `Timer`, `Auto Brew`, `Blink` and `Free Camera` remain explicitly unavailable placeholders and are not presented as implemented.
- Auto Weapon is a client-side hotbar selector; server-side combat rules still apply.
- Static validation is not a substitute for a successful Gradle build or in-game testing.


## v0.7.6 additions
- `weapon_hud`, `weapon_durability_hud`, `attack_cooldown_hud`: implemented in `UtilityModules.renderHud`.
- These are informational HUDs, not combat automation. Compile/in-game verification remains pending.

## v0.7.7 PvP profile additions
- `crystal_pvp`: context-aware hotbar selection (End Crystal on a valid placement base; sword on entity targets/crystals); manual placement/attack only.
- `mace_pvp`: mace selection for falling hits; sword fallback for grounded targets.
- `sword_pvp`: prefers Netherite sword then any sword on a crosshair target.
- `netherite_pot_pvp`: healing splash potion selection at low health and Netherite sword preference while targeting.
- Existing keybind assignment and toggle sounds are used for the new profile modules.
- No full Gradle build or in-game run is claimed unless separately confirmed.
- `quick_crystal_macro`, `quick_mace_macro`, `quick_pot_macro`: one-press hotbar item-selection macros; they auto-reset OFF and show feedback. No automated attack/item use is performed by these macros.
