# Module audit — v0.7.9

The catalogue and configuration whitelist expose exactly six modules: `aim_bot`, `trigger_bot`, `fast_gapple`, `snap_tap`, `auto_potion`, and `potion_refill`.

`UtilityModules.tick` only updates Aim Assist target acquisition, Trigger Bot, Auto Pot, and Auto Pot Refill. Snap Tap remains in `KeyboardInputSnapTapMixin`; Fast Gap remains in its client/server item-use mixins. Retired mixins are removed from `damnson.mixins.json` and their source files are deleted.

Static validation passes. Gradle compilation and in-game behavior remain unverified in this environment.
