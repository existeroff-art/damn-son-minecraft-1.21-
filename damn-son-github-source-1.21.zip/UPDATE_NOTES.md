# Damn Son 1.21 — v0.7.5 Aim/UI patch

## Changes
- Aim Assist strength curve is more responsive at high settings; at 98–100 it applies the wrapped yaw/pitch correction immediately.
- Replaced the ambiguous numeric Aim Point slider with explicit HEAD / CHEST / BODY segmented buttons. Clicking a segment writes the selected integer to config and saves immediately.
- Removed Aim Point from the generic slider list so it cannot be handled by the slider-drag code.
- Existing module catalog and settings are otherwise preserved.

## Validation
- ZIP integrity checked after packaging.
- Source-level checks verify the selector render/click paths and the aim response change are present.
- Full Gradle compilation and in-game camera behavior were not verified in this environment.

## v0.7.6 weapon-focused additions
- Added Weapon HUD, Weapon Durability HUD, and Attack Cooldown HUD as working informational combat modules.
- HUDs use the held main-hand stack and vanilla attack cooldown; they do not send extra packets or modify attacks.
- Existing Auto Weapon remains the only automatic weapon-selection module in this release.
- YouTube videos could not be verified frame-by-frame in this environment; additions are based on common PvP weapon-information needs rather than claims of exact video replication.
- Build status: source-level/static checks only; run the repository Gradle workflow to confirm mappings and compilation.
