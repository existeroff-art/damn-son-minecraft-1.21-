# Damn Son 1.21 — v0.7.9

## Requested module cleanup

Only these modules are exposed in the GUI and accepted by the settings system:

- Aim Assist
- Trigger Bot
- Fast Gap
- Snap Tap
- Auto Pot
- Auto Pot Refill

Retired combat presets/macros, HUD modules, velocity/no-slow/no-web/fog/other features were removed from the active module catalogue, runtime tick loop, or mixin set. Existing user config entries for retired modules are pruned on load/save.

## UI and performance changes

- Added an independently scrollable Aim Assist/settings body, with a draggable scrollbar and fixed footer.
- Aim Point and Weapons Only hit-testing use the same scrolled coordinates as rendering, so lower controls remain accessible after scrolling.
- Menu open/close, toggle, and slider interaction feedback sounds use distinct pitch/volume cues.
- Slider values are persisted on mouse release rather than writing the config file on every drag frame.
- Aim interpolation uses elapsed render-frame time and the interpolated camera position instead of a fixed 20 Hz correction step.
- Aim candidate selection avoids building and sorting a temporary candidate list.
- Potion refill no longer calls `ItemStack.copy()` on nine hotbar stacks every client tick.

## Validation limits

`python scripts/validate_source.py` performs source/JSON sanity checks only. Gradle is not installed in the working environment and the project has not been compiled or tested in Minecraft in this run. The third gameplay clip mentioned by the user was not attached in this turn, so its exact settings were not copied from that clip.
