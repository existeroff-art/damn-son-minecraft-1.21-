# Damn Son 1.21 source update — v0.7.3

## Fixes included

- Aim Assist steering now runs in the HUD render callback (per rendered frame) instead of being applied only at the 20-TPS client tick. The response uses elapsed time so its behavior is less dependent on FPS.
- Aim point uses interpolated entity position instead of a large velocity lead that jumped when server velocity corrections arrived.
- Candidate reacquisition is throttled while there is no target, avoiding repeated full entity filtering/sorting every game tick.
- Auto Potion now stages the hotbar slot and downward pitch for one tick, then sends the item-use action on the following tick, so the reported player look/slot have time to sync before use. Pitch and selected slot are restored afterward.
- Temporary inventory potion swaps are restored only while the player inventory screen handler is active, avoiding accidentally targeting chest/container slots after a screen change.
- Added Target HUD and Potion Effects HUD.
- The GUI labels Back Track, Timer, Auto Brew, Blink and Free Camera as unavailable because they remain unimplemented in this revision. They cannot be toggled or keybound; no fake “working” switches.
- GitHub Actions locates the Gradle root automatically, whether the repository has Gradle files at its root or inside a nested `project/` directory. It reports a useful layout error when the ZIP itself was uploaded rather than its contents.

## Verification limits

- Python source validator, JSON parsing, uniqueness checks and Java delimiter checks are included.
- No Gradle executable or cached Fabric dependency set exists in this execution environment, and the Gradle distribution host is not reachable here. Therefore a full Gradle compile and in-game behavior test are not claimed. Run GitHub Actions and inspect the build log before installing the artifact.
- No anti-cheat detection evasion or packet-spoofing features were added.
