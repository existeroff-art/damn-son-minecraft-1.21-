# Damn Son 1.21 — source update notes (v0.7.0)

## Included changes

- Rebuilt the module menu as compact, centered panels with the pink accent used in the supplied reference. Panel height is capped rather than scaling to the whole window.
- Added per-category wheel scrolling and draggable scroll thumbs so longer categories remain accessible.
- Added a settings panel opened with right-click on a module. Settings include module toggling, keybind assignment, and sliders for Aim Assist, Trigger Bot delay/range, Aura range, Reach, Speed, Velocity, and Anti-KB.
- Aim Assist uses continuous eased rotation, configurable range/FOV/smoothing, bounded per-tick rotation steps, and target revalidation when the target leaves range/FOV or despawns.
- Trigger Bot now has a persisted 0–10 tick delay setting (default 2 ticks) and uses vanilla attack cooldown for repeated swings instead of layering on the previous extra-long interval.
- Fixed Aura Criticals timing so it waits for downward motion before the attack attempt.
- Added player-instance reset handling so stateful toggles such as Speed and Reach can apply again after a respawn/world swap.
- Added implementations for Auto Armor (fills empty armor slots), low-health Splash Potion and Mushroom Stew use, Auto Totem, mature-crop harvesting, client-side vertical Flight controls, Spider wall-climb assist, Elytra lateral steering, Wind Hop, hit particles, nearby-player arrows, No Web, No Slow, and extended atmospheric fog.
- Updated the GitHub Actions workflow label and fixed escaped `find` parentheses in the workflow shell commands.

## Important functionality limits

This is a **source update**, not a verified compiled JAR. The current execution environment does not have Gradle installed, has no Gradle dependency cache, and cannot resolve the Gradle distribution host, so I could not complete `gradle clean build` or launch Minecraft to smoke-test the mixins. Push this ZIP to GitHub and inspect the `Build Damn Son Fabric Mod v0.7.0` Actions run before using the generated JAR.

The catalog still includes several features that need larger dedicated implementations before they should be considered functional: **Back Track, Timer, Auto Brew, Blink, and Free Camera**. They are listed in the UI but are not implemented in this update. Fast Gapple additionally requires the documented companion server-side mod to be installed. Flight, Spider, Speed, Reach, No Slow, and other movement/combat changes may be overridden or rejected by a server, and are not a guarantee of multiplayer compatibility.

## Controls

- Open/close menu: Right Shift (Escape also closes it).
- Left-click a module: toggle it.
- Right-click a module: open its settings.
- Mouse wheel while hovering a category: scroll that category.
- Drag the pink scrollbar thumb: scroll precisely.
- In settings: click `TOGGLE` to switch the module, click `KEY` to assign a key, drag sliders to change supported values, and click `CLOSE PANEL` to return.

Target: Minecraft 1.21, Fabric, Java 21.
