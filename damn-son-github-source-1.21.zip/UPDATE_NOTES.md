# Damn Son 1.21 — v0.7.5 Aim/UI patch

## Changes
- Aim Assist strength curve is more responsive at high settings; at 98–100 it applies the wrapped yaw/pitch correction immediately.
- Replaced the ambiguous numeric Aim Point slider with explicit HEAD / CHEST / BODY segmented buttons. Clicking a segment writes the selected integer to config and saves immediately.
- Removed Aim Point from the generic slider list so it cannot be handled by the slider-drag code.
- Existing module catalog and settings are otherwise preserved.

## Validation
- ZIP integrity checked after packaging.
- Source-level checks verify the selector render/click paths and the aim response change are present.
- Full Gradle compilation and in-game camera behavior were not verified in this environment.

## v0.7.6 weapon-focused additions
- Added Weapon HUD, Weapon Durability HUD, and Attack Cooldown HUD as working informational combat modules.
- HUDs use the held main-hand stack and vanilla attack cooldown; they do not send extra packets or modify attacks.
- Existing Auto Weapon remains the only automatic weapon-selection module in this release.
- YouTube videos could not be verified frame-by-frame in this environment; additions are based on common PvP weapon-information needs rather than claims of exact video replication.
- Build status: source-level/static checks only; run the repository Gradle workflow to confirm mappings and compilation.

## v0.7.7 — PvP profile helpers and UI viewport merge
- Added Crystal PvP profile: selects End Crystals when the crosshair is over a valid obsidian/bedrock base with two air blocks above; selects a sword when aiming at a player or End Crystal.
- Added Mace PvP profile: selects a mace for an airborne falling hit and prefers a sword for grounded target combat.
- Added Sword PvP profile: prefers a Netherite sword, falling back to another sword, while aiming at a living target or End Crystal.
- Added Netherite Pot PvP profile: selects a hotbar healing splash potion at 14 health points or below and otherwise prefers a Netherite sword when a target is under the crosshair.
- Profiles are hotbar-selection helpers. They do not place crystals, throw potions automatically, or attack. `Auto Potion`, Aim Assist, Trigger Bot and other existing modules remain separate toggles.
- Profiles run in priority order if several are enabled simultaneously: Crystal PvP, Mace PvP, Sword PvP, Netherite Pot PvP. Enable one profile at a time for predictable behavior.
- Merged the settings-panel viewport/footer hit-testing fix without nesting the Gradle project in an extra folder.
- Module keybinds and UI toggle sounds remain configurable/active.
- Validation is static unless the CI workflow successfully runs a Gradle build; this environment has not confirmed an in-game launch.
- Added one-press hotbar macros: Quick Crystal (Crystal/Obsidian swap), Quick Mace (Mace/sword swap), and Quick Pot (healing/regen splash potion/sword swap). They reset to OFF after firing and show an action-bar status. They do not auto-place, throw, or attack.
