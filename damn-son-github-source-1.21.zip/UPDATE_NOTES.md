# Damn Son 1.21 source update — v0.7.4

## Combat-focused changes

- Aim rotation no longer mutates player yaw/pitch from `HudRenderCallback`, which runs after the world frame is rendered. Steering is applied once in the client tick path so the normal camera interpolation can render the transition.
- Added Aim Assist target-point selection: HEAD (default), CHEST, or BODY.
- Added an Aim Assist `WEAPONS ONLY` toggle, enabled by default. Supported held items: swords, axes, bows, crossbows, tridents, and the mace.
- Added `Auto Weapon`: while a living target is under the crosshair at close range, it prefers mace during a real fall, axe against a blocking target, then sword; it falls back to available melee options. It restores the prior slot when the target is lost, the menu opens, or the module is disabled, provided the player has not manually selected a different slot.
- Added Aim Assist settings persistence for target point and weapon-only mode; config schema is now v17.

## Build workflow

- Bumped Gradle project/workflow artifact version to v0.7.4.
- Updated static validator checks for the tick-based aim implementation and Auto Weapon.
- Project-root discovery continues to support root or nested `project/` builds.

## Verification limits

- The uploaded portrait gameplay recording was inspected for its combat context. YouTube prevented automated playback/metadata retrieval for the linked showcase URLs, so no claim is made that every linked video was watched end-to-end.
- Static validation and ZIP integrity are checked during packaging.
- Full Gradle compilation and live Minecraft testing are not available in this environment. Run GitHub Actions and check the actual build log before installing the artifact.
- No anti-cheat evasion or packet-spoofing was added.
