#!/usr/bin/env python3
"""Dependency-free sanity checks for the Damn Son Fabric client source tree."""
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
errors = []
for path in root.rglob('*.json'):
    try:
        json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{path.relative_to(root)}: invalid JSON: {exc}')

catalog_path = root / 'src/main/java/com/damnson/client/ModuleCatalog.java'
catalog = catalog_path.read_text(encoding='utf-8')
module_ids = re.findall(r'new Module\("([a-z0-9_]+)"', catalog)
expected = {'aim_bot', 'trigger_bot', 'fast_gapple', 'snap_tap', 'auto_potion', 'potion_refill'}
if len(module_ids) != len(set(module_ids)):
    errors.append('duplicate module IDs in ModuleCatalog')
if set(module_ids) != expected:
    errors.append(f'catalog IDs are not exact: got {sorted(set(module_ids))}')

settings = (root / 'src/main/java/com/damnson/client/ModuleSettings.java').read_text(encoding='utf-8')
for module in expected:
    if f'"{module}"' not in settings:
        errors.append(f'ModuleSettings missing allowed ID {module}')

utility = (root / 'src/main/java/com/damnson/client/UtilityModules.java').read_text(encoding='utf-8')
for symbol in ('updateAimBotTarget(', 'onRenderFrame(', 'tickTriggerBot(', 'tickAutoPotion(', 'tickPotionRefill('):
    if symbol not in utility:
        errors.append(f'UtilityModules missing {symbol}')
for stale in ('tickQuickHotbarMacros(', 'tickPvpLoadoutProfile(', 'tickAura(', 'tickAutoTotem(', 'tickAutoFarm(', 'renderHud('):
    if stale in utility:
        errors.append(f'retired module code still referenced: {stale}')
utility_code = re.sub(r'/\*.*?\*/|//[^\n]*', '', utility, flags=re.S)
if 'previousHotbarPotionStacks' in utility_code or re.search(r'\.copy\s*\(', utility_code):
    errors.append('per-tick ItemStack-copy tracker remains in UtilityModules')

mixins_path = root / 'src/main/resources/damnson.mixins.json'
mixins = json.loads(mixins_path.read_text(encoding='utf-8'))
allowed_client_mixins = {'AimAssistRenderMixin', 'KeyboardInputSnapTapMixin', 'FastGappleClientItemMixin'}
if set(mixins.get('client', [])) != allowed_client_mixins:
    errors.append('client mixin list contains missing or retired mixins')
if mixins.get('mixins') != ['FastGappleItemMixin']:
    errors.append('common mixin list contains unexpected mixins')
for name in ('ClientPlayNetworkHandlerMixin.java', 'CustomFogMixin.java', 'NoWebMixin.java', 'PracticeWorldGuard.java'):
    if any(root.rglob(name)):
        errors.append(f'retired source file still exists: {name}')

# Basic delimiter sanity. This intentionally does not claim Java compilation.
for path in root.rglob('*.java'):
    source = path.read_text(encoding='utf-8')
    scrub = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '', source, flags=re.S)
    for left, right in [('{', '}'), ('(', ')'), ('[', ']')]:
        depth = 0
        for char in scrub:
            if char == left:
                depth += 1
            elif char == right:
                depth -= 1
                if depth < 0:
                    errors.append(f'{path.relative_to(root)}: unmatched {right}')
                    break
        if depth > 0:
            errors.append(f'{path.relative_to(root)}: unmatched {left}')

if errors:
    print('\n'.join('ERROR: ' + item for item in errors))
    sys.exit(1)
print(f'PASS: exactly {len(expected)} requested modules; JSON valid; active runtime and mixin lists trimmed; Java delimiters balanced.')
print('NOTE: Static validation only; not a Gradle compile or in-game test.')
