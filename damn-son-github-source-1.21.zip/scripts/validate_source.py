#!/usr/bin/env python3
"""Dependency-free source sanity checks for the Damn Son Fabric client."""
import json, re, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
errors=[]
for p in root.rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{p.relative_to(root)}: invalid JSON: {e}')
cat = root/'src/main/java/com/damnson/client/ModuleCatalog.java'
text = cat.read_text(encoding='utf-8')
ids = re.findall(r'new Module\("([a-z0-9_]+)"', text)
seen=set()
for mid in ids:
    if mid in seen: errors.append(f'duplicate module id: {mid}')
    seen.add(mid)
required={'aim_bot','auto_weapon','auto_potion','potion_refill','trigger_bot','auto_armor','auto_totem','fps_hud','coordinates_hud','target_hud','potion_effects_hud'}
missing=required-seen
if missing: errors.append('required modules missing from catalog: '+', '.join(sorted(missing)))
utility = root/'src/main/java/com/damnson/client/UtilityModules.java'
utext = utility.read_text(encoding='utf-8')
for phrase in ('tickAimAssist(client, cfg)', 'aimBotTargetPoint', 'aimBotWeaponsOnly',
               'tickAutoWeapon(client, cfg)', 'pendingPotionUseTick = now + 1L',
               'finishPendingAutoPotion(client, cfg)', 'getLerpedPos', 'potion_effects_hud', 'target_hud'):
    if phrase not in utext: errors.append('required implementation hook missing: '+phrase)
workflow = root/'.github/workflows/build.yml'
if not workflow.exists(): errors.append('GitHub Actions build workflow is missing')
if not (root/'build.gradle').exists() or not (root/'settings.gradle').exists():
    errors.append('Gradle settings/build files must be in the source ZIP root')
for p in (root/'src/main/java').rglob('*.java'):
    s=p.read_text(encoding='utf-8')
    # Lightweight delimiter sanity check; ignores comments and literals only approximately.
    scrub=re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '', s, flags=re.S)
    for left,right in [('{','}'),('(',')'),('[',']')]:
        depth=0
        for c in scrub:
            if c==left: depth+=1
            elif c==right:
                depth-=1
                if depth<0: errors.append(f'{p.relative_to(root)}: unmatched {right}'); break
        if depth>0: errors.append(f'{p.relative_to(root)}: unmatched {left}')
if errors:
    print('\n'.join('ERROR: '+e for e in errors)); sys.exit(1)
print(f'PASS: {len(ids)} unique catalog module IDs; JSON descriptors valid; Java delimiter sanity passed.')
print('NOTE: This is static validation only, not a Gradle compile or in-game test.')
