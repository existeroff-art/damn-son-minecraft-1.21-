# Crash fix report — v0.6.6 source update

## Reported fatal error
`InvalidMixinException: @Shadow field field_3907 was not located in the target class net.minecraft.class_743` while applying `KeyboardInputSnapTapMixin`.

## Change
- Removed `@Shadow` declarations for movement/key-state fields from `KeyboardInputSnapTapMixin`.
- Accessed those inherited public fields through `net.minecraft.client.input.Input`, which owns them in Minecraft 1.21.
- Kept the mixin target and `tick(boolean, float)` injection so the Snap Tap logic still runs at the end of the keyboard input tick.

## Validation status
- `damnson.mixins.json` is valid JSON and still references an existing mixin class.
- The invalid `@Shadow` declarations are gone.
- ZIP integrity and source-level checks pass.
- Gradle is unavailable in the authoring environment; compilation and in-game verification are not claimed.

## Separate log errors
The provided log also contains unrelated MoreCulling `RestrictiveMixinConfigPlugin` and JNA native-library errors. If those remain after the Snap Tap fix, they need separate troubleshooting.
