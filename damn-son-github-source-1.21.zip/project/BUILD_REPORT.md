# Build and source review

## Changes in this update

- Simplified the settings screen to controls that correspond to implemented settings.
- Removed misleading UI-only toggles such as “Smart Bypass”, “Focus Mode”, and target selection.
- Added the implemented “TB Critical Only” setting to the menu.
- Fixed slider value handling so slider positions are converted from normalized values to the selected setting range correctly.
- Kept the Right Shift keybinding and GLFW edge-detection fallback.
- Kept combat helpers restricted to single-player hostile mobs.

## Multiplayer behavior

The code checks `client.isInSingleplayer()` before running combat helpers. It does not target player entities or run the helpers on multiplayer servers.

## Build status

No successful Gradle build or in-game launch is claimed. Build with JDK 21 and Gradle 8.10.2 using:

```sh
gradle --no-daemon clean build
```

The GitHub Actions workflow is included for remote build verification. Review the complete Actions log if compilation fails.


## Follow-up source cleanup (2026-10-18)

- Removed unused settings fields that implied player targeting, humanization, focus mode, smart bypass, or an unused aim bind.
- Updated the menu subtitle to explicitly state single-player-only hostile-mob targeting.
- Build remains unverified in this environment because Gradle is not installed; use the included GitHub Actions workflow to compile with Java 21.


## Player-target option update

- Added a `Target Players` toggle to the menu and persisted it in `damn-son.json`.
- AA can select other living player entities when enabled; TB can attack the player entity under the crosshair when enabled.
- Removed the single-player-only early return. This build has not been compiled or tested in-game; server-side validation and server rules still apply.
