# Build and source review

## Current source update

- Reworked `DamnSonScreen` with an animated Vegeta background, dark veil, moving scan beam, cyan/purple framing, separate module cards, active module indicators, and the L portrait.
- Added `assets/damnson/icon.png` and the `icon` property in `fabric.mod.json` so the L portrait is also used as the Fabric mod-list icon.
- Kept Right Shift for the menu and configurable AA/TB toggle hotkeys.
- Disabled weapon-only requirements by default and added a config migration for older config files that could silently block both modules when the player was not holding a sword or axe.
- Refined Aim Assist eased rotation and target-lock preference.
- Updated Trigger Bot to check its configured delay and Minecraft's vanilla attack cooldown.
- Synced the root project with the `project/` copy used by GitHub Actions.

## Verification

The ZIP archive and JSON resources can be checked locally, but this environment does not have Gradle and cannot resolve `services.gradle.org`. A successful Gradle build or in-game test is **not** claimed. Run the included GitHub Actions workflow and review the job log before installing the built JAR.
