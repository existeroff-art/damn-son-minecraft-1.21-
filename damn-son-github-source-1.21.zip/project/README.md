# Damn Son — Fabric client mod (Minecraft Java 1.21, Java 21)

A client-side Fabric mod with a dark AA/TB settings screen. Press **Right Shift** to open or close the menu.

## Included

- **AA (Aim Assist):** configurable range, speed, maximum rotation step, field of view, aim point, and weapon-only option. It smoothly rotates toward hostile mobs in single-player.
- **TB (Trigger Bot):** attacks the targeted hostile mob in single-player, with configurable range and delay, weapon-only option, and critical-hit-only option.
- Settings persist to `.minecraft/config/damn-son.json`.
- Modules are disabled by default.

## Scope

The combat helpers are restricted to **single-player worlds** and hostile mobs. They stop immediately outside single-player and do not target real players on multiplayer servers. The video is a reference for the menu and visible settings; unreadable values have not been guessed as exact copies.

## Build on GitHub

1. Upload the project files to a GitHub repository.
2. Keep `.github/workflows/build.yml`.
3. Open **Actions** and run **Build Damn Son Fabric Mod**, or push to `main`/`master`.
4. Download the `damn-son-minecraft-1.21` artifact from a successful workflow run.

## Local build

Requires JDK 21 and Gradle 8.10.2. From the project root:

```sh
gradle --no-daemon clean build
```

The installable JAR should appear in `build/libs/` (exclude `*-sources.jar` and `*-dev.jar`). Install it with Fabric Loader for Minecraft **1.21 exactly** and a compatible Fabric API.

## Verification status

The source archive is updated, but it has not been compiled or launched in Minecraft in this environment. Unused configuration fields that implied unimplemented player-targeting/humanization features were removed so the config matches implemented controls. Treat the JAR as unverified until GitHub Actions succeeds and the menu/modules are tested in-game.


## UI and module hotkeys
- Press Right Shift to open/close the settings UI.
- The UI includes the bundled L logo and cyan/purple animated accents.
- Click **AA Key** or **TB Key**, then press a key to assign a toggle hotkey (Escape cancels). Defaults: R for Aim Assist and V for Trigger Bot.
- Hotkeys and settings are saved to `config/damn-son.json`.
- Combat helpers remain restricted to single-player practice targets; this project does not enable automated targeting/attacks against multiplayer players.
