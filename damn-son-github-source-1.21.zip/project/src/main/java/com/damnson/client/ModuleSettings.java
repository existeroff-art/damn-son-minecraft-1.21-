package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** User-configurable client module settings. */
public final class ModuleSettings {
    public int configVersion = 3;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public boolean aimAssistEnabled = false;
    public int aimToggleKey = 82; // R by default
    public double aimRange = 4.5;
    public double aimSpeed = 13.0;
    public double aimMaxSpeed = 22.0;
    public double aimFov = 360.0;
    /** Kept only to read older config files. The practice module no longer requires a weapon. */
    public boolean onlyWeapon = false;
    public boolean targetPlayers = true;
    public String aimPoint = "HEAD";

    public boolean triggerBotEnabled = false;
    public int triggerToggleKey = 86; // V by default

    public boolean shieldBreakerEnabled = false;
    public int shieldBreakerToggleKey = 66; // B by default
    public double shieldRange = 3.0;

    public static ModuleSettings get() {
        return INSTANCE;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                int storedVersion = json.has("configVersion") ? json.get("configVersion").getAsInt() : 0;
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded != null) {
                    if (storedVersion < 2) {
                        loaded.onlyWeapon = false;
                    }
                    if (loaded.aimToggleKey <= 0) loaded.aimToggleKey = 82;
                    if (loaded.triggerToggleKey <= 0) loaded.triggerToggleKey = 86;
                    if (loaded.shieldBreakerToggleKey <= 0) loaded.shieldBreakerToggleKey = 66;
                    loaded.shieldRange = clamp(loaded.shieldRange, 1.0, 3.0);
                    loaded.aimRange = clamp(loaded.aimRange, 1.0, 6.0);
                    loaded.aimSpeed = clamp(loaded.aimSpeed, 1.0, 20.0);
                    loaded.aimMaxSpeed = clamp(loaded.aimMaxSpeed, 1.0, 30.0);
                    loaded.aimFov = clamp(loaded.aimFov, 30.0, 360.0);
                    if (!"HEAD".equals(loaded.aimPoint) && !"CHEST".equals(loaded.aimPoint)
                            && !"LEGS".equals(loaded.aimPoint)) {
                        loaded.aimPoint = "HEAD";
                    }
                    loaded.onlyWeapon = false; // Prevent a stale legacy setting from silently blocking practice.
                    loaded.configVersion = 3;
                    if (storedVersion < 3) loaded.save();
                    return loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
