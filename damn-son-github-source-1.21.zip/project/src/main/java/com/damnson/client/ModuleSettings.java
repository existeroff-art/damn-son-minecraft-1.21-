package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** User-configurable client module settings. */
public final class ModuleSettings {
    public int configVersion = 2;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public boolean aimAssistEnabled = false;
    public int aimToggleKey = 82; // R
    public int triggerToggleKey = 86; // V
    public double aimRange = 6.0;
    public double aimSpeed = 8.0;
    public double aimMaxSpeed = 10.0;
    public double aimFov = 360.0;
    public boolean onlyWeapon = false;
    public boolean targetPlayers = true; // player entities can be selected when enabled
    public String aimPoint = "HEAD";

    public boolean triggerBotEnabled = false;
    public double triggerRange = 4.0;
    public int triggerDelayMs = 120;
    public boolean triggerOnlyWeapon = false;
    public boolean triggerCriticalOnly = false;

    public static ModuleSettings get() { return INSTANCE; }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                boolean legacyConfig = !json.has("configVersion")
                        || json.get("configVersion").getAsInt() < 2;
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded != null) {
                    // Migrate older config files whose default weapon filters silently blocked testing.
                    if (legacyConfig) {
                        loaded.configVersion = 2;
                        loaded.onlyWeapon = false;
                        loaded.triggerOnlyWeapon = false;
                        loaded.save();
                    }
                    return loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }
}
