package com.damnson.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class DamnSonClient implements ClientModInitializer {
    private static KeyBinding openMenu;
    private static boolean rightShiftWasDown;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.damnson.open_menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.damnson"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean openRequested = false;
            while (openMenu.wasPressed()) openRequested = true;

            // Fallback for launchers/keyboards that deliver GLFW key state but do not
            // correctly enqueue the registered key binding press.
            boolean rightShiftDown = client.getWindow() != null
                    && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (rightShiftDown && !rightShiftWasDown) openRequested = true;
            rightShiftWasDown = rightShiftDown;

            if (openRequested) {
                if (client.currentScreen instanceof DamnSonScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new DamnSonScreen());
            }
            CombatModules.tick(client);
        });
        System.out.println("[Damn Son] Client initialized. Menu key: Right Shift.");
    }
}
