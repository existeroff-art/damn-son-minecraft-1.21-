package com.damnson.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class DamnSonClient implements ClientModInitializer {
    private static KeyBinding openMenu;
    private static boolean rightShiftWasDown;
    private static boolean aimWasDown;
    private static boolean triggerWasDown;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.damnson.open_menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.damnson"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean openRequested = false;
            while (openMenu.wasPressed()) openRequested = true;

            // Fallback for launchers/keyboards that deliver GLFW key state but do not
            // correctly enqueue the registered key binding press.
            boolean rightShiftDown = client.getWindow() != null
                    && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (rightShiftDown && !rightShiftWasDown) openRequested = true;
            rightShiftWasDown = rightShiftDown;

            if (openRequested) {
                if (client.currentScreen instanceof DamnSonScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new DamnSonScreen());
            }
            if (client.getWindow() != null) {
                ModuleSettings cfg = ModuleSettings.get();
                long handle = client.getWindow().getHandle();
                boolean aimDown = cfg.aimToggleKey > 0 && GLFW.glfwGetKey(handle, cfg.aimToggleKey) == GLFW.GLFW_PRESS;
                boolean triggerDown = cfg.triggerToggleKey > 0 && GLFW.glfwGetKey(handle, cfg.triggerToggleKey) == GLFW.GLFW_PRESS;
                if (aimDown && !aimWasDown) {
                    cfg.aimAssistEnabled = !cfg.aimAssistEnabled;
                    cfg.save();
                    playToggleSound(client, cfg.aimAssistEnabled);
                }
                if (triggerDown && !triggerWasDown) {
                    cfg.triggerBotEnabled = !cfg.triggerBotEnabled;
                    cfg.save();
                    playToggleSound(client, cfg.triggerBotEnabled);
                }
                aimWasDown = aimDown;
                triggerWasDown = triggerDown;
            }
            CombatModules.tick(client);
        });
        System.out.println("[Damn Son] Client initialized. Menu key: Right Shift.");
    }

    private static void playToggleSound(net.minecraft.client.MinecraftClient client, boolean enabled) {
        if (client.player != null) {
            client.player.playSound(net.minecraft.sound.SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),
                    0.38F, enabled ? 1.55F : 0.82F);
        }
    }
}
