package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Client-side combat helpers. Player targeting is controlled by the explicit setting.
 */
public final class CombatModules {
    private static long lastTriggerAt;

    private CombatModules() {}

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null
                || client.interactionManager == null) return;

        ModuleSettings cfg = ModuleSettings.get();
        PlayerEntity player = client.player;
        if (cfg.aimAssistEnabled) runAimAssist(client, cfg, player);
        if (cfg.triggerBotEnabled) runTriggerBot(client, cfg, player);
    }

    private static void runAimAssist(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (cfg.onlyWeapon && !hasWeapon(player.getMainHandStack())) return;

        double range = Math.max(1.0, Math.min(12.0, cfg.aimRange));
        double fov = Math.max(1.0, Math.min(180.0, cfg.aimFov));
        LivingEntity target = null;
        double bestAngle = Double.MAX_VALUE;

        for (LivingEntity candidate : client.world.getEntitiesByClass(LivingEntity.class,
                player.getBoundingBox().expand(range),
                e -> e.isAlive() && e != player
                        && (e instanceof HostileEntity || (cfg.targetPlayers && e instanceof PlayerEntity)))) {
            Vec3d aimAt = aimPosition(candidate, cfg.aimPoint);
            double dx = aimAt.x - player.getX();
            double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
            double dz = aimAt.z - player.getZ();
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distance < 0.001 || distance > range) continue;

            double wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
            double wantedPitch = MathHelper.wrapDegrees((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
            double yawDelta = MathHelper.wrapDegrees((float) (wantedYaw - player.getYaw()));
            double pitchDelta = wantedPitch - player.getPitch();
            double angle = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
            if (Math.abs(yawDelta) <= fov / 2.0 && angle < bestAngle) {
                bestAngle = angle;
                target = candidate;
            }
        }

        if (target == null) return;
        Vec3d aimAt = aimPosition(target, cfg.aimPoint);
        double dx = aimAt.x - player.getX();
        double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
        double dz = aimAt.z - player.getZ();
        float wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        float wantedPitch = MathHelper.wrapDegrees((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        double speed = Math.max(1.0, Math.min(20.0, cfg.aimSpeed));
        double maxStep = Math.max(1.0, Math.min(30.0, cfg.aimMaxSpeed));
        float factor = (float) (speed / 20.0);
        float yawStep = MathHelper.clamp(MathHelper.wrapDegrees(wantedYaw - player.getYaw()) * factor,
                (float) -maxStep, (float) maxStep);
        float pitchStep = MathHelper.clamp((wantedPitch - player.getPitch()) * factor,
                (float) -maxStep, (float) maxStep);
        player.setYaw(player.getYaw() + yawStep);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchStep, -90.0F, 90.0F));
    }

    private static void runTriggerBot(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (cfg.triggerOnlyWeapon && !hasWeapon(player.getMainHandStack())) return;
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target) || !target.isAlive() || target == player) return;
        if (!(target instanceof HostileEntity)
                && !(cfg.targetPlayers && target instanceof PlayerEntity)) return;
        if (player.distanceTo(target) > Math.max(1.0, Math.min(6.0, cfg.triggerRange))) return;
        if (cfg.triggerCriticalOnly && (player.isOnGround() || player.fallDistance <= 0.0F
                || player.isTouchingWater() || player.isClimbing() || player.hasVehicle())) return;

        long now = System.currentTimeMillis();
        int delay = Math.max(80, Math.min(1000, cfg.triggerDelayMs));
        if (now - lastTriggerAt < delay) return;
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastTriggerAt = now;
    }

    private static Vec3d aimPosition(LivingEntity entity, String point) {
        double y = switch (point == null ? "HEAD" : point) {
            case "CHEST" -> entity.getY() + entity.getHeight() * 0.60;
            case "LEGS" -> entity.getY() + entity.getHeight() * 0.25;
            default -> entity.getY() + entity.getStandingEyeHeight() * 0.95;
        };
        return new Vec3d(entity.getX(), y, entity.getZ());
    }

    private static boolean hasWeapon(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem;
    }
}
