package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Client-side combat helpers with configurable entity targeting. */
public final class CombatModules {
    private static long lastTriggerAt;
    private static int lockedTargetId = -1;

    private CombatModules() {}

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null
                || client.interactionManager == null || client.currentScreen != null) return;

        ModuleSettings cfg = ModuleSettings.get();
        PlayerEntity player = client.player;
        if (cfg.aimAssistEnabled) runAimAssist(client, cfg, player);
        else lockedTargetId = -1;
        if (cfg.triggerBotEnabled) runTriggerBot(client, cfg, player);
    }

    private static void runAimAssist(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (cfg.onlyWeapon && !hasWeapon(player.getMainHandStack())) return;

        double range = clamp(cfg.aimRange, 1.0, 12.0);
        double fov = clamp(cfg.aimFov, 1.0, 360.0);
        LivingEntity target = null;
        double bestScore = Double.MAX_VALUE;

        for (LivingEntity candidate : client.world.getEntitiesByClass(LivingEntity.class,
                player.getBoundingBox().expand(range), e -> isTargetAllowed(client, cfg, player, e))) {
            Vec3d aimAt = aimPosition(candidate, cfg.aimPoint);
            double dx = aimAt.x - player.getX();
            double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
            double dz = aimAt.z - player.getZ();
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distance < 0.001 || distance > range) continue;

            double wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
            double wantedPitch = MathHelper.wrapDegrees((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
            double yawDelta = MathHelper.wrapDegrees((float) (wantedYaw - player.getYaw()));
            double pitchDelta = wantedPitch - player.getPitch();
            double angle = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
            if (Math.abs(yawDelta) > fov / 2.0) continue;

            // Slight target lock preference prevents the assist flickering between nearby entities.
            double score = angle - (candidate.getId() == lockedTargetId ? 5.0 : 0.0);
            if (score < bestScore) {
                bestScore = score;
                target = candidate;
            }
        }

        if (target == null) {
            lockedTargetId = -1;
            return;
        }
        lockedTargetId = target.getId();

        Vec3d aimAt = aimPosition(target, cfg.aimPoint);
        double dx = aimAt.x - player.getX();
        double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
        double dz = aimAt.z - player.getZ();
        float wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        float wantedPitch = MathHelper.wrapDegrees((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        double speed = clamp(cfg.aimSpeed, 1.0, 20.0);
        double maxStep = clamp(cfg.aimMaxSpeed, 0.25, 30.0);
        // Exponential interpolation uses the shortest yaw path and a capped step to avoid hard snaps.
        float factor = (float) (1.0 - Math.exp(-speed * 0.028));
        float yawDelta = MathHelper.wrapDegrees(wantedYaw - player.getYaw());
        float pitchDelta = wantedPitch - player.getPitch();
        float yawStep = MathHelper.clamp(yawDelta * factor, (float) -maxStep, (float) maxStep);
        float pitchStep = MathHelper.clamp(pitchDelta * factor, (float) -maxStep, (float) maxStep);
        player.setYaw(player.getYaw() + yawStep);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchStep, -90.0F, 90.0F));
    }

    private static void runTriggerBot(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (cfg.triggerOnlyWeapon && !hasWeapon(player.getMainHandStack())) return;
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target)
                || !isTargetAllowed(client, cfg, player, target)) return;
        if (player.distanceTo(target) > clamp(cfg.triggerRange, 1.0, 6.0)) return;
        if (cfg.triggerCriticalOnly && (player.isOnGround() || player.fallDistance <= 0.0F
                || player.isTouchingWater() || player.isClimbing() || player.hasVehicle())) return;

        long now = System.currentTimeMillis();
        int delay = (int) clamp(cfg.triggerDelayMs, 80.0, 1000.0);
        if (now - lastTriggerAt < delay) return;
        // Respect vanilla's attack recharge so clicks are not sent faster than the weapon can hit.
        if (player.getAttackCooldownProgress(0.5F) < 0.92F) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastTriggerAt = now;
    }

    private static boolean isTargetAllowed(MinecraftClient client, ModuleSettings cfg,
                                           PlayerEntity player, LivingEntity entity) {
        if (entity == null || entity == player || !entity.isAlive() || entity.isRemoved()) return false;
        if (entity instanceof HostileEntity) return true;
        return cfg.targetPlayers && entity instanceof PlayerEntity;
    }

    private static Vec3d aimPosition(LivingEntity entity, String point) {
        double y = switch (point == null ? "HEAD" : point) {
            case "CHEST" -> entity.getY() + entity.getHeight() * 0.60;
            case "LEGS" -> entity.getY() + entity.getHeight() * 0.25;
            default -> entity.getY() + entity.getStandingEyeHeight() * 0.95;
        };
        return new Vec3d(entity.getX(), y, entity.getZ());
    }

    private static boolean hasWeapon(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
