package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Local single-player practice helpers. Automated combat is intentionally inactive in multiplayer. */
public final class CombatModules {
    private static final double TRIGGER_RANGE = 3.0;
    private static final long TRIGGER_DELAY_MS = 120L;
    private static long lastTriggerAt;
    private static long lastShieldBreakAt;
    private static int lockedTargetId = -1;

    private CombatModules() {}

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null
                || client.interactionManager == null || client.currentScreen != null) return;

        // A single-player world can be opened to LAN; disable automation if anyone else joins.
        if (!isSoloPracticeWorld(client)) {
            lockedTargetId = -1;
            return;
        }

        ModuleSettings cfg = ModuleSettings.get();
        PlayerEntity player = client.player;
        if (cfg.aimAssistEnabled) runAimAssist(client, cfg, player);
        else lockedTargetId = -1;
        if (cfg.triggerBotEnabled) runTriggerBot(client, cfg, player);
        if (cfg.shieldBreakerEnabled) runShieldBreaker(client, cfg, player);
    }

    private static boolean isSoloPracticeWorld(MinecraftClient client) {
        if (!client.isInSingleplayer()) return false;
        var server = client.getServer();
        return server == null || server.getPlayerManager().getPlayerList().size() <= 1;
    }

    private static void runAimAssist(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        double range = clamp(cfg.aimRange, 1.0, 6.0);
        double fov = clamp(cfg.aimFov, 30.0, 360.0);
        LivingEntity target = null;
        double bestScore = Double.MAX_VALUE;

        for (LivingEntity candidate : client.world.getEntitiesByClass(LivingEntity.class,
                player.getBoundingBox().expand(range), e -> isTargetAllowed(cfg, player, e))) {
            if (!player.canSee(candidate)) continue;
            Vec3d aimAt = aimPosition(candidate, cfg.aimPoint);
            double dx = aimAt.x - player.getX();
            double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
            double dz = aimAt.z - player.getZ();
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distance < 0.001 || distance > range) continue;

            double wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
            double yawDelta = MathHelper.wrapDegrees((float) (wantedYaw - player.getYaw()));
            double pitchDelta = -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))) - player.getPitch();
            double angle = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
            if (Math.abs(yawDelta) > fov / 2.0) continue;

            // Small lock bonus prevents target flicker when two practice targets stand close together.
            double score = angle - (candidate.getId() == lockedTargetId ? 5.0 : 0.0);
            if (score < bestScore) {
                bestScore = score;
                target = candidate;
            }
        }

        if (target == null) {
            lockedTargetId = -1;
            return;
        }
        lockedTargetId = target.getId();

        Vec3d aimAt = aimPosition(target, cfg.aimPoint);
        double dx = aimAt.x - player.getX();
        double dy = aimAt.y - (player.getY() + player.getStandingEyeHeight());
        double dz = aimAt.z - player.getZ();
        float wantedYaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        float wantedPitch = MathHelper.wrapDegrees((float) -Math.toDegrees(
                Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        // Exponential ease-in plus a capped per-tick delta avoids abrupt snapping in practice mode.
        double speed = clamp(cfg.aimSpeed, 1.0, 20.0);
        double maxStep = clamp(cfg.aimMaxSpeed, 1.0, 30.0);
        float factor = (float) (1.0 - Math.exp(-speed * 0.035));
        float yawDelta = MathHelper.wrapDegrees(wantedYaw - player.getYaw());
        float pitchDelta = wantedPitch - player.getPitch();
        float yawStep = MathHelper.clamp(yawDelta * factor, (float) -maxStep, (float) maxStep);
        float pitchStep = MathHelper.clamp(pitchDelta * factor, (float) -maxStep, (float) maxStep);
        player.setYaw(player.getYaw() + yawStep);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchStep, -90.0F, 90.0F));
    }

    private static void runTriggerBot(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target) || !isTargetAllowed(cfg, player, target)) return;
        if (!player.canSee(target) || player.distanceTo(target) > TRIGGER_RANGE) return;
        if (player.getAttackCooldownProgress(0.5F) < 0.95F) return;

        long now = System.currentTimeMillis();
        if (now - lastTriggerAt < TRIGGER_DELAY_MS) return;
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastTriggerAt = now;
    }

    private static void runShieldBreaker(MinecraftClient client, ModuleSettings cfg, PlayerEntity player) {
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target) || !isTargetAllowed(cfg, player, target)) return;
        if (!player.canSee(target) || player.distanceTo(target) > clamp(cfg.shieldRange, 1.0, 3.0)) return;
        if (!target.isUsingItem() || !(target.getActiveItem().getItem() instanceof ShieldItem)) return;

        long now = System.currentTimeMillis();
        if (now - lastShieldBreakAt < 120L || player.getAttackCooldownProgress(0.5F) < 0.95F) return;
        int axeSlot = findAxeSlot(player);
        if (axeSlot < 0) return;

        player.getInventory().selectedSlot = axeSlot;
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastShieldBreakAt = now;
    }

    private static int findAxeSlot(PlayerEntity player) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getStack(slot);
            if (stack.getItem() instanceof AxeItem) return slot;
        }
        return -1;
    }

    private static boolean isTargetAllowed(ModuleSettings cfg, PlayerEntity player, LivingEntity entity) {
        if (entity == null || entity == player || !entity.isAlive() || entity.isRemoved()) return false;
        if (entity instanceof PlayerEntity) return cfg.targetPlayers;
        return entity instanceof HostileEntity;
    }

    private static Vec3d aimPosition(LivingEntity entity, String point) {
        double y = switch (point == null ? "HEAD" : point) {
            case "CHEST" -> entity.getY() + entity.getHeight() * 0.60;
            case "LEGS" -> entity.getY() + entity.getHeight() * 0.25;
            default -> entity.getY() + entity.getStandingEyeHeight() * 0.95;
        };
        return new Vec3d(entity.getX(), y, entity.getZ());
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
