package com.damnson.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;

/** Settings screen for single-player hostile-mob practice helpers. */
public final class DamnSonScreen extends Screen {
    private final ModuleSettings cfg = ModuleSettings.get();
    private final long openedAt = System.currentTimeMillis();

    public DamnSonScreen() {
        super(Text.literal("Damn Son"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 155;
        int top = Math.max(36, this.height / 2 - 130);

        addDrawableChild(ButtonWidget.builder(toggleText("AA", cfg.aimAssistEnabled), b -> {
            cfg.aimAssistEnabled = !cfg.aimAssistEnabled;
            b.setMessage(toggleText("AA", cfg.aimAssistEnabled));
            clickSound();
            cfg.save();
        }).dimensions(left, top, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("TB", cfg.triggerBotEnabled), b -> {
            cfg.triggerBotEnabled = !cfg.triggerBotEnabled;
            b.setMessage(toggleText("TB", cfg.triggerBotEnabled));
            clickSound();
            cfg.save();
        }).dimensions(left + 165, top, 145, 20).build());

        addDrawableChild(new ValueSlider(left, top + 28, 145, 20,
                "AA Range", 1, 12, cfg.aimRange, v -> cfg.aimRange = v));
        addDrawableChild(new ValueSlider(left, top + 52, 145, 20,
                "AA Speed", 1, 20, cfg.aimSpeed, v -> cfg.aimSpeed = v));
        addDrawableChild(new ValueSlider(left, top + 76, 145, 20,
                "AA Max Step", 1, 30, cfg.aimMaxSpeed, v -> cfg.aimMaxSpeed = v));
        addDrawableChild(new ValueSlider(left, top + 100, 145, 20,
                "AA FOV", 1, 360, cfg.aimFov, v -> cfg.aimFov = v));

        addDrawableChild(new ValueSlider(left + 165, top + 28, 145, 20,
                "TB Range", 1, 6, cfg.triggerRange, v -> cfg.triggerRange = v));
        addDrawableChild(new ValueSlider(left + 165, top + 52, 145, 20,
                "TB Delay ms", 80, 1000, cfg.triggerDelayMs, v -> cfg.triggerDelayMs = (int) v));

        addDrawableChild(ButtonWidget.builder(toggleText("Target Players", cfg.targetPlayers), b -> {
            cfg.targetPlayers = !cfg.targetPlayers;
            b.setMessage(toggleText("Target Players", cfg.targetPlayers));
            clickSound();
            cfg.save();
        }).dimensions(left + 165, top + 152, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("AA Only Weapon", cfg.onlyWeapon), b -> {
            cfg.onlyWeapon = !cfg.onlyWeapon;
            b.setMessage(toggleText("AA Only Weapon", cfg.onlyWeapon));
            clickSound();
            cfg.save();
        }).dimensions(left, top + 128, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("TB Only Weapon", cfg.triggerOnlyWeapon), b -> {
            cfg.triggerOnlyWeapon = !cfg.triggerOnlyWeapon;
            b.setMessage(toggleText("TB Only Weapon", cfg.triggerOnlyWeapon));
            clickSound();
            cfg.save();
        }).dimensions(left + 165, top + 76, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("TB Critical Only", cfg.triggerCriticalOnly), b -> {
            cfg.triggerCriticalOnly = !cfg.triggerCriticalOnly;
            b.setMessage(toggleText("TB Critical Only", cfg.triggerCriticalOnly));
            clickSound();
            cfg.save();
        }).dimensions(left + 165, top + 100, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Aim Point: " + cfg.aimPoint), b -> {
            cfg.aimPoint = switch (cfg.aimPoint) {
                case "HEAD" -> "CHEST";
                case "CHEST" -> "LEGS";
                default -> "HEAD";
            };
            b.setMessage(Text.literal("Aim Point: " + cfg.aimPoint));
            clickSound();
            cfg.save();
        }).dimensions(left, top + 152, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Save settings"), b -> cfg.save())
                .dimensions(left + 165, top + 128, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(this.width / 2 - 50, top + 184, 100, 20).build());
    }

    private void clickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 0.45F, 1.15F);
    }

    private static Text toggleText(String label, boolean enabled) {
        return Text.literal(label + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = this.width / 2 - 155;
        int top = Math.max(42, this.height / 2 - 126);
        float pulse = (float) (0.5 + 0.5 * Math.sin((System.currentTimeMillis() - openedAt) / 260.0));
        int accent = 0xFF39BFFF;
        context.fill(0, 0, width, height, 0x99040814);
        context.fill(left - 8, top - 9, left + 153, top + 178, 0xE8101422);
        context.fill(left + 157, top - 9, left + 318, top + 178, 0xE8101422);
        context.fill(left - 8, top - 9, left + 318, top - 6, accent);
        context.fill(left - 8, top + 177, left + 318, top + 179, 0xFF8A4DFF);
        context.fill(left - 8, top - 9, left - 5, top + 179, accent);
        context.fill(left + 315, top - 9, left + 318, top + 179, 0xFF8A4DFF);
        context.fill(left + 2, top + 3, left + 148, top + 5, 0x5539BFFF + ((int)(pulse * 0x40) << 24));
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, top - 31, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "VEGETA MODE  /  COMBAT CONFIGURATION", width / 2, top - 18, 0xFFB9DFFF);
        context.drawTextWithShadow(textRenderer, "AIM CONTROL", left + 7, top - 1, 0xFF39BFFF);
        context.drawTextWithShadow(textRenderer, "TRIGGER CONTROL", left + 172, top - 1, 0xFFB78AFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double settingValue;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(),
                    (Math.max(min, Math.min(max, initial)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.settingValue = clamp(initial);
            updateMessage();
        }

        private double clamp(double v) {
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void updateMessage() {
            String shown = settingValue == Math.rint(settingValue)
                    ? Integer.toString((int) settingValue)
                    : String.format(java.util.Locale.ROOT, "%.1f", settingValue);
            setMessage(Text.literal(label + ": " + shown));
        }

        @Override
        protected void applyValue() {
            settingValue = clamp(min + (max - min) * this.value);
            setter.accept(settingValue);
            updateMessage();
            ModuleSettings.get().save();
        }
    }
}
