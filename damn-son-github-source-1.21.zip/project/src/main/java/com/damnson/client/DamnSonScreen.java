package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Animated, Vegeta-themed configuration screen. */
public final class DamnSonScreen extends Screen {
    private static final Identifier VEGETA_BG = Identifier.of("damnson", "textures/gui/vegeta_bg.png");
    private static final Identifier L_LOGO = Identifier.of("damnson", "textures/gui/l_logo.png");
    private static final long INTRO_MS = 420L;

    private final ModuleSettings cfg = ModuleSettings.get();
    private final long openedAt = System.currentTimeMillis();
    private String listeningFor = "";
    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;
    private int colW;
    private int rowStep;
    private int rowH;
    private int leftX;
    private int rightX;
    private int firstRowY;

    public DamnSonScreen() {
        super(Text.literal("Damn Son | Combat Lab"));
    }

    @Override
    protected void init() {
        panelW = Math.min(560, Math.max(300, this.width - 16));
        panelH = Math.min(330, Math.max(230, this.height - 26));
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        colW = (panelW - 48) / 2;
        leftX = panelX + 16;
        rightX = panelX + 32 + colW;
        rowStep = Math.max(16, Math.min(26, (panelH - 110) / 8));
        rowH = Math.max(14, Math.min(22, rowStep - 3));
        firstRowY = panelY + 68;

        addDrawableChild(ButtonWidget.builder(toggleText("AIM ASSIST", cfg.aimAssistEnabled), b -> {
            cfg.aimAssistEnabled = !cfg.aimAssistEnabled;
            b.setMessage(toggleText("AIM ASSIST", cfg.aimAssistEnabled));
            moduleToggleSound(cfg.aimAssistEnabled);
            cfg.save();
        }).dimensions(leftX, rowY(0), colW, rowH).build());

        addDrawableChild(ButtonWidget.builder(toggleText("TRIGGER BOT", cfg.triggerBotEnabled), b -> {
            cfg.triggerBotEnabled = !cfg.triggerBotEnabled;
            b.setMessage(toggleText("TRIGGER BOT", cfg.triggerBotEnabled));
            moduleToggleSound(cfg.triggerBotEnabled);
            cfg.save();
        }).dimensions(rightX, rowY(0), colW, rowH).build());

        addDrawableChild(new ValueSlider(leftX, rowY(1), colW, rowH,
                "AA Range", 1, 12, cfg.aimRange, v -> cfg.aimRange = v));
        addDrawableChild(new ValueSlider(leftX, rowY(2), colW, rowH,
                "AA Smoothness", 1, 20, cfg.aimSpeed, v -> cfg.aimSpeed = v));
        addDrawableChild(new ValueSlider(leftX, rowY(3), colW, rowH,
                "AA Max Step", 1, 30, cfg.aimMaxSpeed, v -> cfg.aimMaxSpeed = v));
        addDrawableChild(new ValueSlider(leftX, rowY(4), colW, rowH,
                "AA FOV", 1, 360, cfg.aimFov, v -> cfg.aimFov = v));
        addDrawableChild(ButtonWidget.builder(toggleText("Weapon Required", cfg.onlyWeapon), b -> {
            cfg.onlyWeapon = !cfg.onlyWeapon;
            b.setMessage(toggleText("Weapon Required", cfg.onlyWeapon));
            uiClickSound();
            cfg.save();
        }).dimensions(leftX, rowY(5), colW, rowH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Aim Point: " + cfg.aimPoint), b -> {
            cfg.aimPoint = switch (cfg.aimPoint) {
                case "HEAD" -> "CHEST";
                case "CHEST" -> "LEGS";
                default -> "HEAD";
            };
            b.setMessage(Text.literal("Aim Point: " + cfg.aimPoint));
            uiClickSound();
            cfg.save();
        }).dimensions(leftX, rowY(6), colW, rowH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("AA Key: " + keyName(cfg.aimToggleKey)), b -> {
            listeningFor = "AA";
            b.setMessage(Text.literal("AA Key: PRESS KEY..."));
            uiClickSound();
        }).dimensions(leftX, rowY(7), colW, rowH).build());

        addDrawableChild(new ValueSlider(rightX, rowY(1), colW, rowH,
                "TB Range", 1, 6, cfg.triggerRange, v -> cfg.triggerRange = v));
        addDrawableChild(new ValueSlider(rightX, rowY(2), colW, rowH,
                "TB Delay (ms)", 80, 1000, cfg.triggerDelayMs, v -> cfg.triggerDelayMs = (int) v));
        addDrawableChild(ButtonWidget.builder(toggleText("Weapon Required", cfg.triggerOnlyWeapon), b -> {
            cfg.triggerOnlyWeapon = !cfg.triggerOnlyWeapon;
            b.setMessage(toggleText("Weapon Required", cfg.triggerOnlyWeapon));
            uiClickSound();
            cfg.save();
        }).dimensions(rightX, rowY(3), colW, rowH).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Critical Hits Only", cfg.triggerCriticalOnly), b -> {
            cfg.triggerCriticalOnly = !cfg.triggerCriticalOnly;
            b.setMessage(toggleText("Critical Hits Only", cfg.triggerCriticalOnly));
            uiClickSound();
            cfg.save();
        }).dimensions(rightX, rowY(4), colW, rowH).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Target Players", cfg.targetPlayers), b -> {
            cfg.targetPlayers = !cfg.targetPlayers;
            b.setMessage(toggleText("Target Players", cfg.targetPlayers));
            uiClickSound();
            cfg.save();
        }).dimensions(rightX, rowY(5), colW, rowH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("TB Key: " + keyName(cfg.triggerToggleKey)), b -> {
            listeningFor = "TB";
            b.setMessage(Text.literal("TB Key: PRESS KEY..."));
            uiClickSound();
        }).dimensions(rightX, rowY(6), colW, rowH).build());

        int footerY = panelY + panelH - 32;
        addDrawableChild(ButtonWidget.builder(Text.literal("SAVE SETTINGS"), b -> {
            cfg.save();
            uiClickSound();
        }).dimensions(this.width / 2 - 112, footerY, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close())
                .dimensions(this.width / 2 + 4, footerY, 108, 20).build());
    }

    private int rowY(int row) {
        return firstRowY + row * rowStep;
    }

    private static String keyName(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN || key <= 0) return "UNBOUND";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        if (key == GLFW.GLFW_KEY_LEFT_ALT) return "LALT";
        if (key == GLFW.GLFW_KEY_RIGHT_ALT) return "RALT";
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "KEY " + key : name.toUpperCase(java.util.Locale.ROOT);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningFor.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                listeningFor = "";
                uiClickSound();
                clearAndInit();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) return true;
            if (listeningFor.equals("AA")) cfg.aimToggleKey = keyCode;
            else cfg.triggerToggleKey = keyCode;
            listeningFor = "";
            cfg.save();
            uiClickSound();
            clearAndInit();
            return true;
        }
        boolean handled = super.keyPressed(keyCode, scanCode, modifiers);
        if (handled) cfg.save();
        return handled;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseReleased(mouseX, mouseY, button);
        // Persist slider changes once the drag ends instead of writing the file every frame.
        cfg.save();
        return handled;
    }

    private void uiClickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.40F, 1.20F);
        }
    }

    private void moduleToggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),
                    0.42F, enabled ? 1.62F : 0.78F);
        }
    }

    private static Text toggleText(String label, boolean enabled) {
        return Text.literal(label + "  ·  " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        float phase = (now - openedAt) / 260.0F;
        float pulse = (float) (0.5 + 0.5 * Math.sin(phase));
        float intro = Math.min(1.0F, Math.max(0.0F, (now - openedAt) / (float) INTRO_MS));
        float ease = 1.0F - (float) Math.pow(1.0F - intro, 3.0);

        // Full-screen Vegeta art with a deep blue veil and an animated scan beam.
        context.drawTexture(VEGETA_BG, 0, 0, 0.0F, 0.0F, this.width, this.height, 500, 275);
        context.fill(0, 0, width, height, 0x97030A19);
        context.fill(0, 0, width, 22, 0x48030A19);
        context.fill(0, height - 24, width, height, 0x60030A19);
        int beamX = (int) ((now / 13L) % Math.max(1, width));
        context.fill(beamX, 0, Math.min(width, beamX + 2), height, 0x203BBEFF);

        // Main frame, glowing edge and two separate module cards.
        context.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0x88000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xE9091222);
        context.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFF39BFFF);
        context.fill(panelX, panelY + panelH - 2, panelX + panelW, panelY + panelH, 0xFF8B55FF);
        context.fill(panelX, panelY, panelX + 2, panelY + panelH, 0xFF39BFFF);
        context.fill(panelX + panelW - 2, panelY, panelX + panelW, panelY + panelH, 0xFF8B55FF);

        int cardTop = panelY + 54;
        int cardBottom = panelY + panelH - 42;
        context.fill(leftX - 5, cardTop, leftX + colW + 5, cardBottom, 0xC80A1B30);
        context.fill(rightX - 5, cardTop, rightX + colW + 5, cardBottom, 0xC813142E);
        context.fill(leftX - 5, cardTop, leftX + colW + 5, cardTop + 2, 0xFF28BFFF);
        context.fill(rightX - 5, cardTop, rightX + colW + 5, cardTop + 2, 0xFFAF72FF);

        // Animated energy sweep across the cards. Controls are drawn afterward and remain clickable.
        int sweepWidth = Math.max(1, panelW / 5);
        int sweepX = panelX + (int) ((now / 8L) % Math.max(1, panelW + sweepWidth)) - sweepWidth;
        context.fill(Math.max(panelX, sweepX), panelY + 3,
                Math.min(panelX + panelW, sweepX + sweepWidth), panelY + 5,
                0x6639BFFF | ((int) (pulse * 0x22) << 24));

        // L is used as both the header mark and the separate Fabric mod icon in fabric.mod.json.
        int logoSize = 34;
        context.fill(panelX + 13, panelY + 9, panelX + 13 + logoSize + 4, panelY + 9 + logoSize + 4,
                0x5039BFFF | ((int) (pulse * 0x25) << 24));
        context.drawTexture(L_LOGO, panelX + 15, panelY + 11, 0, 0, logoSize, logoSize, 128, 128);
        context.drawTextWithShadow(textRenderer, "DAMN SON", panelX + 60, panelY + 13, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "VEGETA PROTOCOL  //  COMBAT LAB", panelX + 60, panelY + 28, 0xFF9FCFFF);

        int indicatorY = panelY + 15;
        int indicatorX = panelX + panelW - 115;
        context.fill(indicatorX, indicatorY, indicatorX + 8, indicatorY + 8,
                cfg.aimAssistEnabled ? 0xFF41FFC0 : 0xFF62718A);
        context.drawTextWithShadow(textRenderer, "AA", indicatorX + 12, indicatorY, 0xFFE8F4FF);
        context.fill(indicatorX + 43, indicatorY, indicatorX + 51, indicatorY + 8,
                cfg.triggerBotEnabled ? 0xFF41FFC0 : 0xFF62718A);
        context.drawTextWithShadow(textRenderer, "TB", indicatorX + 55, indicatorY, 0xFFE8F4FF);

        context.drawTextWithShadow(textRenderer, "01  AIM CONTROL", leftX, panelY + 44, 0xFF62D5FF);
        context.drawTextWithShadow(textRenderer, "02  TRIGGER CONTROL", rightX, panelY + 44, 0xFFC8A4FF);
        context.fill(panelX + 14, panelY + panelH - 39, panelX + panelW - 14, panelY + panelH - 37,
                0x4439BFFF | ((int) (pulse * 0x25) << 24));
        if (rowStep >= 20) {
            context.drawCenteredTextWithShadow(textRenderer,
                    listeningFor.isEmpty() ? "RIGHT SHIFT  •  OPEN/CLOSE MENU" : "PRESS KEY FOR " + listeningFor + "  •  ESC CANCELS",
                    this.width / 2, panelY + panelH - 49, listeningFor.isEmpty() ? 0xFF9FCFFF : 0xFFFFD479);
        }
        context.drawCenteredTextWithShadow(textRenderer,
                cfg.targetPlayers ? "PLAYER TARGETING: ON" : "PLAYER TARGETING: OFF",
                this.width / 2, panelY + panelH - 10, 0xFFFFD479);

        // Ease the glow in on opening; widgets remain anchored so hitboxes always match their visuals.
        int introAlpha = (int) (ease * (0x18 + pulse * 0x25));
        context.fill(panelX + 2, panelY + 3, panelX + panelW - 2, panelY + 5,
                (introAlpha << 24) | 0x0039BFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double settingValue;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(),
                    (Math.max(min, Math.min(max, initial)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.settingValue = clamp(initial);
            updateMessage();
        }

        private double clamp(double v) {
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void updateMessage() {
            String shown = settingValue == Math.rint(settingValue)
                    ? Integer.toString((int) settingValue)
                    : String.format(java.util.Locale.ROOT, "%.1f", settingValue);
            setMessage(Text.literal(label + "  ·  " + shown));
        }

        @Override
        protected void applyValue() {
            settingValue = clamp(min + (max - min) * this.value);
            setter.accept(settingValue);
            updateMessage();
        }
    }
}
