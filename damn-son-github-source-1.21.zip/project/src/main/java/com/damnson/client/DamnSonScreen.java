package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Animated, dark game-client-inspired configuration screen. */
public final class DamnSonScreen extends Screen {
    private static final Identifier ANIME_BG = Identifier.of("damnson", "textures/gui/anime_bg.png");
    private static final Identifier L_LOGO = Identifier.of("damnson", "textures/gui/l_logo.png");
    private static final int DEFAULT_AA_KEY = GLFW.GLFW_KEY_R;
    private static final int DEFAULT_TB_KEY = GLFW.GLFW_KEY_V;
    private static final int DEFAULT_SB_KEY = GLFW.GLFW_KEY_B;

    private final ModuleSettings cfg = ModuleSettings.get();
    private final long openedAt = System.currentTimeMillis();
    private String listeningFor = "";
    private int panelX, panelY, panelW, panelH;
    private int sideW, contentX, contentW, cardY, contentH;
    private int aimX, aimW, sideX, sideWCard, sideTopH, sideBottomY, sideBottomH;

    public DamnSonScreen() {
        super(Text.literal("Damn Son | Practice Lab"));
    }

    @Override
    protected void init() {
        panelW = Math.min(760, Math.max(300, width - 20));
        panelH = Math.min(430, Math.max(270, height - 20));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        sideW = Math.min(132, Math.max(94, panelW / 5));
        contentX = panelX + sideW + 16;
        contentW = panelX + panelW - 16 - contentX;
        cardY = panelY + 86;
        contentH = panelY + panelH - 44 - cardY;
        aimW = Math.max(190, (int) ((contentW - 12) * 0.59));
        aimX = contentX;
        sideX = aimX + aimW + 12;
        sideWCard = contentW - aimW - 12;
        sideTopH = (contentH - 10) / 2;
        sideBottomY = cardY + sideTopH + 10;
        sideBottomH = contentH - sideTopH - 10;

        int innerX = aimX + 12;
        int innerW = aimW - 24;
        int halfGap = 6;
        int halfW = (innerW - halfGap) / 2;
        int row = cardY + 38;
        int h = 20;
        addDrawableChild(ButtonWidget.builder(toggleText("AIM ASSIST", cfg.aimAssistEnabled), b -> {
            cfg.aimAssistEnabled = !cfg.aimAssistEnabled;
            b.setMessage(toggleText("AIM ASSIST", cfg.aimAssistEnabled));
            moduleToggleSound(cfg.aimAssistEnabled);
            cfg.save();
        }).dimensions(innerX, row, halfW, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("KEY  " + keyName(cfg.aimToggleKey)), b -> startListening("AA"))
                .dimensions(innerX + halfW + halfGap, row, innerW - halfW - halfGap, h).build());

        addDrawableChild(new ValueSlider(innerX, row + 25, innerW, h,
                "Range", 1, 6, cfg.aimRange, v -> cfg.aimRange = v));
        addDrawableChild(new ValueSlider(innerX, row + 49, innerW, h,
                "Smoothness", 1, 20, cfg.aimSpeed, v -> cfg.aimSpeed = v));
        addDrawableChild(new ValueSlider(innerX, row + 73, innerW, h,
                "Max turn / tick", 1, 30, cfg.aimMaxSpeed, v -> cfg.aimMaxSpeed = v));
        addDrawableChild(new ValueSlider(innerX, row + 97, innerW, h,
                "FOV", 30, 360, cfg.aimFov, v -> cfg.aimFov = v));
        addDrawableChild(ButtonWidget.builder(Text.literal("Aim point  ·  " + cfg.aimPoint), b -> {
            cfg.aimPoint = switch (cfg.aimPoint) {
                case "HEAD" -> "CHEST";
                case "CHEST" -> "LEGS";
                default -> "HEAD";
            };
            b.setMessage(Text.literal("Aim point  ·  " + cfg.aimPoint));
            uiClickSound();
            cfg.save();
        }).dimensions(innerX, row + 121, innerW, h).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Player targets", cfg.targetPlayers), b -> {
            cfg.targetPlayers = !cfg.targetPlayers;
            b.setMessage(toggleText("Player targets", cfg.targetPlayers));
            uiClickSound();
            cfg.save();
        }).dimensions(innerX, row + 145, innerW, h).build());

        int sx = sideX + 12;
        int sw = sideWCard - 24;
        int sh = 20;
        int triggerY = cardY + 38;
        addDrawableChild(ButtonWidget.builder(toggleText("TRIGGER BOT", cfg.triggerBotEnabled), b -> {
            cfg.triggerBotEnabled = !cfg.triggerBotEnabled;
            b.setMessage(toggleText("TRIGGER BOT", cfg.triggerBotEnabled));
            moduleToggleSound(cfg.triggerBotEnabled);
            cfg.save();
        }).dimensions(sx, triggerY, sw, sh).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("KEY  " + keyName(cfg.triggerToggleKey)), b -> startListening("TB"))
                .dimensions(sx, triggerY + 25, sw, sh).build());

        int shieldY = sideBottomY + 38;
        addDrawableChild(ButtonWidget.builder(toggleText("SHIELD BREAKER", cfg.shieldBreakerEnabled), b -> {
            cfg.shieldBreakerEnabled = !cfg.shieldBreakerEnabled;
            b.setMessage(toggleText("SHIELD BREAKER", cfg.shieldBreakerEnabled));
            moduleToggleSound(cfg.shieldBreakerEnabled);
            cfg.save();
        }).dimensions(sx, shieldY, sw, sh).build());
        addDrawableChild(new ValueSlider(sx, shieldY + 25, sw, sh,
                "Range", 1, 3, cfg.shieldRange, v -> cfg.shieldRange = v));
        addDrawableChild(ButtonWidget.builder(Text.literal("KEY  " + keyName(cfg.shieldBreakerToggleKey)), b -> startListening("SB"))
                .dimensions(sx, shieldY + 50, sw, sh).build());

        int footerY = panelY + panelH - 29;
        addDrawableChild(ButtonWidget.builder(Text.literal("SAVE"), b -> {
            cfg.save();
            uiClickSound();
        }).dimensions(panelX + panelW - 172, footerY, 72, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close())
                .dimensions(panelX + panelW - 92, footerY, 76, 20).build());
    }

    private void startListening(String module) {
        listeningFor = module;
        uiClickSound();
        clearAndInit();
    }

    private void resetListeningToDefault() {
        switch (listeningFor) {
            case "AA" -> cfg.aimToggleKey = DEFAULT_AA_KEY;
            case "TB" -> cfg.triggerToggleKey = DEFAULT_TB_KEY;
            case "SB" -> cfg.shieldBreakerToggleKey = DEFAULT_SB_KEY;
            default -> { }
        }
        listeningFor = "";
        cfg.save();
    }

    private static String keyName(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN || key <= 0) return "UNBOUND";
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_ESCAPE -> "ESC";
            default -> {
                String name = GLFW.glfwGetKeyName(key, 0);
                yield name == null ? "KEY " + key : name.toUpperCase(java.util.Locale.ROOT);
            }
        };
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningFor.isEmpty()) {
            // Escape/back restores the selected module's default key instead of leaving a half-bound state.
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                resetListeningToDefault();
                uiClickSound();
                clearAndInit();
                return true;
            }
            // Right Shift remains reserved for opening/closing the GUI.
            if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) return true;
            switch (listeningFor) {
                case "AA" -> cfg.aimToggleKey = keyCode;
                case "TB" -> cfg.triggerToggleKey = keyCode;
                case "SB" -> cfg.shieldBreakerToggleKey = keyCode;
                default -> { }
            }
            listeningFor = "";
            cfg.save();
            uiClickSound();
            clearAndInit();
            return true;
        }
        boolean handled = super.keyPressed(keyCode, scanCode, modifiers);
        if (handled) cfg.save();
        return handled;
    }

    @Override
    public void close() {
        if (!listeningFor.isEmpty()) resetListeningToDefault();
        super.close();
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseReleased(mouseX, mouseY, button);
        cfg.save();
        return handled;
    }

    private void uiClickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.35F, 1.28F);
    }

    private void moduleToggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),
                    0.42F, enabled ? 1.66F : 0.76F);
        }
    }

    private static Text toggleText(String label, boolean enabled) {
        return Text.literal(label + "  ·  " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / 310.0));
        int sweepY = (int) ((now / 12L) % Math.max(1, height));

        // Giga Chad cyberpunk backdrop. Subtle parallax, moving energy streaks and drifting particles animate it.
        // A tiny animated pan gives the background depth without shifting interactive controls.
        int panX = 6 + (int) (Math.sin(now / 1350.0) * 5.0);
        int panY = 4 + (int) (Math.cos(now / 1810.0) * 3.0);
        context.fill(0, 0, width, height, 0xFF05030D);
        context.drawTexture(ANIME_BG, -panX, -panY, width + 12, height + 8,
                0.0F, 0.0F, 1024, 576, 1024, 576);
        // Dark glass tint preserves readability while keeping the Giga Chad art visible.
        context.fill(0, 0, width, height, 0x93000614);
        context.fill(0, sweepY, width, Math.min(height, sweepY + 2), 0x405F28FF);
        for (int i = 0; i < 15; i++) {
            int px = Math.floorMod(i * 113 + (int) (now / (23L + i % 3)), Math.max(1, width));
            int py = Math.floorMod(i * 47 + (int) (now / (31L + i % 4)), Math.max(1, height));
            int size = 1 + (i % 3 == 0 ? 1 : 0);
            context.fill(px, py, px + size, py + size, i % 2 == 0 ? 0xA86F32FF : 0xA8C07AFF);
        }

        // Main glass-like frame and dedicated sidebar.
        context.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0x88000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xED090E1A);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFF39C7FF);
        context.fill(panelX, panelY + panelH - 2, panelX + panelW, panelY + panelH, 0xFF9C69FF);
        context.fill(panelX, panelY, panelX + 2, panelY + panelH, 0xFF39C7FF);
        context.fill(panelX + panelW - 2, panelY, panelX + panelW, panelY + panelH, 0xFF9C69FF);
        context.fill(panelX + 1, panelY + 1, panelX + sideW, panelY + panelH - 1, 0xF20B1222);
        context.fill(panelX + sideW, panelY + 1, panelX + sideW + 1, panelY + panelH - 1, 0x8039C7FF);

        int logoSize = 42;
        int logoX = panelX + (sideW - logoSize) / 2;
        int logoY = panelY + 17;
        context.fill(logoX - 3, logoY - 3, logoX + logoSize + 3, logoY + logoSize + 3,
                0x5039C7FF | ((int) (pulse * 0x28) << 24));
        // 11-argument overload scales the full logo texture; the short overload only crops a corner.
        context.drawTexture(L_LOGO, logoX, logoY, logoSize, logoSize,
                0.0F, 0.0F, 128, 128, 128, 128);
        context.drawCenteredTextWithShadow(textRenderer, "DAMN SON", panelX + sideW / 2, panelY + 67, 0xFFF4F7FF);
        context.drawCenteredTextWithShadow(textRenderer, "CLIENT", panelX + sideW / 2, panelY + 80, 0xFF9BC5E8);

        int navY = panelY + 124;
        context.fill(panelX + 10, navY, panelX + sideW - 10, navY + 31, 0xFF162840);
        context.fill(panelX + 10, navY, panelX + 12, navY + 31, 0xFF45CEFF);
        context.drawTextWithShadow(textRenderer, "▣  COMBAT", panelX + 20, navY + 11, 0xFFCBF2FF);
        context.drawTextWithShadow(textRenderer, "AIM ASSIST", panelX + 20, navY + 51, 0xFF8DA6C4);
        context.drawTextWithShadow(textRenderer, "TRIGGER BOT", panelX + 20, navY + 73, 0xFF8DA6C4);
        context.drawTextWithShadow(textRenderer, "SHIELD BREAKER", panelX + 20, navY + 95, 0xFF8DA6C4);
        context.fill(panelX + 15, panelY + panelH - 48, panelX + sideW - 15, panelY + panelH - 47, 0x5539C7FF);
        context.drawCenteredTextWithShadow(textRenderer, "v1.3", panelX + sideW / 2, panelY + panelH - 35, 0xFF6F8AA8);

        // Header area.
        context.drawTextWithShadow(textRenderer, "COMBAT SUITE", contentX, panelY + 20, 0xFFF3F7FF);
        context.drawTextWithShadow(textRenderer, "PRACTICE MODULES  /  LOCAL WORLD", contentX, panelY + 39, 0xFF8EA6C6);
        int statusX = panelX + panelW - 142;
        context.fill(statusX, panelY + 21, statusX + 8, panelY + 29,
                0xFF5EF0B2 | ((int) (pulse * 0x22) << 24));
        context.drawTextWithShadow(textRenderer, "READY", statusX + 14, panelY + 20, 0xFF9AF7CF);
        context.drawTextWithShadow(textRenderer, "RIGHT SHIFT  ·  MENU", statusX - 22, panelY + 39, 0xFF7D91AE);

        // Cards.
        drawCard(context, aimX, cardY, aimW, contentH, 0xFF47CFFF, "01", "AIM ASSIST");
        drawCard(context, sideX, cardY, sideWCard, sideTopH, 0xFF47CFFF, "02", "TRIGGER BOT");
        drawCard(context, sideX, sideBottomY, sideWCard, sideBottomH, 0xFFB28AFF, "03", "SHIELD BREAKER");

        int smallLine = 0xFF839CB9;
        context.drawTextWithShadow(textRenderer, "SMOOTH TRACKING  ·  PRACTICE ONLY",
                aimX + 13, cardY + contentH - 22, smallLine);
        context.drawTextWithShadow(textRenderer, "VANILLA COOLDOWN",
                sideX + 12, cardY + sideTopH - 23, smallLine);
        context.drawTextWithShadow(textRenderer, "RANGE 3.0 BLOCKS MAX",
                sideX + 12, sideBottomY + sideBottomH - 23, 0xFFC0A4FF);

        // Moving energy sweep over the content; controls are drawn after this, so click regions stay aligned.
        int beamX = panelX + (int) ((now / 7L) % Math.max(1, panelW));
        context.fill(Math.max(panelX, beamX - 26), panelY + 2, Math.min(panelX + panelW, beamX + 26), panelY + 4,
                0x306F29FF | ((int) (pulse * 0x28) << 24));
        if (!listeningFor.isEmpty()) {
            context.fill(contentX, panelY + panelH - 29, contentX + 205, panelY + panelH - 10, 0xF0251D31);
            context.drawTextWithShadow(textRenderer, "PRESS A KEY  ·  ESC = DEFAULT", contentX + 7,
                    panelY + panelH - 23, 0xFFFFD27A);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawCard(DrawContext context, int x, int y, int w, int h, int accent, String number, String title) {
        float pulse = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 340.0));
        context.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x67000000);
        context.fill(x, y, x + w, y + h, 0xE8111929);
        context.fill(x, y, x + w, y + 2, accent);
        context.fill(x, y + 2, x + 2, y + h, (accent & 0x00FFFFFF) | ((int) (0xA0 + pulse * 0x30) << 24));
        context.drawTextWithShadow(textRenderer, number, x + 12, y + 13, accent);
        context.drawTextWithShadow(textRenderer, title, x + 35, y + 13, 0xFFF0F5FF);
        context.fill(x + 12, y + 31, x + w - 12, y + 32, 0x2F8AA9CB);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double settingValue;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(), (Math.max(min, Math.min(max, initial)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.settingValue = clamp(initial);
            updateMessage();
        }

        private double clamp(double value) {
            if (Double.isNaN(value) || Double.isInfinite(value)) return min;
            return Math.max(min, Math.min(max, value));
        }

        @Override
        protected void updateMessage() {
            String shown = settingValue == Math.rint(settingValue)
                    ? Integer.toString((int) settingValue)
                    : String.format(java.util.Locale.ROOT, "%.1f", settingValue);
            setMessage(Text.literal(label + "  ·  " + shown));
        }

        @Override
        protected void applyValue() {
            settingValue = clamp(min + (max - min) * this.value);
            setter.accept(settingValue);
            updateMessage();
        }
    }
}
