# Lumina — Fabric 1.21 (selected modules)

This source package registers only these feature modules in the GUI:

- **AimAssist** — defaults based on the visible AimAssist settings in the supplied gameplay recording: Range 4.5, Speed 10, Max Speed 15, FOV 175, Focus Mode on, Weapon Only on, Head aim point, Players target mode. Camera updates use one controller and filtered target coordinates to reduce jitter. There is no randomization or anti-cheat evasion setting.
- **TriggerBot** — acts on a valid living entity already under the crosshair, subject to cooldown/weapon/item-use settings.
- **AutoPot** — supports healing and optional strength potions, splash throws/drinking paths, and deferred hotbar refill. Refill matches the exact potion contents as well as the item form so regeneration is not swapped into an instant-health slot by mistake.
- **ESP** — selected client-side entity outlines.
- **Bypass** — retained as a compatibility/status placeholder only. Client-brand spoofing, channel hiding, action jitter, and claims of server anti-cheat evasion have been removed.

`ThemeModule` and `HudModule` remain as internal UI support objects but are not registered as feature modules in the GUI. Other modules and their associated mixins have been removed from this source package.

## Build

Requirements: JDK 21 and Gradle 8.10.2. Run:

```sh
gradle --no-daemon clean build
```

The resulting JAR is placed under `build/libs/`. The GitHub Actions workflow builds on pushes to `main`/`master` and manual dispatch, then uploads `build/libs/*.jar` as an artifact.

## Validation

The source bundle has been checked for ZIP integrity and JSON metadata. A full Gradle compile must still be run in GitHub Actions or an environment with Gradle/Minecraft dependencies available; no successful full build is claimed here.
