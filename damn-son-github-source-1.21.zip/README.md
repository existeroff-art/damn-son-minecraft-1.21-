# Damn Son — Fabric 1.21 client mod

Requires JDK 21 and Gradle 8.10.2.

Build from repository root:
```bash
gradle --no-daemon clean build
```

UI update: dark anime-inspired styling, cyan/purple accents, subtle pulsing header, module-toggle click sounds, and existing Right Shift menu binding/settings retained.

Build and in-game behavior have not yet been verified.
