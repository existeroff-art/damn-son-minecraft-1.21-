# Lumina (Fabric 1.21)

## Build

Requirements: JDK 21 and Gradle 8.10.2. This folder is a Gradle project; open it directly in IntelliJ or run:

```sh
gradle --no-daemon clean build
```

The mod JAR is created under `build/libs/`. Install it in `.minecraft/mods` with Fabric API `0.102.0+1.21` and Fabric Loader `0.16+`.

The included GitHub Actions workflow builds the project on pushes to `main`/`master` and on manual workflow dispatch, then uploads the JAR as the `lumina-fabric-1.21` artifact.

## Use

- **Right Shift** opens the menu.
- Click a module to open its settings, click the switch (or right-click) to toggle it.
- Mode pills: left click = next, right click = previous.
- Keybind row inside each module: click, then press a key (Esc/Backspace clears).
- Accent colors and panel opacity live in Util -> Theme.
- Config is stored in `.minecraft/config/lumina.json`.

## Updated modules

- **AimAssist:** sticky target acquisition, short capped velocity lead, a low-pass filtered aim point, damped rotation, and smaller bounded yaw/pitch steps to reduce jitter. Rotation pauses cleanly while pot/pearl/mace sequences own the camera.
- **Aura + AimAssist:** when both are enabled, Aura reuses AimAssist's locked target and no longer writes a competing camera rotation. Use either module alone or both together; if AimAssist is enabled, its lock controls Aura's attack target.
- **AutoPot:** sends splash/lingering potions once through the item interaction rather than repeatedly holding use; pitch is held downward for a client tick. Refill waits for inventory synchronization, confirms the target slot, retries, and matches the exact item kind plus potion purpose so a splash potion is not replaced by a drinkable one. It checks main inventory and other hotbar slots.
- **ESP:** uses a client-side `Entity.isGlowing` mixin for filtered outline rendering, avoiding a glow flag that server metadata can overwrite. The render-time lookup avoids mutating unrelated entity state.
- **AnchorMacro and TriggerBot:** retained.
- **Auto Mace:** non-elytra sequence: keeps one target for the combo, optionally sends an axe hit when the target is actively blocking, uses a wind charge downward, waits for ascent/descent, selects the mace and attacks during the fall without rotating the camera toward the target. It uses vanilla attack/use calls and a conservative reach check; server-side validation can still reject automated attacks.
- **Mace Swap:** retained, but the module now disables the other mace selector when enabled so the two modules do not fight over the hotbar slot.
- **Pearl Catch:** watches the selected pearl stack for a throw, waits the configured delay, then waits a bounded number of extra ticks for the client projectile entity before aiming. It prefers the owned pearl, falls back to a nearby owner-less projectile only when its path matches the recorded throw direction, and otherwise uses the saved launch direction. It sends one wind-charge use and restores the camera/hotbar; timing/collision remains dependent on game physics and server behavior.

The modules **Snap Tap**, **Fast Gapple**, **CrystalMacro**, **PvP Macros**, and **Mace Windcharge** are not present. Snap Tap mixins were removed from the mixin config.

## Validation notes

The source archive has been checked for ZIP integrity, valid JSON metadata, and Java syntax parsing. A full Gradle dependency-resolved build was not runnable in the editing environment because Gradle is not installed and outbound DNS/network access is unavailable; use the included GitHub Actions workflow to verify the actual mapped Minecraft compile.
