# Damn Son Client 0.6.6 (Minecraft 1.21 / Fabric)

This source archive contains a Fabric client utility mod with a redesigned flat/dark module menu, configurable module keybinds, distinct enable/disable sounds, Snap Tap movement behavior, HUD utilities, and optional Fast Gapple support.

## Build

Use Java 21 and Gradle 8.10.2. Run `gradle --no-daemon clean build` from this directory. The workflow in `.github/workflows/build.yml` builds the project and uploads a JAR artifact.

## Menu and controls

- **Right Shift** opens/closes the GUI.
- Each module row has its own configurable keybind.
- Settings persist in `config/damn-son.json`.
- The GigaChad/anime menu background and logo are removed; the new UI uses a compact dark layout, teal/purple accents, hover states, and separate enabled/disabled sounds.
- **Anti-KB** uses a fixed practice profile (50% horizontal velocity retained, 100% vertical velocity retained) and remains restricted to a solo integrated world. Only its toggle keybind is user-facing.
- **Aim Assist** and **Trigger Bot** are practice-only and target non-player mobs; they do not auto-target or auto-attack real players. Both require a sword, axe, mace, or trident in the main hand.
- **Snap Tap** applies last-input priority to opposing WASD keys; check server rules before use.
- **Fast Gapple** requires a server-side Damn Son installation and server opt-in; a client cannot force vanilla servers to accept faster eating.

## Compatibility and safety notes

There is no universal anti-cheat-safe Anti-KB setting. This project does not attempt to evade server-side checks, and does not implement automated targeting or attacking against multiplayer players. Some servers may disallow Snap Tap. Fast Gapple only changes server behavior when the server supports the matching payload.

## Build status

JSON metadata, module IDs, mixin class references, source references, and ZIP integrity were statically checked. Gradle is not installed in the authoring environment, so compilation and in-game tests have not been run locally. Validate the source with the included GitHub Actions workflow before using it.
