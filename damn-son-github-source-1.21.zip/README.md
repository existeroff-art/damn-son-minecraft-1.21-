# Damn Son Client — Fabric 1.21

An original Minecraft Java client-side mod with a dark animated ClickGUI. The design is inspired by common client menus; this is not a byte-for-byte or source-code clone of Remu Client.

## Requirements

- Minecraft Java Edition 1.21
- Fabric Loader 0.16.5 or newer
- Fabric API for Minecraft 1.21
- Java 21 to build

## Modules

The menu currently provides 22 modules in six categories:

- **Combat:** Aim Assist, Trigger Bot, Shield Breaker. These combat-practice helpers run only in a solo single-player world; they intentionally do nothing in multiplayer/LAN sessions.
- **Movement:** Auto Sprint, Auto Jump.
- **Render:** Fullbright (maximum vanilla gamma), Zoom (30 FOV while enabled).
- **Player:** Auto Eat, Auto Tool, Auto Respawn.
- **HUD:** FPS, Coordinates/Dimension, Keystrokes, Armor Durability, Ping, Biome, Direction, Speed, World Clock, Watermark, Active Modules.
- **Misc:** Toggle Sneak.

Each module row has an ON/OFF toggle and a keybind button. Use mouse-wheel scrolling or the up/down buttons to browse longer categories. Open the GUI with **Right Shift**. In a module's settings page, Aim Assist and Shield Breaker have adjustable settings. Settings are stored at `.minecraft/config/damn-son.json`.

## Build

The GitHub Actions workflow in `.github/workflows/build.yml` builds the root project with Java 21 and Gradle 8.10.2, then uploads a JAR artifact. Locally, run `gradle --no-daemon clean build` from the extracted project root after installing Java 21 and Gradle 8.10.2.

## Validation status

This archive has been checked for ZIP integrity, required resources, valid JSON, and matching source layout. A Gradle compilation and in-game test could not be run in the current environment because Gradle is unavailable and network DNS is disabled. Therefore this archive is source code, not a confirmed compiled JAR.
