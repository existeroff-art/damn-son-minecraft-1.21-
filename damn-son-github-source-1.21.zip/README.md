# Damn Son — Fabric 1.21 client mod

Requires JDK 21 and Gradle 8.10.2.

Build from repository root:
```bash
gradle --no-daemon clean build
```

UI update: dark anime-inspired styling, cyan/purple accents, subtle pulsing header, module-toggle click sounds, and existing Right Shift menu binding/settings retained.

Build and in-game behavior have not yet been verified.


## UI and module hotkeys
- Press Right Shift to open/close the settings UI.
- The UI includes the bundled L logo and cyan/purple animated accents.
- Click **AA Key** or **TB Key**, then press a key to assign a toggle hotkey (Escape cancels). Defaults: R for Aim Assist and V for Trigger Bot.
- Hotkeys and settings are saved to `config/damn-son.json`.
- Combat helpers remain restricted to single-player practice targets; this project does not enable automated targeting/attacks against multiplayer players.
