# Damn Son — Fabric 1.21 client mod

Minecraft Java **1.21**, Fabric Loader, Java 21. The source project contains a Vegeta-themed animated menu and a separate L portrait logo used as the Fabric mod-list icon.

## Controls

- **Right Shift** opens/closes the menu.
- **R** toggles Aim Assist and **V** toggles Trigger Bot by default.
- In the menu, click **AA Key** or **TB Key**, then press another key to rebind. Escape cancels.
- Settings save to `config/damn-son.json`.

## UI and behavior

- Animated Vegeta background with dark overlay, neon cyan/purple frame, moving scan beam, and L logo.
- Separate `assets/damnson/icon.png` mod icon.
- Aim Assist uses eased rotation updates, configurable range/smoothness/maximum step/FOV/aim point, and a target-lock preference.
- Trigger Bot checks the crosshair target, optional range/weapon/critical-only settings, configured delay, and vanilla attack cooldown.
- Weapon-only filters default off so testing does not silently fail when the player is not holding a sword or axe. Existing config files are migrated once.
- The Target Players option enables player-entity targeting. Use automation only where it is permitted by the server's rules.

## Build

The GitHub Actions workflow uses Java 21 and Gradle 8.10.2. Push the extracted source files to a repository and run **Actions → Build Damn Son Fabric Mod**. On success, download the `damn-son-minecraft-1.21` artifact.

Local build, if Gradle 8.10.2 is installed:

```sh
gradle --no-daemon clean build
```

The generated JAR is under `build/libs/`; do not use the `-sources.jar` or `-dev.jar` as the game mod.

## Verification status

This environment has Java 21 but no Gradle installation and cannot resolve the Gradle distribution host, so a Gradle compile and in-game launch were not possible here. Treat the archive as source-updated, not as a successfully compiled build; use the included Actions workflow to verify compilation.
