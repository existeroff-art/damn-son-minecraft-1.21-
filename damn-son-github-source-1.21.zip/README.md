# Damn Son Client — Fabric 1.21 (source)

An original client-side Minecraft utility mod with an animated neon ClickGUI.

## Requirements

- Minecraft Java Edition 1.21
- Fabric Loader 0.16.5 or newer
- Fabric API for Minecraft 1.21
- Java 21 to build
- Gradle 8.10.2 (or use the included GitHub Actions workflow)

## Modules

- **Combat practice (single-player only):** Anti-KB with horizontal/vertical retained-velocity sliders; Aim Assist against nearby non-player mobs with range/strength sliders; Trigger Bot against a non-player mob already under the crosshair with a range slider. These modules are intentionally disabled outside an integrated single-player world and never target player entities.
- **Movement:** Auto Sprint, Auto Jump.
- **Render:** Fullbright, Zoom.
- **Player:** Auto Eat, Auto Tool, Auto Respawn.
- **HUD:** FPS, Coordinates/Dimension, Keystrokes, Armor Durability, Ping, Biome, Direction, Speed, World Clock, Watermark, Active Modules.
- **Misc:** Toggle Sneak.

Open the menu with **Right Shift**. Every module has an ON/OFF toggle and configurable keybind, and module changes use toggle sounds. Settings are stored at `.minecraft/config/damn-son.json`; **SAVE** writes settings and **LOAD** reads them back.

## Practice-only combat behavior

Combat practice helpers run only when Minecraft is in an integrated single-player world. Aim Assist only considers living non-player entities inside the configured range and a limited field of view. Trigger Bot only interacts with a living non-player entity already under the crosshair and waits for the normal attack cooldown. Anti-KB only scales the local player's velocity update in single-player. Multiplayer velocity changes, automated aim, and automated attacks are intentionally not implemented. This project does not include server anti-cheat bypass or stealth/detection-evasion logic.

## Build

Run `gradle --no-daemon clean build` from the extracted root with Java 21 and Gradle 8.10.2. The GitHub Actions workflow builds the root project and uploads the remapped JAR artifact.

## Validation status

Source checks include ZIP integrity, required assets, metadata, mixin configuration, unique module IDs, practice-only guards, and source structure. A Gradle compilation and in-game test could not be executed in the authoring environment because Gradle is not installed. This is a source ZIP, not a newly compiled JAR.
