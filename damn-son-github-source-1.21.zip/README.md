# Damn Son — Minecraft 1.21 Fabric source

The Gradle project is located in `project/`. The GitHub Actions workflow at `.github/workflows/build.yml` intentionally runs `gradle --no-daemon -p project clean build`, matching that layout.

## Build locally

Requirements: JDK 21 and Gradle 8.10.2.

```sh
gradle --no-daemon -p project clean build
```

The workflow uploads `damn-son-1.21.jar` as a build artifact. The source has not been compiled in this environment, so the first successful GitHub Actions run is the build verification.


GitHub Actions now detects the Gradle project in the repository root, `project/`, or `project/project/`, so importing the ZIP with an extra folder level does not cause the previous “does not contain a Gradle build” error.
