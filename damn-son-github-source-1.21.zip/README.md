# Damn Son — Fabric 1.21 client mod

Requires JDK 21 and Gradle 8.10.2.

Build from repository root:
```bash
gradle --no-daemon clean build
```

UI update: dark anime-inspired styling, cyan/purple accents, subtle pulsing header, module-toggle click sounds, and existing Right Shift menu binding/settings retained.

Build and in-game behavior have not yet been verified.


## UI and module hotkeys
- Press Right Shift to open/close the settings UI.
- The UI includes the bundled L logo and cyan/purple animated accents.
- Click **AA Key** or **TB Key**, then press a key to assign a toggle hotkey (Escape cancels). Defaults: R for Aim Assist and V for Trigger Bot.
- Hotkeys and settings are saved to `config/damn-son.json`.
- Combat helpers remain restricted to single-player practice targets; this project does not enable automated targeting/attacks against multiplayer players.


## Visual update
- Vegeta artwork is used as the GUI background.
- The L image is used as the mod/menu logo.
- Aim Assist and Trigger Bot player-target practice is restricted to single-player worlds; hostile mobs remain supported.
- This archive has not been verified by a successful Gradle build in this environment.


Player targeting is enabled by default for single-player practice worlds. The combat helpers deliberately do not target player entities in multiplayer worlds. Smooth aim uses eased rotation updates; build and in-game behavior still need to be verified in your GitHub Actions run.
