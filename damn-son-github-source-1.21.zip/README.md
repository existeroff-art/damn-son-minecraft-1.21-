# Lumina (Fabric 1.21)

## Build
Requirements: JDK 21 and Gradle 8.10.2 (or open the extracted folder in IntelliJ and import the Gradle project).

    gradle --no-daemon clean build

The mod jar is created under `build/libs/`. Install it in `.minecraft/mods` with Fabric API `0.102.0+1.21` and Fabric Loader `0.16+`.
The repository-level ZIP build workflow should extract this archive into its project directory, run `gradle --no-daemon clean build`, and publish the resulting JAR.

## Use
- **Right Shift** opens the menu.
- Click a module to open its settings, click the switch (or right-click) to toggle it.
- Mode pills: left click = next, right click = previous.
- Keybind row inside each module: click, then press a key (Esc/Backspace clears).
- Accent colors and panel opacity live in Util -> Theme.
- Config is stored in `.minecraft/config/lumina.json`.

## Updated modules

- **AimAssist:** holds one target until that target becomes invalid or AimAssist is toggled off/on. It no longer switches to a different nearby entity just because that entity briefly comes closer to the crosshair. Rotation uses exponential smoothing and a stable upper-torso aim point.
- **AutoPot:** handles drinkable potions as a hold-to-drink state and splash/lingering potions as a throw. Splash potions temporarily pitch downward so healing lands near the player's feet. The refill setting swaps a matching potion from inventory into the used hotbar slot.
- **ESP:** tracks the original glow state and restores it when an entity stops matching the filters or the module is disabled. It no longer clears glow on entities that were already glowing before ESP was enabled.
- **AnchorMacro and TriggerBot:** retained unchanged as requested.
- **Mace Swap:** retained. It selects the mace during a fall based on the configured fall distance.
- **Auto Mace:** a target-aware mace selector; it switches when descending and the crosshair is on a valid player within range. Use this or Mace Swap depending on the behavior you prefer.
- **Pearl Catch:** detects an ender-pearl throw, waits the configured number of ticks, then uses a hotbar wind charge while preserving the current aim direction. Projectile collisions depend on timing, trajectory, Minecraft mechanics, and server rules, so a combo is not guaranteed to connect on every attempt.

Removed from the module list and source: **Snap Tap**, **Fast Gapple**, **CrystalMacro**, **PvP Macros**, and **Mace Windcharge**. Snap Tap's input mixins were also removed from the mixin config.

## Limitations

The linked YouTube pages were reachable only far enough to retrieve their titles; the full videos and exact module behavior were not available to inspect. The uploaded gameplay recording was inspected, and the aim-assist changes above address target switching and excessive rotation jitter. This source package has been statically checked, but a Gradle build could not be run in this environment because Gradle is not installed and outbound DNS/network access is unavailable. The included GitHub Actions workflow can perform the real dependency-resolved build.
