# Damn Son — Fabric 1.21 Practice Client

A client-side Fabric mod for Minecraft Java 1.21 / Java 21 with a dark, Giga Chad-inspired animated configuration screen and local single-player practice helpers.

## Controls

- **Right Shift** — open/close the menu
- **R** — Aim Assist toggle (default)
- **V** — Trigger Bot toggle (default)
- **B** — Shield Breaker toggle (default)
- Each module has a configurable key in the menu. While listening for a key, press **Escape** to restore that module's default (R, V, or B).

## UI and settings

- Giga Chad-inspired cyberpunk backdrop with subtle animated parallax, pulsing scan lines, drifting particles and violet energy streaks (not the old Vegeta background).
- The L portrait is used in the menu header and as the actual Fabric mod-list icon.
- Aim Assist exposes range, smoothness, maximum turn step, FOV, aim point, and player-target toggle.
- Trigger Bot has only its module toggle and keybind in the UI; it uses built-in practice defaults and checks vanilla attack cooldown.
- Shield Breaker has a 1–3 block range control (default 3) and its own keybind.
- Legacy config values that could silently gate practice mode are migrated/ignored.

## Practice-mode boundary

Combat helpers run only in a local single-player world and pause if another player joins that integrated world through LAN. They do not automate aim or attacks on multiplayer servers. They target visible practice entities and respect vanilla attack cooldown.

## Build

This repository includes `.github/workflows/build.yml` to build with Java 21 and Gradle 8.10.2 and upload the resulting JAR as a workflow artifact. Run the workflow manually from GitHub Actions after pushing the extracted project files.

A local Gradle build was **not** available in the authoring environment (Gradle is not installed and downloading dependencies was unavailable), so the source has not been confirmed by a completed Gradle compile or an in-game run.
