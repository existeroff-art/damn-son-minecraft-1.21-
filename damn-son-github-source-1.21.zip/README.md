# Damn Son — Minecraft Java 1.21 (Fabric)

**Target:** Minecraft Java Edition **1.21 exactly** (not 1.21.1), Fabric, Java 21.

## What this source currently contains

- Right Shift menu key.
- AA and TB setting toggles, sliders and JSON configuration persistence.
- Settings modeled from the uploaded reference video: AA Range 6, Speed 10, Max Speed 15, FOV 175, Humanize ON, Focus Mode ON, Smart Bypass ON, Only Weapon ON, Aim Point HEAD, Target Mode PLAYERS.
- The reference video’s TB panel was collapsed / values were not readable, so TB defaults (Range 4, Delay 120 ms, Only Weapon ON, Players Only ON) are clearly chosen defaults, not claimed video values.
- GitHub Actions workflow at `.github/workflows/build.yml` that compiles the project and uploads a JAR artifact when the build succeeds.

## Important status — read before installing

This is a **starter GUI/config project**. AA/TB settings and UI are present, but complete AA/TB gameplay behavior is **not implemented or runtime-verified** in this source. The GitHub workflow can compile the current source and package its JAR; a successful build does **not** mean the gameplay modules are finished. Keep use limited to your own single-player world. This project does not implement multiplayer anti-cheat bypass.

## Build from GitHub using an Android phone

### A. Create the repository

1. Open https://github.com and sign in.
2. Tap **+** → **New repository**.
3. Name it `damn-son-minecraft-1.21`, select **Public** or **Private**, and create it.
4. On your phone, download and extract this source ZIP using the Files app.
5. Open the new repository and use **Add file → Upload files** to upload the *contents* of the extracted `damn-son` project folder. Keep paths/folders intact. Do not upload only the ZIP if you want the included workflow to run automatically.
6. Commit the upload to `main`.

### B. Run the automatic build

1. In the repository, open the **Actions** tab.
2. If GitHub asks to enable Actions, enable them.
3. Open **Build Damn Son Fabric Mod**. If it has not run automatically, open the workflow and choose **Run workflow**.
4. Wait for the run to finish. Green means Gradle completed; red means the build failed and the logs show the actual error.
5. Open the successful run, scroll to **Artifacts**, and download `damn-son-minecraft-1.21`.
6. Extract that artifact. It should include `damn-son-1.21.jar`. This is the current starter build, not a finished AA/TB gameplay implementation.

### C. Install the JAR

1. Use a Minecraft Java 1.21 installation with Fabric Loader and Fabric API for **1.21**.
2. Put `damn-son-1.21.jar` into that installation's `.minecraft/mods` folder.
3. Launch that exact 1.21 Fabric profile. Do not use a 1.21.1 profile for this project.

## Build locally (PC or Termux with Java 21 and Gradle)

From the project root:

```bash
gradle --no-daemon clean build
```

The standard output is in `build/libs/`. GitHub Actions also creates a named copy `damn-son-1.21.jar` in its downloadable artifact.

## Settings file

Configuration is stored at `.minecraft/config/damn-son.json`.

## Build limitations

No build is claimed to have passed from this editing environment. Verify the actual GitHub Actions result before installing. A successful compile only validates compilation; implement and test the actual local single-player AA/TB logic separately before treating those features as functional.
