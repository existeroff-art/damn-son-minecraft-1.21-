# Damn Son Client — Fabric 1.21 (source)

An original client-side Minecraft utility mod with an animated neon ClickGUI.

## Requirements

- Minecraft Java Edition 1.21
- Fabric Loader 0.16.5 or newer
- Fabric API for Minecraft 1.21
- Java 21 to build
- Gradle 8.10.2 (or use the included GitHub Actions workflow)

## Modules

- **Combat utility:** Anti-KB with configurable retained horizontal and vertical velocity percentages. The packet hook runs in single-player and multiplayer worlds.
- **Movement:** Auto Sprint, Auto Jump.
- **Render:** Fullbright, Zoom.
- **Player:** Auto Eat, Auto Tool, Auto Respawn.
- **HUD:** FPS, Coordinates/Dimension, Keystrokes, Armor Durability, Ping, Biome, Direction, Speed, World Clock, Watermark, Active Modules.
- **Misc:** Toggle Sneak.

Open the menu with **Right Shift**. Every module has an ON/OFF toggle and configurable keybind, and module changes use toggle sounds. Settings are stored at `.minecraft/config/damn-son.json`; **SAVE** writes settings and **LOAD** reads them back. Anti-KB settings are available from the module settings page; lower retained-velocity percentages suppress more of the local velocity update. The initial default is 0% horizontal and 0% vertical.

## Anti-KB behavior and limitations

Anti-KB scales the local player's velocity after a matching `EntityVelocityUpdateS2CPacket` is handled. The guard checks for a valid local player/world and confirms that the packet belongs to the local player; it does not reject multiplayer sessions. This is client-side behavior only. A multiplayer server may apply corrections, override movement, or disallow such modifications. This code does not claim to bypass server checks, and effectiveness can vary by server and protocol/mod setup.

## Build

Run `gradle --no-daemon clean build` from the extracted root with Java 21 and Gradle 8.10.2. The GitHub Actions workflow builds the root project and uploads the remapped JAR artifact.

## Validation status

The source archive checks verify ZIP integrity, required assets, metadata, mixin configuration, unique module IDs and source structure. A Gradle compilation and in-game test were not executed in this environment because Gradle is not installed and dependency/network access is unavailable. This is a source ZIP, not a compiled JAR.
