package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputSnapTapMixin {
    private static boolean damnson$wasLeft;
    private static boolean damnson$wasRight;
    private static boolean damnson$wasForward;
    private static boolean damnson$wasBack;
    private static long damnson$sequence;
    private static long damnson$leftOrder;
    private static long damnson$rightOrder;
    private static long damnson$forwardOrder;
    private static long damnson$backOrder;

    @Inject(method = "tick", at = @At("TAIL"))
    private void damnson$applySnapTap(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        Input input = (Input) (Object) this;
        if (client == null || client.currentScreen != null || !ModuleSettings.get().enabled("snap_tap")) {
            damnson$reset();
            return;
        }

        if (input.pressingLeft && !damnson$wasLeft) damnson$leftOrder = ++damnson$sequence;
        if (input.pressingRight && !damnson$wasRight) damnson$rightOrder = ++damnson$sequence;
        if (input.pressingForward && !damnson$wasForward) damnson$forwardOrder = ++damnson$sequence;
        if (input.pressingBack && !damnson$wasBack) damnson$backOrder = ++damnson$sequence;

        if (input.pressingLeft && input.pressingRight) {
            input.movementSideways = (damnson$leftOrder > damnson$rightOrder ? 1.0F : -1.0F)
                    * (slowDown ? slowDownFactor : 1.0F);
        }
        if (input.pressingForward && input.pressingBack) {
            input.movementForward = (damnson$forwardOrder > damnson$backOrder ? 1.0F : -1.0F)
                    * (slowDown ? slowDownFactor : 1.0F);
        }

        damnson$wasLeft = input.pressingLeft;
        damnson$wasRight = input.pressingRight;
        damnson$wasForward = input.pressingForward;
        damnson$wasBack = input.pressingBack;
    }

    private static void damnson$reset() {
        damnson$wasLeft = false;
        damnson$wasRight = false;
        damnson$wasForward = false;
        damnson$wasBack = false;
        damnson$leftOrder = 0;
        damnson$rightOrder = 0;
        damnson$forwardOrder = 0;
        damnson$backOrder = 0;
    }
}
