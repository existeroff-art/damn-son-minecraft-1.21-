package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Rockstar 2.0 style client menu.
 *
 * Layout: floating multi-column overlay — one column per category, all visible simultaneously.
 * Left-click module  → toggle on/off
 * Right-click module → open settings panel (replaces the rightmost column slot)
 * Scroll on column   → scroll that column's module list
 * ESC / RShift       → close
 */
public final class DamnSonScreen extends Screen {

    // ── Colours ────────────────────────────────────────────────────────────
    private static final int C_BACKDROP   = 0xB2050910;
    private static final int C_GRID       = 0x0A8AACCC;
    private static final int C_COL_BG     = 0xE3080D18;
    private static final int C_COL_HDR    = 0xFF0B1320;
    private static final int C_HDR_ACCENT = 0xFF4DD4C4; // teal
    private static final int C_HDR_LINE   = 0xFF192638;
    private static final int C_ROW_HOVER  = 0xFF111D2B;
    private static final int C_ROW_ON     = 0xFF0C2220; // enabled row bg
    private static final int C_BORDER     = 0xFF1A2B3E;
    private static final int C_TEXT       = 0xFFE2EDF8;
    private static final int C_MUTED      = 0xFF5C7490;
    private static final int C_CHECK      = 0xFF4DD4C4; // enabled checkmark colour
    private static final int C_ARROW      = 0xFF7B68EE; // settings arrow colour
    private static final int C_ON_LABEL   = 0xFF8FFAE0;
    private static final int C_CLOSE_BG   = 0xE0120810;
    private static final int C_CLOSE_LINE = 0xFF7B2233;
    private static final int C_SAVE_BG    = 0xE0091812;
    private static final int C_SAVE_LINE  = 0xFF2A6A5A;

    // category header icons (single chars, MC font supports these)
    private static final String[] CAT_ICONS = { "✦", "↑", "◈", "♦", "…" };
    private static final String[] CAT_LABELS = ModuleCatalog.CATEGORIES; // COMBAT MOVEMENT VISUALS PLAYER OTHER

    // ── Layout constants ───────────────────────────────────────────────────
    private static final int COL_W      = 168;  // column width px
    private static final int COL_GAP    = 3;    // gap between columns
    private static final int HDR_H      = 42;   // header height
    private static final int ROW_H      = 21;   // module row height
    private static final int COL_PAD_X  = 9;    // inner horizontal padding
    private static final int TOP_MARGIN = 28;   // distance from top of screen
    private static final int BOT_RESERVE= 38;   // footer bar height
    private static final int COL_RADIUS = 2;    // corner rounding approximation (drawn as fills)
    private static final int SETTINGS_W = 200;  // settings panel width

    // ── State ──────────────────────────────────────────────────────────────
    private final ModuleSettings cfg = ModuleSettings.get();
    private final int[] scrollOffsets = new int[CAT_LABELS.length];
    private String settingsModuleId = null;  // null = no settings panel open
    private String listeningForKeybind = ""; // module id we're capturing a key for

    // ── Derived layout (computed in init) ─────────────────────────────────
    private int totalW, startX, startY, colH, visibleRows;

    public DamnSonScreen() { super(Text.literal("Damn Son")); }

    @Override
    protected void init() {
        int numCols = CAT_LABELS.length;
        totalW  = numCols * COL_W + (numCols - 1) * COL_GAP
                + (settingsModuleId != null ? SETTINGS_W + COL_GAP : 0);
        startX  = Math.max(4, (width  - totalW) / 2);
        startY  = TOP_MARGIN;
        colH    = height - startY - BOT_RESERVE;
        visibleRows = Math.max(1, (colH - HDR_H - 6) / ROW_H);
    }

    // ──────────────────────────────────────────────────────────────────────
    //  Render
    // ──────────────────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Full-screen backdrop
        ctx.fill(0, 0, width, height, C_BACKDROP);
        // Subtle grid
        for (int gx = 0; gx < width;  gx += 52) ctx.fill(gx, 0, gx + 1, height, C_GRID);
        for (int gy = 0; gy < height; gy += 52) ctx.fill(0, gy, width,  gy + 1,  C_GRID);

        // Columns
        for (int ci = 0; ci < CAT_LABELS.length; ci++) {
            int cx = startX + ci * (COL_W + COL_GAP);
            renderColumn(ctx, mx, my, ci, cx);
        }

        // Settings panel
        if (settingsModuleId != null) {
            int sx = startX + CAT_LABELS.length * (COL_W + COL_GAP);
            renderSettingsPanel(ctx, mx, my, sx);
        }

        // Footer bar
        renderFooter(ctx, mx, my);

        // Keybind capture banner
        if (!listeningForKeybind.isEmpty()) {
            int bw = 260, bh = 20;
            int bx = (width - bw) / 2;
            int by = height - BOT_RESERVE - 28;
            ctx.fill(bx, by, bx + bw, by + bh, 0xEE261C10);
            ctx.fill(bx, by, bx + bw, by + 1, 0xFFE08020);
            ctx.drawCenteredTextWithShadow(textRenderer, "PRESS A KEY  ·  ESC = UNBIND",
                    bx + bw / 2, by + 6, 0xFFFFD070);
        }

        // Header bar (drawn over columns so it overlays)
        renderHeader(ctx);
    }

    private void renderHeader(DrawContext ctx) {
        // Thin top strip
        ctx.fill(0, 0, width, 22, 0xEE060C16);
        ctx.fill(0, 21, width, 22, 0xFF1A2B3E);

        // Brand
        ctx.drawTextWithShadow(textRenderer, "DAMN SON", 10, 7, 0xFF4DD4C4);
        ctx.drawTextWithShadow(textRenderer, "v0.7.0", 10 + textRenderer.getWidth("DAMN SON") + 6, 7, 0xFF3A5060);

        // Right side: status
        String status = "MULTIPLAYER";
        int sw = textRenderer.getWidth(status);
        ctx.fill(width - sw - 18, 6, width - sw - 12, 12, 0xFF4DD4C4);
        ctx.drawTextWithShadow(textRenderer, status, width - sw - 8, 7, 0xFF4DD4C4);
    }

    private void renderColumn(DrawContext ctx, int mx, int my, int ci, int cx) {
        int cy = startY;
        String cat = CAT_LABELS[ci];
        List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(cat);
        boolean colHovered = mx >= cx && mx < cx + COL_W && my >= cy && my < cy + colH;

        // Column shadow
        ctx.fill(cx + 2, cy + 3, cx + COL_W + 2, cy + colH + 3, 0x55000000);
        // Column body
        ctx.fill(cx, cy, cx + COL_W, cy + colH, C_COL_BG);
        // Left accent bar
        ctx.fill(cx, cy, cx + 2, cy + colH, colHovered ? C_HDR_ACCENT : C_BORDER);
        // Top border
        ctx.fill(cx + 2, cy, cx + COL_W, cy + 1, C_HDR_LINE);
        // Right border
        ctx.fill(cx + COL_W - 1, cy, cx + COL_W, cy + colH, C_BORDER);

        // Header
        ctx.fill(cx + 2, cy + 1, cx + COL_W - 1, cy + HDR_H, C_COL_HDR);
        ctx.fill(cx + 2, cy + HDR_H - 1, cx + COL_W - 1, cy + HDR_H, C_HDR_LINE);

        // Icon
        ctx.drawTextWithShadow(textRenderer, CAT_ICONS[ci], cx + COL_PAD_X, cy + 10, C_HDR_ACCENT);
        // Category name
        ctx.drawTextWithShadow(textRenderer, cat, cx + COL_PAD_X + 12, cy + 10, C_TEXT);
        // Module count
        String countStr = modules.size() + " modules";
        ctx.drawTextWithShadow(textRenderer, countStr, cx + COL_PAD_X, cy + 24, C_MUTED);

        // Module rows
        int maxScroll = Math.max(0, modules.size() - visibleRows);
        scrollOffsets[ci] = Math.max(0, Math.min(scrollOffsets[ci], maxScroll));

        for (int vi = 0; vi < visibleRows; vi++) {
            int idx = vi + scrollOffsets[ci];
            if (idx >= modules.size()) break;
            ModuleCatalog.Module m = modules.get(idx);
            int ry = cy + HDR_H + 3 + vi * ROW_H;
            renderModuleRow(ctx, mx, my, m, cx, ry);
        }

        // Scroll indicator
        if (modules.size() > visibleRows) {
            float progress = (float) scrollOffsets[ci] / maxScroll;
            int barH = colH - HDR_H - 6;
            int thumbH = Math.max(10, barH * visibleRows / modules.size());
            int thumbY = cy + HDR_H + 3 + (int)((barH - thumbH) * progress);
            ctx.fill(cx + COL_W - 3, cy + HDR_H + 3, cx + COL_W - 1, cy + colH - 2, 0xFF101A27);
            ctx.fill(cx + COL_W - 3, thumbY, cx + COL_W - 1, thumbY + thumbH, C_HDR_ACCENT);
        }
    }

    private void renderModuleRow(DrawContext ctx, int mx, int my, ModuleCatalog.Module m,
                                  int cx, int ry) {
        boolean enabled = cfg.enabled(m.id());
        boolean hovered = mx >= cx && mx < cx + COL_W && my >= ry && my < ry + ROW_H;
        boolean isSettings = m.id().equals(settingsModuleId);

        // Row background
        int rowBg;
        if (isSettings) rowBg = 0xFF162637;
        else if (enabled) rowBg = hovered ? 0xFF0F2A27 : C_ROW_ON;
        else rowBg = hovered ? C_ROW_HOVER : C_COL_BG;
        ctx.fill(cx + 2, ry, cx + COL_W - 1, ry + ROW_H - 1, rowBg);

        // Enabled indicator: left mini-bar
        if (enabled) ctx.fill(cx + 2, ry, cx + 4, ry + ROW_H - 1, C_HDR_ACCENT);

        // Module name
        int nameColor = enabled ? C_ON_LABEL : (hovered ? C_TEXT : 0xFFBBCCDD);
        ctx.drawTextWithShadow(textRenderer, m.name(), cx + COL_PAD_X + (enabled ? 2 : 0), ry + 6, nameColor);

        // Checkmark if enabled
        if (enabled) {
            ctx.drawTextWithShadow(textRenderer, "✔", cx + COL_W - 18, ry + 6, C_CHECK);
        }

        // Settings arrow for modules that have configurable settings
        if (hasSettings(m.id()) && hovered && !enabled) {
            ctx.drawTextWithShadow(textRenderer, "›", cx + COL_W - 18, ry + 6, C_ARROW);
        }

        // Keybind hint (faint, on hover)
        if (hovered) {
            int kb = cfg.keybind(m.id());
            if (kb > 0) {
                String kbStr = keyName(kb);
                int kbW = textRenderer.getWidth(kbStr);
                ctx.drawTextWithShadow(textRenderer, kbStr, cx + COL_W - 3 - kbW - (enabled ? 14 : 0), ry + 6, 0xFF2A4060);
            }
        }
    }

    private void renderSettingsPanel(DrawContext ctx, int mx, int my, int sx) {
        ModuleCatalog.Module m = ModuleCatalog.byId(settingsModuleId);
        if (m == null) return;

        // Panel
        ctx.fill(sx + 2, startY + 3, sx + SETTINGS_W + 2, startY + colH + 3, 0x55000000);
        ctx.fill(sx, startY, sx + SETTINGS_W, startY + colH, 0xEA080E1C);
        ctx.fill(sx, startY, sx + 2, startY + colH, C_ARROW);
        ctx.fill(sx + 2, startY, sx + SETTINGS_W, startY + 1, C_HDR_LINE);
        ctx.fill(sx + SETTINGS_W - 1, startY, sx + SETTINGS_W, startY + colH, C_BORDER);

        // Header
        ctx.fill(sx + 2, startY + 1, sx + SETTINGS_W - 1, startY + HDR_H, 0xFF0A1122);
        ctx.fill(sx + 2, startY + HDR_H - 1, sx + SETTINGS_W - 1, startY + HDR_H, C_HDR_LINE);
        ctx.drawTextWithShadow(textRenderer, "SETTINGS", sx + COL_PAD_X, startY + 10, C_ARROW);
        ctx.drawTextWithShadow(textRenderer, m.name(), sx + COL_PAD_X, startY + 24, C_TEXT);

        int py = startY + HDR_H + 10;
        int pw = SETTINGS_W - COL_PAD_X * 2;
        int px = sx + COL_PAD_X;

        // Description
        ctx.fill(px, py, px + pw, py + 18, 0xFF0B1525);
        ctx.drawTextWithShadow(textRenderer, m.description(), px + 4, py + 5, C_MUTED);
        py += 26;

        // Toggle button
        boolean on = cfg.enabled(m.id());
        ctx.fill(px, py, px + pw, py + 22, on ? 0xFF0E2A27 : 0xFF0D1A26);
        ctx.fill(px, py, px + 2, py + 22, on ? C_CHECK : C_BORDER);
        ctx.drawTextWithShadow(textRenderer, "Toggle:  " + (on ? "ON" : "OFF"), px + 6, py + 7,
                on ? C_ON_LABEL : C_TEXT);
        py += 30;

        // Keybind
        String kbLabel = listeningForKeybind.equals(m.id()) ? "PRESS KEY …" : "KEY: " + keyName(cfg.keybind(m.id()));
        ctx.fill(px, py, px + pw, py + 22, 0xFF0B1525);
        ctx.fill(px, py, px + 2, py + 22, C_ARROW);
        ctx.drawTextWithShadow(textRenderer, kbLabel, px + 6, py + 7, C_MUTED);
        py += 30;

        // Module-specific sliders
        py = renderModuleSliders(ctx, m.id(), px, py, pw, mx, my);

        // Close button
        int closeY = startY + colH - 28;
        ctx.fill(px, closeY, px + pw, closeY + 20, 0xFF0A0F1E);
        ctx.fill(px, closeY, px + pw, closeY + 1, C_BORDER);
        ctx.drawCenteredTextWithShadow(textRenderer, "CLOSE PANEL", px + pw / 2, closeY + 6, C_MUTED);
    }

    /**
     * Draws sliders for module-specific settings. Returns the next y position.
     * Sliders are drawn-only (drag interaction handled in mouseDragged).
     */
    private int renderModuleSliders(DrawContext ctx, String id, int px, int py, int pw, int mx, int my) {
        return switch (id) {
            case "aim_bot" -> {
                py = drawSliderRow(ctx, px, py, pw, mx, my, "RANGE (blocks)",
                        cfg.aimBotRange, 2, 12, id + "_range");
                py = drawSliderRow(ctx, px, py, pw, mx, my, "FOV (°)",
                        cfg.aimBotFov, 10, 180, id + "_fov");
                py = drawSliderRow(ctx, px, py, pw, mx, my, "SMOOTH (%)",
                        cfg.aimBotSmooth, 1, 100, id + "_smooth");
                yield py;
            }
            case "trigger_bot" -> drawSliderRow(ctx, px, py, pw, mx, my, "RANGE (blocks)",
                    cfg.triggerBotRange, 2, 6, id + "_range");
            case "aura" -> drawSliderRow(ctx, px, py, pw, mx, my, "RANGE (blocks)",
                    cfg.auraRange, 2, 6, id + "_range");
            case "reach" -> drawSliderRow(ctx, px, py, pw, mx, my, "EXTRA REACH (blocks)",
                    cfg.reachExtra, 0, 3, id + "_reach");
            case "speed" -> drawSliderRow(ctx, px, py, pw, mx, my, "MULTIPLIER",
                    cfg.speedMultiplier, 0.1, 4, id + "_speed");
            case "velocity" -> {
                py = drawSliderRow(ctx, px, py, pw, mx, my, "HORIZONTAL (%)",
                        cfg.velocityHorizontalPercent, 0, 100, id + "_h");
                py = drawSliderRow(ctx, px, py, pw, mx, my, "VERTICAL (%)",
                        cfg.velocityVerticalPercent, 0, 100, id + "_v");
                yield py;
            }
            case "anti_kb" -> {
                py = drawSliderRow(ctx, px, py, pw, mx, my, "HORIZONTAL (%)",
                        cfg.antiKbHorizontalPercent, 0, 100, id + "_h");
                py = drawSliderRow(ctx, px, py, pw, mx, my, "VERTICAL (%)",
                        cfg.antiKbVerticalPercent, 0, 100, id + "_v");
                yield py;
            }
            default -> py;
        };
    }

    // slider drag state
    private String draggingSlider = null;
    private int    dragStartX, dragStartVal;

    private int drawSliderRow(DrawContext ctx, int px, int py, int pw, int mx, int my,
                               String label, double value, double min, double max, String sliderId) {
        ctx.fill(px, py, px + pw, py + 20, 0xFF090E1C);

        // Track
        int trackY = py + 13;
        ctx.fill(px + 2, trackY, px + pw - 2, trackY + 2, 0xFF1A2A3A);

        // Thumb
        double fraction = (value - min) / (max - min);
        int thumbX = px + 2 + (int)((pw - 4) * fraction);
        ctx.fill(thumbX - 3, trackY - 2, thumbX + 3, trackY + 4, C_HDR_ACCENT);

        // Labels
        ctx.drawTextWithShadow(textRenderer, label, px + 2, py + 3, C_MUTED);
        String valStr = (value == (int)value) ? String.valueOf((int)value)
                : String.format(Locale.ROOT, "%.2f", value);
        ctx.drawTextWithShadow(textRenderer, valStr, px + pw - textRenderer.getWidth(valStr) - 2, py + 3, C_TEXT);

        return py + 26;
    }

    private void applySliderDrag(String sliderId, int deltaX, int totalWidth) {
        double fraction = Math.max(0, Math.min(1, (double) deltaX / totalWidth));
        switch (sliderId) {
            case "aim_bot_range"  -> cfg.aimBotRange   = 2 + fraction * 10;
            case "aim_bot_fov"    -> cfg.aimBotFov     = 10 + fraction * 170;
            case "aim_bot_smooth" -> cfg.aimBotSmooth  = 1 + fraction * 99;
            case "trigger_bot_range" -> cfg.triggerBotRange = 2 + fraction * 4;
            case "aura_range"     -> cfg.auraRange     = 2 + fraction * 4;
            case "reach_reach"    -> cfg.reachExtra    = fraction * 3;
            case "speed_speed"    -> cfg.speedMultiplier = 0.1 + fraction * 3.9;
            case "velocity_h"     -> cfg.velocityHorizontalPercent = fraction * 100;
            case "velocity_v"     -> cfg.velocityVerticalPercent   = fraction * 100;
            case "anti_kb_h"      -> cfg.antiKbHorizontalPercent   = fraction * 100;
            case "anti_kb_v"      -> cfg.antiKbVerticalPercent     = fraction * 100;
        }
        cfg.save();
    }

    private void renderFooter(DrawContext ctx, int mx, int my) {
        int fy = height - BOT_RESERVE;
        ctx.fill(0, fy, width, height, 0xEE04080F);
        ctx.fill(0, fy, width, fy + 1, C_HDR_LINE);

        // Buttons: SAVE / CLOSE
        int bh = 22, bw = 64;
        int bySave  = fy + (BOT_RESERVE - bh) / 2;
        int bxClose = width - bw - 10;
        int bxSave  = bxClose - bw - 6;

        drawFooterButton(ctx, mx, my, bxSave,  bySave, bw, bh, "SAVE",  C_SAVE_BG,  C_SAVE_LINE);
        drawFooterButton(ctx, mx, my, bxClose, bySave, bw, bh, "CLOSE", C_CLOSE_BG, C_CLOSE_LINE);

        // Hint text
        ctx.drawTextWithShadow(textRenderer, "LEFT: toggle  ·  RIGHT: settings  ·  SCROLL: scroll  ·  RSHIFT / ESC: close",
                10, fy + (BOT_RESERVE - 8) / 2, C_MUTED);
    }

    private void drawFooterButton(DrawContext ctx, int mx, int my, int bx, int by, int bw, int bh,
                                   String label, int bg, int accent) {
        boolean hovered = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        ctx.fill(bx, by, bx + bw, by + bh, hovered ? blendOver(bg, 0x18FFFFFF) : bg);
        ctx.fill(bx, by, bx + bw, by + 1, accent);
        ctx.drawCenteredTextWithShadow(textRenderer, label, bx + bw / 2, by + (bh - 8) / 2, C_TEXT);
    }

    // ──────────────────────────────────────────────────────────────────────
    //  Mouse / key events
    // ──────────────────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int mx = (int) mouseX, my = (int) mouseY;
        int fy = height - BOT_RESERVE;

        // ── Footer buttons ─────────────────────────────────────────────
        int bh = 22, bw = 64;
        int bySave  = fy + (BOT_RESERVE - bh) / 2;
        int bxClose = width - bw - 10;
        int bxSave  = bxClose - bw - 6;
        if (button == 0) {
            if (inRect(mx, my, bxSave,  bySave, bw, bh)) { cfg.save(); clickSound(); return true; }
            if (inRect(mx, my, bxClose, bySave, bw, bh)) { close(); return true; }
        }

        // ── Settings panel interactions ────────────────────────────────
        if (settingsModuleId != null) {
            int sx = startX + CAT_LABELS.length * (COL_W + COL_GAP);
            int px = sx + COL_PAD_X;
            int pw = SETTINGS_W - COL_PAD_X * 2;
            int py = startY + HDR_H + 10;
            ModuleCatalog.Module sm = ModuleCatalog.byId(settingsModuleId);

            // Toggle button
            if (button == 0 && inRect(mx, my, px, py + 26, pw, 22)) {
                cfg.setEnabled(settingsModuleId, !cfg.enabled(settingsModuleId));
                cfg.save();
                toggleSound(cfg.enabled(settingsModuleId));
                if ("fast_gapple".equals(settingsModuleId)) DamnSonClient.syncFastGappleToggle();
                return true;
            }
            // Keybind row
            if (button == 0 && inRect(mx, my, px, py + 56, pw, 22)) {
                listeningForKeybind = settingsModuleId;
                clickSound();
                return true;
            }
            // Close panel
            int closeY = startY + colH - 28;
            if (button == 0 && inRect(mx, my, px, closeY, pw, 20)) {
                settingsModuleId = null;
                clickSound();
                init();
                return true;
            }
            // Click outside settings panel
            if (!inRect(mx, my, sx, startY, SETTINGS_W, colH)) {
                settingsModuleId = null;
                clickSound();
                init();
            }
        }

        // ── Column rows ────────────────────────────────────────────────
        for (int ci = 0; ci < CAT_LABELS.length; ci++) {
            int cx = startX + ci * (COL_W + COL_GAP);
            if (!inRect(mx, my, cx, startY, COL_W, colH)) continue;

            List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(CAT_LABELS[ci]);
            for (int vi = 0; vi < visibleRows; vi++) {
                int idx = vi + scrollOffsets[ci];
                if (idx >= modules.size()) break;
                ModuleCatalog.Module m = modules.get(idx);
                int ry = startY + HDR_H + 3 + vi * ROW_H;
                if (!inRect(mx, my, cx + 2, ry, COL_W - 3, ROW_H - 1)) continue;

                if (button == 0) {
                    // Left click → toggle
                    if (!listeningForKeybind.isEmpty()) {
                        // clicking elsewhere cancels keybind
                        listeningForKeybind = "";
                        clickSound();
                        return true;
                    }
                    cfg.setEnabled(m.id(), !cfg.enabled(m.id()));
                    cfg.save();
                    if ("fast_gapple".equals(m.id())) DamnSonClient.syncFastGappleToggle();
                    toggleSound(cfg.enabled(m.id()));
                    return true;
                } else if (button == 1) {
                    // Right click → open settings panel
                    settingsModuleId = m.id();
                    listeningForKeybind = "";
                    clickSound();
                    init(); // recompute totalW to include settings panel
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        // Slider dragging in settings panel
        if (settingsModuleId != null && button == 0) {
            int sx = startX + CAT_LABELS.length * (COL_W + COL_GAP);
            int px = sx + COL_PAD_X;
            int pw = SETTINGS_W - COL_PAD_X * 2;
            int py = startY + HDR_H + 10 + 26 + 30 + 30; // offset past toggle + keybind rows

            // Determine which slider is under the mouse
            String[] sliders = slidersForModule(settingsModuleId);
            for (String sid : sliders) {
                if (inRect((int) mouseX, (int) mouseY, px, py, pw, 20)) {
                    int relX = (int) mouseX - (px + 2);
                    applySliderDrag(sid, relX, pw - 4);
                    return true;
                }
                py += 26;
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double hAmount, double vAmount) {
        if (!listeningForKeybind.isEmpty()) return true;
        for (int ci = 0; ci < CAT_LABELS.length; ci++) {
            int cx = startX + ci * (COL_W + COL_GAP);
            if (mouseX >= cx && mouseX < cx + COL_W && mouseY >= startY && mouseY < startY + colH) {
                List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(CAT_LABELS[ci]);
                int maxScroll = Math.max(0, modules.size() - visibleRows);
                scrollOffsets[ci] = Math.max(0, Math.min(maxScroll,
                        scrollOffsets[ci] - (int) Math.signum(vAmount)));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, hAmount, vAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningForKeybind.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) cfg.setKeybind(listeningForKeybind, 0);
            else if (keyCode != GLFW.GLFW_KEY_RIGHT_SHIFT) cfg.setKeybind(listeningForKeybind, keyCode);
            listeningForKeybind = "";
            cfg.save();
            clickSound();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        listeningForKeybind = "";
        cfg.save();
        super.close();
    }

    @Override public boolean shouldPause() { return false; }

    // ──────────────────────────────────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────────────────────────────────

    private static boolean hasSettings(String id) {
        return switch (id) {
            case "aim_bot", "trigger_bot", "aura", "reach", "speed", "velocity", "anti_kb" -> true;
            default -> false;
        };
    }

    private static String[] slidersForModule(String id) {
        return switch (id) {
            case "aim_bot"      -> new String[]{"aim_bot_range", "aim_bot_fov", "aim_bot_smooth"};
            case "trigger_bot"  -> new String[]{"trigger_bot_range"};
            case "aura"         -> new String[]{"aura_range"};
            case "reach"        -> new String[]{"reach_reach"};
            case "speed"        -> new String[]{"speed_speed"};
            case "velocity"     -> new String[]{"velocity_h", "velocity_v"};
            case "anti_kb"      -> new String[]{"anti_kb_h", "anti_kb_v"};
            default             -> new String[0];
        };
    }

    private static boolean inRect(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int blendOver(int base, int over) {
        // Very cheap alpha blend; just lighten the bg slightly on hover
        int a = (over >> 24) & 0xFF;
        int br = (base >> 16) & 0xFF, bg = (base >> 8) & 0xFF, bb = base & 0xFF;
        int or = (over >> 16) & 0xFF, og = (over >> 8) & 0xFF, ob = over & 0xFF;
        return 0xFF000000
                | (((br * (255 - a) + or * a) / 255) << 16)
                | (((bg * (255 - a) + og * a) / 255) << 8)
                |  ((bb * (255 - a) + ob * a) / 255);
    }

    private static String keyName(int key) {
        if (key <= 0 || key == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT   -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT    -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE         -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_ALT      -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT     -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL  -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            default -> {
                String n = GLFW.glfwGetKeyName(key, 0);
                yield n == null ? "K" + key : n.toUpperCase(Locale.ROOT);
            }
        };
    }

    private void clickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, 0.28f));
    }

    private void toggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(),
                        enabled ? 1.22f : 0.82f, 0.36f));
    }
}
