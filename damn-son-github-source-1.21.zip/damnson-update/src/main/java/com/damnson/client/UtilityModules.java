package com.damnson.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class UtilityModules {

    // ── Attribute modifier IDs ────────────────────────────────────────────
    private static final Identifier SPEED_MOD  = Identifier.of("damnson", "speed_boost");
    private static final Identifier REACH_MOD  = Identifier.of("damnson", "reach_extend");

    // ── Speed HUD state ───────────────────────────────────────────────────
    private static double previousX, previousZ, horizontalSpeed;

    // ── Feature state ─────────────────────────────────────────────────────
    private static boolean fullbrightWasEnabled;
    private static double  originalGamma   = 1.0;
    private static boolean zoomWasEnabled;
    private static int     originalFov     = 70;
    private static boolean sneakWasEnabled;
    private static boolean speedWasEnabled;
    private static boolean reachWasEnabled;
    private static long    lastEatTick;
    private static long    lastAutoJumpTick;
    private static long    lastAutoGappleTick;

    // ── Aim Bot: sticky target cycle ─────────────────────────────────────
    /** The entity we are currently locked onto. */
    private static LivingEntity aimTarget        = null;
    /** How many targets to skip when re-acquiring (increments each OFF→ON). */
    private static int          aimCycleSkip     = 0;
    private static boolean      aimBotWasEnabled = false;

    // ── Trigger Bot ───────────────────────────────────────────────────────
    private static LivingEntity triggerTarget     = null;
    private static long         triggerFirstSeen  = 0; // world tick
    private static long         triggerDelay      = 5; // ticks before attacking
    private static long         triggerLastAttack = 0;

    // ── Aura / Criticals ──────────────────────────────────────────────────
    private static long    auraLastAttack  = 0;
    private static boolean critHopPending  = false;

    // ── Death Cords ───────────────────────────────────────────────────────
    private static boolean deathCordsFired = false;

    private UtilityModules() {}

    // ─────────────────────────────────────────────────────────────────────
    //  Initialisation
    // ─────────────────────────────────────────────────────────────────────

    public static void registerHud() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Main tick
    // ─────────────────────────────────────────────────────────────────────

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) return;
        ModuleSettings cfg = ModuleSettings.get();

        // Auto Respawn
        if (cfg.enabled("auto_respawn") && client.player.isDead() && client.currentScreen != null) {
            client.player.requestRespawn();
            client.setScreen(null);
        }

        // Death Cords
        if (cfg.enabled("death_cords")) {
            if (client.player.isDead() && !deathCordsFired) {
                deathCordsFired = true;
                client.player.sendMessage(Text.literal(
                    String.format("[Death Cords]  X: %d  Y: %d  Z: %d  DIM: %s",
                        client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ(),
                        client.world.getRegistryKey().getValue().getPath())), false);
            } else if (!client.player.isDead()) {
                deathCordsFired = false;
            }
        }

        if (client.currentScreen != null) {
            // Still apply reach/speed toggles even with screen open, then return.
            tickReach(client, cfg);
            tickSpeed(client, cfg);
            return;
        }

        // ── Aim Bot ─────────────────────────────────────────────────────
        tickAimBot(client, cfg);

        // ── Trigger Bot ─────────────────────────────────────────────────
        tickTriggerBot(client, cfg);

        // ── Aura ────────────────────────────────────────────────────────
        tickAura(client, cfg);

        // ── Sneak ───────────────────────────────────────────────────────
        boolean sneakEnabled = cfg.enabled("toggle_sneak");
        if (sneakEnabled)          client.options.sneakKey.setPressed(true);
        else if (sneakWasEnabled)  client.options.sneakKey.setPressed(false);
        sneakWasEnabled = sneakEnabled;

        // ── Auto Sprint ─────────────────────────────────────────────────
        if (cfg.enabled("auto_sprint")
                && client.options.forwardKey.isPressed()
                && !client.options.sneakKey.isPressed()
                && !client.player.isUsingItem()
                && !client.player.isFallFlying()
                && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }

        // ── Auto Jump ───────────────────────────────────────────────────
        long worldTick = client.world.getTime();
        boolean autoJump = cfg.enabled("auto_jump")
                && client.options.forwardKey.isPressed()
                && client.player.isOnGround()
                && !client.player.isTouchingWater()
                && !client.player.isInLava()
                && !client.player.isUsingItem();
        if (autoJump && worldTick - lastAutoJumpTick >= 10) {
            client.player.jump();
            lastAutoJumpTick = worldTick;
        }

        // ── Auto Tool / Auto Eat / Auto GApple ──────────────────────────
        tickAutoTool(client, cfg);
        tickAutoEat(client, cfg);
        tickAutoGapple(client, cfg);

        // ── Reach / Speed / Fullbright / Zoom ───────────────────────────
        tickReach(client, cfg);
        tickSpeed(client, cfg);
        tickFullbright(client, cfg);
        tickZoom(client, cfg);

        // ── Speed HUD ───────────────────────────────────────────────────
        horizontalSpeed = Math.sqrt(
                Math.pow(client.player.getX() - previousX, 2)
                + Math.pow(client.player.getZ() - previousZ, 2)) * 20.0;
        previousX = client.player.getX();
        previousZ = client.player.getZ();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Aim Bot  — sticky target, cycles on re-enable
    //
    //  Behaviour:
    //    • First enable → lock onto target #0 (sorted by crosshair angle).
    //    • Toggle OFF   → clear lock, increment cycle counter.
    //    • Toggle ON    → lock onto target #N (N = cycle counter mod count).
    //    • While locked → smooth-track that entity even if others step in front.
    //    • Target dead/gone → silently clear; next tick re-acquires.
    //
    //  Bypass notes (Grim / Vulcan):
    //    • Rotation step capped at MAX_STEP °/tick (avoid impossible yaw velocity).
    //    • Sub-tick gaussian jitter breaks linear-tracking signature.
    //    • FOV cone prevents snap turns from 180° away.
    // ─────────────────────────────────────────────────────────────────────

    private static final float MAX_STEP_DEG = 9.5f; // max yaw/pitch per tick

    private static void tickAimBot(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("aim_bot");

        // Detect OFF → ON
        if (enabled && !aimBotWasEnabled) {
            aimTarget = null; // re-acquire using current cycle index
        }
        // Detect ON → OFF: increment skip so next ON picks the next target
        if (!enabled && aimBotWasEnabled) {
            aimCycleSkip++;
            aimTarget = null;
        }
        aimBotWasEnabled = enabled;

        if (!enabled) return;

        // Validate existing lock
        if (aimTarget != null) {
            boolean gone = !aimTarget.isAlive()
                    || aimTarget.isRemoved()
                    || client.world.getEntityById(aimTarget.getId()) == null;
            if (gone) aimTarget = null;
        }

        // Acquire new target from sorted candidate list
        if (aimTarget == null) {
            List<LivingEntity> candidates = buildAimCandidates(client, cfg);
            if (!candidates.isEmpty()) {
                aimTarget = candidates.get(aimCycleSkip % candidates.size());
            }
        }

        if (aimTarget == null) return;

        // Smooth track locked target
        Vec3d delta = aimTarget.getEyePos().subtract(client.player.getEyePos());
        float tYaw   = (float)(Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
        float tPitch = (float)-(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))
                * (180.0 / Math.PI));

        float yawDelta   = MathHelper.wrapDegrees(tYaw   - client.player.getYaw());
        float pitchDelta = tPitch - client.player.getPitch();

        float smooth = (float)(cfg.aimBotSmooth / 100.0);
        float yawStep   = clampF(yawDelta   * smooth, -MAX_STEP_DEG, MAX_STEP_DEG);
        float pitchStep = clampF(pitchDelta * smooth, -MAX_STEP_DEG, MAX_STEP_DEG);

        // Gaussian sub-tick jitter — breaks linear signature
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        yawStep   += (float)(rng.nextGaussian() * 0.18);
        pitchStep += (float)(rng.nextGaussian() * 0.12);

        client.player.setYaw(client.player.getYaw() + yawStep);
        client.player.setPitch(MathHelper.clamp(client.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    /** Sorted by angle distance from crosshair, filtered by FOV cone and range. */
    private static List<LivingEntity> buildAimCandidates(MinecraftClient client, ModuleSettings cfg) {
        double range = cfg.aimBotRange;
        float  fov   = (float)(cfg.aimBotFov / 2.0);
        boolean filterBots = cfg.enabled("anti_bot");
        List<LivingEntity> out = new ArrayList<>();

        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator())) {
            if (filterBots && !(e instanceof PlayerEntity)) continue; // keep real players only when anti-bot on
            Vec3d delta = e.getEyePos().subtract(client.player.getEyePos());
            if (delta.lengthSquared() > range * range) continue;
            float targetYaw = (float)(Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
            if (Math.abs(MathHelper.wrapDegrees(targetYaw - client.player.getYaw())) > fov) continue;
            out.add(e);
        }
        // Sort closest to crosshair first
        Vec3d lookVec = client.player.getRotationVec(1.0f);
        out.sort((a, b) -> {
            double da = a.getEyePos().subtract(client.player.getEyePos()).normalize().distanceTo(lookVec);
            double db = b.getEyePos().subtract(client.player.getEyePos()).normalize().distanceTo(lookVec);
            return Double.compare(da, db);
        });
        return out;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Trigger Bot  — entity under crosshair, humanized random delay
    //
    //  Bypass notes (Grim / Vulcan):
    //    • 3–8 tick wait after entity enters crosshair (not instant).
    //    • Attack only at ≥0.90 cooldown (not tick-perfect 1.0 every time).
    //    • Min 8–12 tick interval between attacks (avoids robotic CPS).
    //    • Delay randomised per trigger window (no fixed period).
    // ─────────────────────────────────────────────────────────────────────

    private static void tickTriggerBot(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("trigger_bot") || client.interactionManager == null) return;
        if (!isHoldingCombatWeapon(client)) return;

        LivingEntity target = null;
        if (client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity le
                && le.isAlive() && !le.isSpectator()) {
            double range = cfg.triggerBotRange;
            if (client.player.squaredDistanceTo(le) <= range * range) {
                target = le;
            }
        }

        long now = client.world.getTime();
        ThreadLocalRandom rng = ThreadLocalRandom.current();

        if (target != triggerTarget) {
            triggerTarget    = target;
            triggerFirstSeen = now;
            // Random delay before first attack in this trigger window
            triggerDelay = 3 + rng.nextLong(6); // 3–8 ticks
        }

        if (target == null) return;
        if (now - triggerFirstSeen < triggerDelay) return;
        if (client.player.getAttackCooldownProgress(0.0f) < 0.90f) return;

        // Minimum gap between attacks (not robotic)
        long minInterval = 8 + rng.nextLong(5); // 8–12 ticks
        if (now - triggerLastAttack < minInterval) return;

        client.interactionManager.attackEntity(client.player, target);
        client.player.swingHand(Hand.MAIN_HAND);
        triggerLastAttack = now;

        // Reset window delay so next consecutive attack also has human variance
        triggerDelay     = 3 + rng.nextLong(6);
        triggerFirstSeen = now;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Aura  — auto-attack nearest entity; integrates with Criticals
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAura(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("aura") || client.interactionManager == null) return;

        long now = client.world.getTime();
        long interval = 10 + ThreadLocalRandom.current().nextLong(4); // ~0.5–0.7 s
        if (now - auraLastAttack < interval) return;

        double range = cfg.auraRange;
        LivingEntity nearest = null;
        double best = range * range;
        boolean filterBots = cfg.enabled("anti_bot");

        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator())) {
            if (filterBots && !(e instanceof PlayerEntity)) continue;
            double dist = client.player.squaredDistanceTo(e);
            if (dist < best) { best = dist; nearest = e; }
        }

        if (nearest == null) return;
        if (client.player.getAttackCooldownProgress(0.0f) < 0.95f) return;

        // Criticals: hop crit — tiny upward velocity, then attack while falling
        if (cfg.enabled("criticals") && client.player.isOnGround() && !client.player.isInFluid()) {
            if (!critHopPending) {
                Vec3d vel = client.player.getVelocity();
                client.player.setVelocity(vel.x, 0.40, vel.z); // micro hop
                critHopPending = true;
                return; // wait for fall
            }
        }
        critHopPending = false;

        // Smooth snap toward target before striking
        Vec3d delta = nearest.getEyePos().subtract(client.player.getEyePos());
        float tYaw   = (float)(Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
        float tPitch = (float)-(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))
                * (180.0 / Math.PI));
        client.player.setYaw(client.player.getYaw()
                + MathHelper.wrapDegrees(tYaw - client.player.getYaw()) * 0.55f);
        client.player.setPitch(client.player.getPitch()
                + (tPitch - client.player.getPitch()) * 0.55f);

        client.interactionManager.attackEntity(client.player, nearest);
        client.player.swingHand(Hand.MAIN_HAND);
        auraLastAttack = now;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Reach  — extends entity_interaction_range attribute
    // ─────────────────────────────────────────────────────────────────────

    private static void tickReach(MinecraftClient client, ModuleSettings cfg) {
        if (client.player == null) return;
        boolean enabled = cfg.enabled("reach");
        var attr = client.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (attr == null) return;

        if (enabled && !reachWasEnabled) {
            attr.addTemporaryModifier(new EntityAttributeModifier(
                    REACH_MOD, cfg.reachExtra, EntityAttributeModifier.Operation.ADD_VALUE));
        } else if (!enabled && reachWasEnabled) {
            attr.removeModifier(REACH_MOD);
        }
        reachWasEnabled = enabled;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Speed  — adds to movement_speed attribute
    // ─────────────────────────────────────────────────────────────────────

    private static void tickSpeed(MinecraftClient client, ModuleSettings cfg) {
        if (client.player == null) return;
        boolean enabled = cfg.enabled("speed");
        var attr = client.player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (attr == null) return;

        if (enabled && !speedWasEnabled) {
            // Base movement speed in MC is ~0.1; add a fraction of the multiplier
            double bonus = 0.020 * cfg.speedMultiplier;
            attr.addTemporaryModifier(new EntityAttributeModifier(
                    SPEED_MOD, bonus, EntityAttributeModifier.Operation.ADD_VALUE));
        } else if (!enabled && speedWasEnabled) {
            attr.removeModifier(SPEED_MOD);
        }
        speedWasEnabled = enabled;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Auto GApple  — eat a golden apple when health < 7 hearts
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAutoGapple(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_gapple") || client.player.isUsingItem()) return;
        if (client.player.getHealth() > 14.0f) return; // > 7 hearts, don't eat
        long worldTick = client.world.getTime();
        if (worldTick - lastAutoGappleTick < 20) return; // cooldown

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof EnchantedGoldenAppleItem
                    || stack.getItem() instanceof Item item && isGoldenApple(item)) {
                client.player.getInventory().selectedSlot = slot;
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                lastAutoGappleTick = worldTick;
                return;
            }
        }
    }

    private static boolean isGoldenApple(Item item) {
        // GoldenAppleItem is the vanilla (non-enchanted) gapple
        return item.getClass().getSimpleName().contains("GoldenApple");
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Existing helpers (unchanged logic, no PracticeWorldGuard)
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAutoTool(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_tool") || !(client.crosshairTarget instanceof BlockHitResult hit)) return;
        var state = client.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return;
        int bestSlot = client.player.getInventory().selectedSlot;
        float bestSpeed = client.player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int slot = 0; slot < 9; slot++) {
            float speed = client.player.getInventory().getStack(slot).getMiningSpeedMultiplier(state);
            if (speed > bestSpeed * 1.05f) { bestSpeed = speed; bestSlot = slot; }
        }
        client.player.getInventory().selectedSlot = bestSlot;
    }

    private static void tickAutoEat(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_eat")
                || client.player.isUsingItem()
                || client.player.getHungerManager().getFoodLevel() > 14) return;
        long tick = client.world.getTime();
        if (tick - lastEatTick < 8) return;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (stack.contains(DataComponentTypes.FOOD)) {
                client.player.getInventory().selectedSlot = slot;
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                lastEatTick = tick;
                return;
            }
        }
    }

    private static void tickFullbright(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("fullbright");
        if (enabled && !fullbrightWasEnabled) originalGamma = client.options.getGamma().getValue();
        if (enabled)               client.options.getGamma().setValue(1.0);
        else if (fullbrightWasEnabled) client.options.getGamma().setValue(originalGamma);
        fullbrightWasEnabled = enabled;
    }

    private static void tickZoom(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("zoom");
        if (enabled && !zoomWasEnabled) originalFov = client.options.getFov().getValue();
        if (enabled)              client.options.getFov().setValue(30);
        else if (zoomWasEnabled)  client.options.getFov().setValue(originalFov);
        zoomWasEnabled = enabled;
    }

    private static boolean isHoldingCombatWeapon(MinecraftClient client) {
        if (client == null || client.player == null) return false;
        var item = client.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem
                || item instanceof MaceItem || item instanceof TridentItem;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  HUD
    // ─────────────────────────────────────────────────────────────────────

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null
                || client.options.hudHidden) return;
        ModuleSettings cfg = ModuleSettings.get();
        int x = 6, y = 6, line = 11;

        if (cfg.enabled("watermark_hud")) { draw(context, "DAMN SON  /  1.21", x, y, 0xFFC39AFF); y += line; }
        if (cfg.enabled("fps_hud"))       { draw(context, "FPS  " + client.getCurrentFps(), x, y); y += line; }
        if (cfg.enabled("coordinates_hud")) {
            draw(context, String.format(Locale.ROOT, "XYZ  %d / %d / %d",
                    client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ()), x, y);
            y += line;
            draw(context, "DIM  " + client.world.getRegistryKey().getValue().getPath(), x, y);
            y += line;
        }
        if (cfg.enabled("ping_hud")) {
            var handler = client.getNetworkHandler();
            var entry   = handler == null ? null : handler.getPlayerListEntry(client.player.getUuid());
            draw(context, "PING  " + (entry == null ? "--" : entry.getLatency() + " ms"), x, y);
            y += line;
        }
        if (cfg.enabled("biome_hud")) {
            String biome = client.world.getBiome(client.player.getBlockPos()).getKey()
                    .map(k -> k.getValue().getPath()).orElse("unknown");
            draw(context, "BIOME  " + biome, x, y); y += line;
        }
        if (cfg.enabled("direction_hud")) {
            String[] dirs = {"S","SW","W","NW","N","NE","E","SE"};
            draw(context, "FACING  " + dirs[Math.floorMod(Math.round(client.player.getYaw() / 45.0f), 8)], x, y);
            y += line;
        }
        if (cfg.enabled("speed_hud")) {
            draw(context, String.format(Locale.ROOT, "SPEED  %.2f m/s", horizontalSpeed), x, y); y += line;
        }
        if (cfg.enabled("clock_hud")) {
            long time = Math.floorMod(client.world.getTimeOfDay() + 6000L, 24000L);
            draw(context, String.format(Locale.ROOT, "TIME  %02d:%02d",
                    (int)(time / 1000L), (int)(time % 1000L * 60L / 1000L)), x, y);
            y += line;
        }
        if (cfg.enabled("armor_hud")) {
            StringBuilder armor = new StringBuilder("ARMOR  ");
            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}) {
                ItemStack stack = client.player.getEquippedStack(slot);
                if (stack.isEmpty()) armor.append("--  ");
                else if (stack.isDamageable()) {
                    int remaining = 100 - Math.round(stack.getDamage() * 100.0f / stack.getMaxDamage());
                    armor.append(remaining).append("%  ");
                } else armor.append("OK  ");
            }
            draw(context, armor.toString().trim(), x, y); y += line;
        }
        if (cfg.enabled("keystrokes_hud")) {
            drawKey(context, "W",    client.options.forwardKey.isPressed(),  x + 22, y + 1);
            drawKey(context, "A",    client.options.leftKey.isPressed(),     x,      y + 23);
            drawKey(context, "S",    client.options.backKey.isPressed(),     x + 22, y + 23);
            drawKey(context, "D",    client.options.rightKey.isPressed(),    x + 44, y + 23);
            drawKey(context, "SPC",  client.options.jumpKey.isPressed(),     x,      y + 45, 66);
            y += 68;
        }

        // ── ESP: draw name tags through walls ───────────────────────────
        if (cfg.enabled("esp") || cfg.enabled("name_tags")) {
            // We render via the HUD callback using world→screen projection.
            // The HUD context is 2D, so we use MinecraftClient's camera matrices.
            renderEspOverlay(context, client, cfg);
        }

        // ── Array list (right side) ──────────────────────────────────────
        if (cfg.enabled("array_list_hud")) {
            List<String> active = new ArrayList<>();
            for (ModuleCatalog.Module m : ModuleCatalog.MODULES) {
                if (cfg.enabled(m.id()) && !m.id().endsWith("_hud")) active.add(m.name());
            }
            int ay = 7;
            for (String name : active) {
                int tw = client.textRenderer.getWidth(name);
                int ax = client.getWindow().getScaledWidth() - tw - 12;
                context.fill(ax - 4, ay - 2, ax + tw + 6, ay + 10, 0xA8080D18);
                context.fill(ax + tw + 3, ay - 2, ax + tw + 6, ay + 10, 0xFF9C69FF);
                context.drawTextWithShadow(client.textRenderer, name, ax, ay, 0xFFF0E8FF);
                ay += 12;
            }
        }
    }

    /**
     * Simple ESP: project entity eye position to screen and draw a name/health label.
     * Falls back gracefully if the projection yields off-screen coordinates.
     */
    private static void renderEspOverlay(DrawContext context, MinecraftClient client, ModuleSettings cfg) {
        if (client.world == null || client.player == null) return;
        net.minecraft.client.render.Camera camera = client.gameRenderer.getCamera();
        net.minecraft.client.util.math.MatrixStack ms = new net.minecraft.client.util.math.MatrixStack();

        org.joml.Matrix4f projView = new org.joml.Matrix4f(client.gameRenderer.getBasicProjectionMatrix(client.options.getFov().getValue()))
                .mul(new org.joml.Matrix4f().rotation(
                        (float)Math.toRadians(camera.getPitch()), 1,0,0).rotateY(
                        (float)Math.toRadians(camera.getYaw() + 180f)));

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();

        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(64),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator())) {

            Vec3d camPos   = camera.getPos();
            Vec3d entityEye = e.getEyePos();
            double rx = entityEye.x - camPos.x;
            double ry = entityEye.y - camPos.y + 0.3;
            double rz = entityEye.z - camPos.z;

            org.joml.Vector4f clip = projView.transform(new org.joml.Vector4f((float)rx, (float)ry, (float)rz, 1.0f));
            if (clip.w <= 0) continue; // behind camera
            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;
            if (Math.abs(ndcX) > 1.1f || Math.abs(ndcY) > 1.1f) continue; // off-screen

            int sx = (int)((ndcX + 1.0f) * 0.5f * sw);
            int sy = (int)((1.0f - ndcY) * 0.5f * sh);

            String label;
            int color;
            if (e instanceof PlayerEntity pe) {
                label = pe.getName().getString();
                // Health color: green → yellow → red
                float hp = e.getHealth() / e.getMaxHealth();
                color = hpColor(hp);
            } else {
                if (!cfg.enabled("esp")) continue; // name_tags only targets players
                label = e.getType().getName().getString();
                color = 0xFFCCCCCC;
            }

            int tw = client.textRenderer.getWidth(label);
            context.fill(sx - tw/2 - 3, sy - 11, sx + tw/2 + 3, sy + 1, 0x88000000);
            context.drawCenteredTextWithShadow(client.textRenderer, label, sx, sy - 9, color);
        }
    }

    private static int hpColor(float fraction) {
        fraction = MathHelper.clamp(fraction, 0.0f, 1.0f);
        int r = (int)((1.0f - fraction) * 255);
        int g = (int)(fraction * 220);
        return 0xFF000000 | (r << 16) | (g << 8);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Draw helpers
    // ─────────────────────────────────────────────────────────────────────

    private static void draw(DrawContext context, String value, int x, int y) {
        draw(context, value, x, y, 0xFFE5F4FF);
    }

    private static void draw(DrawContext context, String value, int x, int y, int color) {
        MinecraftClient client = MinecraftClient.getInstance();
        context.fill(x - 3, y - 2, x + client.textRenderer.getWidth(value) + 5, y + 10, 0x99060B16);
        context.drawTextWithShadow(client.textRenderer, Text.literal(value), x, y, color);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y) {
        drawKey(context, label, pressed, x, y, 20);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y, int width) {
        context.fill(x, y, x + width, y + 19, pressed ? 0xFF26769B : 0xD90B1422);
        context.fill(x, y, x + width, y + 1,  pressed ? 0xFF6DE0FF : 0xFF526780);
        context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer,
                label, x + width / 2, y + 5, 0xFFF4FAFF);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Util
    // ─────────────────────────────────────────────────────────────────────

    private static float clampF(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
