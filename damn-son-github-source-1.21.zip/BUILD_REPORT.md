# Build and validation report

- Target: Minecraft Java 1.21 / Fabric / Java 21.
- Replaced the two-tab menu with an original six-category ClickGUI: Combat, Movement, Render, Player, HUD, and Misc.
- Added a catalog of 22 toggleable modules, independent keybind capture, scrolling, settings view, and JSON config persistence.
- Added or retained working client-side features: FPS, coordinates/dimension, keystrokes, armor durability, ping, biome, facing direction, horizontal speed, world clock, watermark, active-module list, auto sprint, auto jump, auto eat, auto tool, auto respawn, max vanilla gamma, zoom, and toggle sneak.
- Existing combat-practice helpers are gated to solo single-player worlds and remain disabled in multiplayer/LAN sessions.
- Kept the animated cyberpunk background and L-logo assets.
- ZIP integrity, JSON parsing, required resources, Java source brace balance, and root-project layout were checked.
- **Gradle compilation and in-game test were not run** because Gradle is not installed and network DNS is unavailable in the current environment. No compiled JAR is included.
- The linked YouTube page exposed its title but not a readable module-by-module inventory. The 22 modules above are an original expansion, not a verified exact list of everything shown in that video.
