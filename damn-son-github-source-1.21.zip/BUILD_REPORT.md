# Damn Son Fabric 1.21 — v0.6.2 build report

## Changes

- Removed the single-player-only guard from Anti-KB.
- Anti-KB still only targets velocity updates whose entity ID matches the local player.
- Default new-install retained horizontal/vertical velocity is 0%/0%. Existing config values are preserved.
- Config version 9; project/UI version 0.6.2.
- Anti-KB is the default selected module when opening the settings page.
- Preserved existing GUI, keybinds, toggle sounds, sliders, and utility modules.

## Static validation performed

- Parse `fabric.mod.json` and mixin config as JSON.
- Check module IDs are unique and Anti-KB remains in COMBAT.
- Check Anti-KB does not gate on `isInSingleplayer()`.
- Check the handler compares the incoming velocity packet entity ID with the local player ID.
- Check referenced GUI textures exist.
- Verify the root Gradle project files are included in the ZIP.

## Not verified

Gradle is not installed and dependency downloads are blocked in this environment, so Java compilation, Fabric remapping, and in-game behavior were not tested. This ZIP is source, not a compiled JAR. Multiplayer servers may also correct/reject client-side velocity changes.
