# Build report — v0.6.4

Static source checks:
- Anti-KB sliders are absent from the settings GUI.
- Anti-KB retains the existing solo integrated-world guard.
- Aim Assist and Trigger Bot remain practice-only and explicitly exclude PlayerEntity targets.
- Module metadata version bumped to 0.6.4.

Build status:
- Not compiled in this environment because Gradle is unavailable.
- Run `gradle --no-daemon -p project clean build` in GitHub Actions to verify compilation.
