# Build report (v0.6.6)

- Target is Minecraft 1.21 / Fabric / Java 21.
- Replaced the previous animated/anime menu background and logo with a clean dark UI, flat custom-rendered buttons, hover states, teal/purple accent colors, and separate enable/disable sounds.
- Preserved categories, module keybind capture, settings page, sliders for practice helpers, Save/Load, Right Shift menu behavior, and existing module catalog.
- Removed unused legacy GUI background and logo image assets.
- Static checks: JSON metadata parsed; unique module IDs confirmed; mixin class references resolved; old background/logo references absent; source brace and parenthesis counts matched; ZIP integrity passed.
- Gradle executable is unavailable in the authoring container, so compilation and runtime tests were not run locally. A GitHub Actions build is still required.
