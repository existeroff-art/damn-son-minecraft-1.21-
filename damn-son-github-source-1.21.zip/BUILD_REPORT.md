# Build report — v0.6.3 source

Static source checks are run by the authoring workflow. Gradle is not installed in the authoring environment, so a clean Gradle compile and in-game test have not been verified. Use the included GitHub Actions workflow to compile the project and inspect its artifact/logs.
