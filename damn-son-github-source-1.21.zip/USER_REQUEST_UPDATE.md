# User-request update (2026-10-20) — v0.7.9

The available module menu and settings whitelist now contain only:

- Aim Assist
- Trigger Bot
- Fast Gap
- Snap Tap
- Auto Pot
- Auto Pot Refill

The unrelated module entries, macro profiles, and retired mixins were removed from the active project. The settings panel now scrolls independently; Aim Point and Weapons Only click regions follow their drawn positions; menu interactions have click/toggle sounds; slider config writes happen on release instead of every drag frame.

Aim Assist uses elapsed render-frame time for smoothing and avoids rebuilding/sorting a target list. Auto Pot Refill no longer copies all nine hotbar stacks every tick. These are code-level performance changes, not a confirmed in-game stutter fix.

Only two gameplay recordings were attached with this request. No third reference clip was attached, so its exact settings were not copied. Static validation passes; Gradle compilation and an in-game test are still required.
