# Test report — v0.7.7

- Source archive contains `build.gradle`, `settings.gradle`, `gradle.properties`, source files and the GitHub Actions workflow at ZIP root.
- `python scripts/validate_source.py`: PASS — 68 unique module IDs, JSON descriptors valid, Java delimiter sanity passed, and required implementation hooks present.
- Added Crystal PvP, Mace PvP, Sword PvP and Netherite Pot PvP hotbar-selection profiles.
- Added one-press Crystal, Mace and healing-potion hotbar macros; each macro reports its action and resets itself OFF.
- Merged settings-panel clipping/footer hit-testing fix.
- Gradle compilation and Minecraft runtime/in-game testing: NOT RUN. Gradle is not installed in this environment, and the Gradle distribution host could not be resolved from this runtime. Please use the included GitHub Actions workflow to perform the actual build.
