# Damn Son 1.21 source update — Aim Assist and Potion handling

## Changed in this revision

- Aim Assist FOV now supports the full 10–360° range; 360° disables angle filtering and searches all around the player.
- Aim Assist range now defaults to 8 blocks and can be configured up to 32 blocks. Existing-lock hysteresis and target-point consistency prevent boundary-based target drop/reacquire loops.
- Replaced the fixed 24° yaw / 15° pitch caps with continuous exponential easing. The default strength is 85/100; the slider still adjusts tracking strength.
- Target candidates are sorted by angular error and then distance; target torso points use consistent prediction during acquisition and tracking.
- Auto Potion selects splash potions carrying Instant Health (preferred) or Regeneration (fallback), uses a configurable health threshold and cooldown, pulls a healing potion from inventory when the hotbar is empty, and sends the use action with a temporary downward pitch before immediately restoring the local camera.
- Added a separate **Pot Refill** toggle that watches emptied splash-potion hotbar slots and swaps in the same potion contents from main inventory slots 9–35. It covers manual throws and Auto Potion use when enabled.
- Settings remain backward-compatible; missing new config fields get defaults and the config version is now 15.
- Added health-threshold and cooldown controls to Auto Potion settings.

## Validation status

- Source package structure and JSON descriptors are checked by the packaging script.
- The source ZIP has no bundled Gradle wrapper. A full Minecraft/Fabric compilation and in-game test are not claimed here; run the included GitHub Actions workflow to confirm compilation against Yarn 1.21 build 9 and Fabric API 0.100.8.
- Auto Potion / Pot Refill depend on the server honoring standard splash-potion use and inventory slot swaps. Server anti-cheat/plugins can reject or alter this behavior.
