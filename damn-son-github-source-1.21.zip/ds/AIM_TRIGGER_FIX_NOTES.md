# Aim Assist and Potion Fix Notes — v0.7.1

## Aim Assist
- Removed fixed per-tick yaw/pitch angle caps that made long corrections stutter.
- Kept target selection sticky and added distance/FOV hysteresis to reduce lock loss/reacquire flicker.
- Uses the same predicted torso aim point during both selection and tracking.
- FOV setting covers 10–360 degrees; 360 means no angular filtering (a full circle).
- Default profile is 8-block range, 360-degree FOV, and 85/100 tracking strength. Range remains configurable through 32 blocks.
- Old config versions migrate to the full-circle, high-strength profile.

## Auto Potion / Pot Refill
- Auto Potion prioritizes splash Instant Health and falls back to splash Regeneration.
- At the configured health threshold it temporarily points the use packet down, then restores the local pitch and selected slot.
- If there is no healing potion in the hotbar, it temporarily borrows one from main inventory and restores the displaced item.
- Pot Refill is separate and, when enabled, refills emptied hotbar splash-potion slots from matching potion contents in main inventory.

## Verification
- Static checks passed; full Fabric compilation and in-game tests are not available in this environment.
