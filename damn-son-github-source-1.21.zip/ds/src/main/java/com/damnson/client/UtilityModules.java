package com.damnson.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.block.CropBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class UtilityModules {

    // ── Attribute modifier IDs ────────────────────────────────────────────
    private static final Identifier SPEED_MOD  = Identifier.of("damnson", "speed_boost");
    private static final Identifier REACH_MOD  = Identifier.of("damnson", "reach_extend");

    // ── Speed HUD state ───────────────────────────────────────────────────
    private static double previousX, previousZ, horizontalSpeed;

    // ── Feature state ─────────────────────────────────────────────────────
    private static boolean fullbrightWasEnabled;
    private static double  originalGamma   = 1.0;
    private static boolean zoomWasEnabled;
    private static int     originalFov     = 70;
    private static boolean sneakWasEnabled;
    private static boolean speedWasEnabled;
    private static boolean reachWasEnabled;
    private static long    lastEatTick;
    private static long    lastAutoJumpTick;
    private static long    lastAutoGappleTick;
    private static long    lastAutoArmorTick;
    private static long    lastAutoPotionTick;
    private static long    lastAutoSoupTick;
    private static long    lastAutoTotemTick;
    private static long    lastWindHopTick;
    private static Object  lastPlayerReference;
    private static BlockPos farmBreakPos;

    // Potion refill tracks hotbar stack consumption so it works for both Auto Potion and manual throws.
    private static final ItemStack[] previousHotbarPotionStacks = new ItemStack[9];
    private static final long[] pendingPotionRefillAt = new long[9];
    private static final PotionContentsComponent[] pendingPotionContents = new PotionContentsComponent[9];

    // ── Aim Assist: maintain a sticky lock until the target is genuinely invalid ──
    private static LivingEntity aimTarget = null;
    private static boolean aimBotWasEnabled = false;

    // ── Trigger Bot ───────────────────────────────────────────────────────
    private static LivingEntity triggerTarget     = null;
    private static long         triggerFirstSeen  = 0; // world tick
    private static long         triggerDelay      = 5; // ticks before attacking
    
    // ── Aura / Criticals ──────────────────────────────────────────────────
    private static long    auraLastAttack  = 0;
    private static boolean critHopPending  = false;

    // ── Death Cords ───────────────────────────────────────────────────────
    private static boolean deathCordsFired = false;

    private UtilityModules() {}

    // ─────────────────────────────────────────────────────────────────────
    //  Initialisation
    // ─────────────────────────────────────────────────────────────────────

    public static void registerHud() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Main tick
    // ─────────────────────────────────────────────────────────────────────

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) return;
        ModuleSettings cfg = ModuleSettings.get();
        // Attribute modifiers and sticky targets belong to a player instance. Reset on respawn/world swap
        // so Speed and Reach are reapplied to the replacement player instead of remaining silently off.
        if (lastPlayerReference != client.player) {
            lastPlayerReference = client.player;
            speedWasEnabled = false;
            reachWasEnabled = false;
            fullbrightWasEnabled = false;
            zoomWasEnabled = false;
            sneakWasEnabled = false;
            aimTarget = null;
            triggerTarget = null;
            aimBotWasEnabled = false;
            triggerFirstSeen = 0;
            farmBreakPos = null;
            lastAutoPotionTick = 0;
            for (int i = 0; i < 9; i++) {
                previousHotbarPotionStacks[i] = null;
                pendingPotionRefillAt[i] = 0L;
                pendingPotionContents[i] = null;
            }
            previousX = client.player.getX();
            previousZ = client.player.getZ();
        }

        // Auto Respawn
        if (cfg.enabled("auto_respawn") && client.player.isDead() && client.currentScreen != null) {
            client.player.requestRespawn();
            client.setScreen(null);
        }

        // Death Cords
        if (cfg.enabled("death_cords")) {
            if (client.player.isDead() && !deathCordsFired) {
                deathCordsFired = true;
                client.player.sendMessage(Text.literal(
                    String.format("[Death Cords]  X: %d  Y: %d  Z: %d  DIM: %s",
                        client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ(),
                        client.world.getRegistryKey().getValue().getPath())), false);
            } else if (!client.player.isDead()) {
                deathCordsFired = false;
            }
        }

        if (client.currentScreen != null) {
            // Still apply reach/speed toggles even with screen open, then return.
            tickReach(client, cfg);
            tickSpeed(client, cfg);
            return;
        }

        // Refill spent splash-potion hotbar slots before combat actions.
        tickPotionRefill(client, cfg);

        // ── Aim Assist ──────────────────────────────────────────────────
        tickAimBot(client, cfg);

        // ── Trigger Bot ─────────────────────────────────────────────────
        tickTriggerBot(client, cfg);

        // ── Aura ────────────────────────────────────────────────────────
        tickAura(client, cfg);

        // ── Sneak ───────────────────────────────────────────────────────
        boolean sneakEnabled = cfg.enabled("toggle_sneak");
        if (sneakEnabled)          client.options.sneakKey.setPressed(true);
        else if (sneakWasEnabled)  client.options.sneakKey.setPressed(false);
        sneakWasEnabled = sneakEnabled;

        // ── Auto Sprint ─────────────────────────────────────────────────
        if (cfg.enabled("auto_sprint")
                && client.options.forwardKey.isPressed()
                && !client.options.sneakKey.isPressed()
                && !client.player.isUsingItem()
                && !client.player.isFallFlying()
                && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }

        // ── Auto Jump ───────────────────────────────────────────────────
        long worldTick = client.world.getTime();
        boolean autoJump = cfg.enabled("auto_jump")
                && client.options.forwardKey.isPressed()
                && client.player.isOnGround()
                && !client.player.isTouchingWater()
                && !client.player.isInLava()
                && !client.player.isUsingItem();
        if (autoJump && worldTick - lastAutoJumpTick >= 10) {
            client.player.jump();
            lastAutoJumpTick = worldTick;
        }

        // ── Auto Tool / Auto Eat / Auto GApple ──────────────────────────
        tickAutoTool(client, cfg);
        tickAutoEat(client, cfg);
        tickAutoGapple(client, cfg);
        tickAutoArmor(client, cfg);
        tickAutoPotion(client, cfg);
        tickAutoSoup(client, cfg);
        tickAutoTotem(client, cfg);
        tickAutoFarm(client, cfg);
        tickFlight(client, cfg);
        tickSpider(client, cfg);
        tickElytraStrafe(client, cfg);
        tickWindHop(client, cfg);

        // ── Reach / Speed / Fullbright / Zoom ───────────────────────────
        tickReach(client, cfg);
        tickSpeed(client, cfg);
        tickFullbright(client, cfg);
        tickZoom(client, cfg);

        // ── Speed HUD ───────────────────────────────────────────────────
        horizontalSpeed = Math.sqrt(
                Math.pow(client.player.getX() - previousX, 2)
                + Math.pow(client.player.getZ() - previousZ, 2)) * 20.0;
        previousX = client.player.getX();
        previousZ = client.player.getZ();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Aim Assist — sticky target selection and continuous, non-jittery easing
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAimBot(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("aim_bot");
        if (!enabled) {
            if (aimBotWasEnabled) aimTarget = null;
            aimBotWasEnabled = false;
            return;
        }
        if (!aimBotWasEnabled) aimTarget = null;
        aimBotWasEnabled = true;

        double range = Math.max(2.0, cfg.aimBotRange);
        float fov = MathHelper.clamp((float) cfg.aimBotFov, 10.0f, 360.0f);
        boolean fullCircle = fov >= 359.9f;

        // Keep a lock while the target remains valid. A small range/FOV hysteresis
        // avoids one-tick unlock/relock loops when a moving target crosses a boundary.
        if (aimTarget != null) {
            boolean invalid = !aimTarget.isAlive() || aimTarget.isRemoved()
                    || client.world.getEntityById(aimTarget.getId()) == null;
            if (!invalid) {
                Vec3d point = getAimPoint(aimTarget);
                Vec3d delta = point.subtract(client.player.getEyePos());
                float targetYaw = yawTo(delta);
                float targetPitch = pitchTo(delta);
                double keepRange = range + 0.65;
                float halfFov = fov * 0.5f;
                invalid = delta.lengthSquared() > keepRange * keepRange;
                if (!invalid && !fullCircle) {
                    invalid = Math.abs(MathHelper.wrapDegrees(targetYaw - client.player.getYaw())) > halfFov + 7.0f
                            || Math.abs(targetPitch - client.player.getPitch()) > halfFov + 7.0f;
                }
            }
            if (invalid) aimTarget = null;
        }

        if (aimTarget == null) {
            List<LivingEntity> candidates = buildAimCandidates(client, cfg, range, fov, fullCircle);
            if (!candidates.isEmpty()) aimTarget = candidates.get(0);
        }
        if (aimTarget == null) return;

        Vec3d delta = getAimPoint(aimTarget).subtract(client.player.getEyePos());
        float targetYaw = yawTo(delta);
        float targetPitch = pitchTo(delta);
        float yawDelta = MathHelper.wrapDegrees(targetYaw - client.player.getYaw());
        float pitchDelta = targetPitch - client.player.getPitch();

        // The old hard 24°/15° caps caused large corrections to move in discrete
        // chunks and made full-circle reacquisition visibly stutter. Exponential
        // easing is frame-interpolated by vanilla between client ticks; there is no
        // artificial step cap or random noise, so high strength stays decisive.
        float strength = MathHelper.clamp((float) cfg.aimBotSmooth, 1.0f, 100.0f) / 100.0f;
        float factor = 0.08f + (float) Math.pow(strength, 0.75) * 0.90f;
        float yawStep = yawDelta * factor;
        float pitchStep = pitchDelta * factor;
        client.player.setYaw(client.player.getYaw() + yawStep);
        client.player.setPitch(MathHelper.clamp(client.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private static List<LivingEntity> buildAimCandidates(MinecraftClient client, ModuleSettings cfg,
                                                         double range, float fov, boolean fullCircle) {
        boolean filterBots = cfg.enabled("anti_bot");
        List<LivingEntity> out = new ArrayList<>();
        double r2 = range * range;
        for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                e -> e != client.player && e.isAlive() && !e.isRemoved() && !e.isSpectator())) {
            if (filterBots && !(entity instanceof PlayerEntity)) continue;
            Vec3d delta = getAimPoint(entity).subtract(client.player.getEyePos());
            double distance2 = delta.lengthSquared();
            if (distance2 > r2 || distance2 < 1.0e-6) continue;
            if (!fullCircle) {
                float halfFov = fov * 0.5f;
                float dyaw = Math.abs(MathHelper.wrapDegrees(yawTo(delta) - client.player.getYaw()));
                float dpitch = Math.abs(pitchTo(delta) - client.player.getPitch());
                if (dyaw > halfFov || dpitch > halfFov) continue;
            }
            out.add(entity);
        }
        // Sort by angular offset (not normalized-vector Euclidean distance), then by range.
        out.sort((a, b) -> {
            Vec3d da = getAimPoint(a).subtract(client.player.getEyePos());
            Vec3d db = getAimPoint(b).subtract(client.player.getEyePos());
            double aa = angularErrorSquared(client, da);
            double ab = angularErrorSquared(client, db);
            int angleOrder = Double.compare(aa, ab);
            return angleOrder != 0 ? angleOrder : Double.compare(da.lengthSquared(), db.lengthSquared());
        });
        return out;
    }

    private static Vec3d getAimPoint(LivingEntity entity) {
        Vec3d velocity = entity.getVelocity();
        return new Vec3d(entity.getX() + velocity.x * 0.8,
                entity.getBoundingBox().minY + entity.getHeight() * 0.55
                        + MathHelper.clamp(velocity.y * 0.25, -0.08, 0.08),
                entity.getZ() + velocity.z * 0.8);
    }

    private static float yawTo(Vec3d delta) {
        return (float) (Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
    }

    private static float pitchTo(Vec3d delta) {
        return (float) -(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))
                * (180.0 / Math.PI));
    }

    private static double angularErrorSquared(MinecraftClient client, Vec3d delta) {
        double yaw = MathHelper.wrapDegrees(yawTo(delta) - client.player.getYaw());
        double pitch = pitchTo(delta) - client.player.getPitch();
        return yaw * yaw + pitch * pitch;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Trigger Bot — crosshair target with an adjustable delay.
    // ─────────────────────────────────────────────────────────────────────

    private static void tickTriggerBot(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("trigger_bot") || client.interactionManager == null) {
            triggerTarget = null;
            triggerFirstSeen = 0;
            return;
        }
        if (client.player.isUsingItem()) {
            triggerTarget = null;
            triggerFirstSeen = 0;
            return;
        }

        LivingEntity target = null;
        if (client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity le
                && le.isAlive() && !le.isRemoved() && !le.isSpectator()
                && le.isAttackable()) {
            double range = cfg.triggerBotRange;
            if (client.player.getEyePos().squaredDistanceTo(le.getEyePos()) <= range * range) {
                target = le;
            }
        }

        long now = client.world.getTime();
        if (target != triggerTarget) {
            triggerTarget = target;
            triggerFirstSeen = now;
            triggerDelay = Math.max(0L, Math.min(10L, Math.round(cfg.triggerBotDelayTicks)));
        }

        if (target == null) return;
        if (now - triggerFirstSeen < triggerDelay) return;

        // Let vanilla attack cooldown control repeat timing. The old extra 8–12 tick
        // interval plus a new delay after every hit made follow-up attacks sluggish.
        if (client.player.getAttackCooldownProgress(0.5f) < 0.90f) return;

        client.interactionManager.attackEntity(client.player, target);
        client.player.swingHand(Hand.MAIN_HAND);
        if (cfg.enabled("kill_effects")) spawnHitEffect(client, target);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Aura  — auto-attack nearest entity; integrates with Criticals
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAura(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("aura") || client.interactionManager == null) return;

        long now = client.world.getTime();
        long interval = 10 + ThreadLocalRandom.current().nextLong(4); // ~0.5–0.7 s
        if (now - auraLastAttack < interval) return;

        double range = cfg.auraRange;
        LivingEntity nearest = null;
        double best = range * range;
        boolean filterBots = cfg.enabled("anti_bot");

        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator())) {
            if (filterBots && !(e instanceof PlayerEntity)) continue;
            double dist = client.player.squaredDistanceTo(e);
            if (dist < best) { best = dist; nearest = e; }
        }

        if (nearest == null) return;
        if (client.player.getAttackCooldownProgress(0.0f) < 0.95f) return;

        // Criticals: only strike after the micro-hop begins falling; the previous
        // implementation attacked on the very next rising tick, so it rarely crit.
        if (cfg.enabled("criticals")) {
            if (!critHopPending && client.player.isOnGround() && !client.player.isInFluid()) {
                Vec3d vel = client.player.getVelocity();
                client.player.setVelocity(vel.x, 0.42, vel.z);
                critHopPending = true;
                return;
            }
            if (critHopPending) {
                if (client.player.isOnGround()) {
                    critHopPending = false;
                } else if (client.player.getVelocity().y >= 0.0) {
                    return; // still rising; wait until downward movement
                } else {
                    critHopPending = false;
                }
            }
        } else {
            critHopPending = false;
        }

        // Smooth snap toward target before striking
        Vec3d delta = nearest.getEyePos().subtract(client.player.getEyePos());
        float tYaw   = (float)(Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
        float tPitch = (float)-(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))
                * (180.0 / Math.PI));
        client.player.setYaw(client.player.getYaw()
                + MathHelper.wrapDegrees(tYaw - client.player.getYaw()) * 0.55f);
        client.player.setPitch(client.player.getPitch()
                + (tPitch - client.player.getPitch()) * 0.55f);

        client.interactionManager.attackEntity(client.player, nearest);
        client.player.swingHand(Hand.MAIN_HAND);
        if (cfg.enabled("kill_effects")) spawnHitEffect(client, nearest);
        auraLastAttack = now;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Reach  — extends entity_interaction_range attribute
    // ─────────────────────────────────────────────────────────────────────

    private static void tickReach(MinecraftClient client, ModuleSettings cfg) {
        if (client.player == null) return;
        boolean enabled = cfg.enabled("reach");
        var attr = client.player.getAttributeInstance(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE);
        if (attr == null) return;

        if (enabled && !reachWasEnabled) {
            attr.addTemporaryModifier(new EntityAttributeModifier(
                    REACH_MOD, cfg.reachExtra, EntityAttributeModifier.Operation.ADD_VALUE));
        } else if (!enabled && reachWasEnabled) {
            attr.removeModifier(REACH_MOD);
        }
        reachWasEnabled = enabled;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Speed  — adds to movement_speed attribute
    // ─────────────────────────────────────────────────────────────────────

    private static void tickSpeed(MinecraftClient client, ModuleSettings cfg) {
        if (client.player == null) return;
        boolean enabled = cfg.enabled("speed");
        var attr = client.player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (attr == null) return;

        if (enabled && !speedWasEnabled) {
            // Base movement speed in MC is ~0.1; add a fraction of the multiplier
            double bonus = 0.020 * cfg.speedMultiplier;
            attr.addTemporaryModifier(new EntityAttributeModifier(
                    SPEED_MOD, bonus, EntityAttributeModifier.Operation.ADD_VALUE));
        } else if (!enabled && speedWasEnabled) {
            attr.removeModifier(SPEED_MOD);
        }
        speedWasEnabled = enabled;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Auto GApple  — eat a golden apple when health < 7 hearts
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAutoGapple(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_gapple") || client.player.isUsingItem()) return;
        if (client.player.getHealth() > 14.0f) return; // > 7 hearts, don't eat
        long worldTick = client.world.getTime();
        if (worldTick - lastAutoGappleTick < 20) return; // cooldown

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (stack.isOf(Items.ENCHANTED_GOLDEN_APPLE)
                    || stack.isOf(Items.GOLDEN_APPLE)) {
                client.player.getInventory().selectedSlot = slot;
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                lastAutoGappleTick = worldTick;
                return;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Additional inventory and movement modules
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAutoArmor(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_armor") || client.interactionManager == null) return;
        long now = client.world.getTime();
        if (now - lastAutoArmorTick < 8) return;
        lastAutoArmorTick = now;
        var inventory = client.player.getInventory();
        for (int invSlot = 9; invSlot < 36; invSlot++) {
            ItemStack stack = inventory.getStack(invSlot);
            if (!(stack.getItem() instanceof ArmorItem armor)) continue;
            EquipmentSlot equipmentSlot = armor.getSlotType();
            if (!client.player.getEquippedStack(equipmentSlot).isEmpty()) continue;
            // PlayerScreenHandler maps the main inventory slots 9..35 directly.
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    invSlot, 0, SlotActionType.QUICK_MOVE, client.player);
            return;
        }
        // Also allow armor to be equipped from the hotbar when its matching armor slot is empty.
        for (int invSlot = 0; invSlot < 9; invSlot++) {
            ItemStack stack = inventory.getStack(invSlot);
            if (!(stack.getItem() instanceof ArmorItem armor)) continue;
            EquipmentSlot equipmentSlot = armor.getSlotType();
            if (!client.player.getEquippedStack(equipmentSlot).isEmpty()) continue;
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    36 + invSlot, 0, SlotActionType.QUICK_MOVE, client.player);
            return;
        }
    }

    private static void tickAutoPotion(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_potion") || client.interactionManager == null
                || client.player.isUsingItem() || client.player.isCreative()
                || client.player.getHealth() > cfg.autoPotionThreshold) return;
        long now = client.world.getTime();
        if (now - lastAutoPotionTick < Math.max(5L, Math.round(cfg.autoPotionCooldownTicks))) return;

        var inventory = client.player.getInventory();
        int potionSlot = findHealingPotionInHotbar(inventory, true);
        if (potionSlot >= 0) {
            throwHealingPotion(client, cfg, potionSlot, now, -1);
            return;
        }

        // No healing potion on the hotbar: borrow the selected slot only for the throw,
        // then swap the previous held item back from the inventory source slot.
        int sourceSlot = findHealingPotionInMainInventory(inventory, true);
        if (sourceSlot >= 0) {
            int temporaryHotbarSlot = inventory.selectedSlot;
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    sourceSlot, temporaryHotbarSlot, SlotActionType.SWAP, client.player);
            if (hasPotionEffect(inventory.getStack(temporaryHotbarSlot), StatusEffects.INSTANT_HEALTH)
                    || hasPotionEffect(inventory.getStack(temporaryHotbarSlot), StatusEffects.REGENERATION)) {
                throwHealingPotion(client, cfg, temporaryHotbarSlot, now, sourceSlot);
            } else {
                client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                        sourceSlot, temporaryHotbarSlot, SlotActionType.SWAP, client.player);
            }
        }
    }

    /** sourceSlotToRestore >= 0 means the potion was borrowed from main inventory temporarily. */
    private static void throwHealingPotion(MinecraftClient client, ModuleSettings cfg, int potionSlot,
                                           long now, int sourceSlotToRestore) {
        var inventory = client.player.getInventory();
        int oldSlot = inventory.selectedSlot;
        float oldPitch = client.player.getPitch();
        ItemStack potionStack = inventory.getStack(potionSlot);
        PotionContentsComponent contents = potionStack.get(DataComponentTypes.POTION_CONTENTS);
        try {
            inventory.selectedSlot = potionSlot;
            client.player.setPitch(90.0f);
            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
            lastAutoPotionTick = now;
        } finally {
            client.player.setPitch(oldPitch);
            inventory.selectedSlot = oldSlot;
            if (sourceSlotToRestore >= 0) {
                // Always restore the displaced item even if item-use throws an exception.
                client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                        sourceSlotToRestore, potionSlot, SlotActionType.SWAP, client.player);
            }
        }
        if (sourceSlotToRestore < 0 && cfg.enabled("potion_refill") && contents != null) {
            // Keep the last contents because the client stack may already be empty after use prediction.
            pendingPotionContents[potionSlot] = contents;
            pendingPotionRefillAt[potionSlot] = now;
        }
    }

    private static int findHealingPotionInHotbar(net.minecraft.entity.player.PlayerInventory inventory,
                                                  boolean allowRegeneration) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (hasPotionEffect(stack, StatusEffects.INSTANT_HEALTH)) return i;
        }
        if (allowRegeneration) {
            for (int i = 0; i < 9; i++) {
                if (hasPotionEffect(inventory.getStack(i), StatusEffects.REGENERATION)) return i;
            }
        }
        return -1;
    }

    private static int findHealingPotionInMainInventory(net.minecraft.entity.player.PlayerInventory inventory,
                                                         boolean allowRegeneration) {
        for (int i = 9; i < 36; i++) {
            if (hasPotionEffect(inventory.getStack(i), StatusEffects.INSTANT_HEALTH)) return i;
        }
        if (allowRegeneration) {
            for (int i = 9; i < 36; i++) {
                if (hasPotionEffect(inventory.getStack(i), StatusEffects.REGENERATION)) return i;
            }
        }
        return -1;
    }

    private static boolean hasPotionEffect(ItemStack stack,
            net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effectType) {
        if (!(stack.getItem() instanceof SplashPotionItem)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (StatusEffectInstance effect : contents.getEffects()) {
            if (effect.getEffectType().equals(effectType)) return true;
        }
        return false;
    }

    /** Refill a consumed splash-potion slot with the same potion from slots 9–35. */
    private static void tickPotionRefill(MinecraftClient client, ModuleSettings cfg) {
        if (client.interactionManager == null) return;
        var inventory = client.player.getInventory();
        long now = client.world.getTime();
        boolean enabled = cfg.enabled("potion_refill");

        if (enabled) {
            for (int hotbar = 0; hotbar < 9; hotbar++) {
                ItemStack previous = previousHotbarPotionStacks[hotbar];
                ItemStack current = inventory.getStack(hotbar);
                if (previous != null && previous.getItem() instanceof SplashPotionItem
                        && current.isEmpty() && pendingPotionContents[hotbar] == null) {
                    PotionContentsComponent contents = previous.get(DataComponentTypes.POTION_CONTENTS);
                    if (contents != null) {
                        pendingPotionContents[hotbar] = contents;
                        pendingPotionRefillAt[hotbar] = now;
                    }
                }

                PotionContentsComponent wanted = pendingPotionContents[hotbar];
                if (wanted == null || now - pendingPotionRefillAt[hotbar] < 1L || !current.isEmpty()) continue;
                int source = -1;
                for (int invSlot = 9; invSlot < 36; invSlot++) {
                    ItemStack candidate = inventory.getStack(invSlot);
                    if (candidate.getItem() instanceof SplashPotionItem
                            && wanted.equals(candidate.get(DataComponentTypes.POTION_CONTENTS))) {
                        source = invSlot;
                        break;
                    }
                }
                if (source >= 0) {
                    client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                            source, hotbar, SlotActionType.SWAP, client.player);
                    pendingPotionContents[hotbar] = null;
                    pendingPotionRefillAt[hotbar] = 0L;
                } else if (now - pendingPotionRefillAt[hotbar] > 60L) {
                    pendingPotionContents[hotbar] = null;
                    pendingPotionRefillAt[hotbar] = 0L;
                }
            }
        } else {
            for (int i = 0; i < 9; i++) {
                pendingPotionContents[i] = null;
                pendingPotionRefillAt[i] = 0L;
            }
        }

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            previousHotbarPotionStacks[i] = stack.isEmpty() ? ItemStack.EMPTY : stack.copy();
        }
    }

    private static void tickAutoSoup(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_soup") || client.interactionManager == null
                || client.player.isUsingItem() || client.player.getHealth() > 14.0f) return;
        long now = client.world.getTime();
        if (now - lastAutoSoupTick < 8) return;
        for (int slot = 0; slot < 9; slot++) {
            if (client.player.getInventory().getStack(slot).isOf(Items.MUSHROOM_STEW)) {
                client.player.getInventory().selectedSlot = slot;
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                lastAutoSoupTick = now;
                return;
            }
        }
    }

    private static void tickAutoTotem(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_totem") || client.interactionManager == null
                || client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        long now = client.world.getTime();
        if (now - lastAutoTotemTick < 10) return;
        var inventory = client.player.getInventory();
        for (int invSlot = 0; invSlot < inventory.size(); invSlot++) {
            if (!inventory.getStack(invSlot).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int screenSlot = invSlot < 9 ? 36 + invSlot : invSlot;
            if (invSlot >= 36) continue; // armor/offhand slots are not inventory source slots
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    screenSlot, 40, SlotActionType.SWAP, client.player);
            lastAutoTotemTick = now;
            return;
        }
    }

    private static void tickAutoFarm(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_farm") || client.interactionManager == null) {
            farmBreakPos = null;
            return;
        }
        if (!(client.crosshairTarget instanceof BlockHitResult hit)) {
            farmBreakPos = null;
            return;
        }
        BlockPos pos = hit.getBlockPos();
        BlockState state = client.world.getBlockState(pos);
        if (!(state.getBlock() instanceof CropBlock crop) || !crop.isMature(state)) {
            farmBreakPos = null;
            return;
        }
        if (!pos.equals(farmBreakPos)) {
            farmBreakPos = pos.toImmutable();
            client.interactionManager.attackBlock(pos, hit.getSide());
        }
        client.interactionManager.updateBlockBreakingProgress(pos, hit.getSide());
    }

    private static void tickFlight(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("flight") || client.player.isFallFlying()) return;
        var player = client.player;
        Vec3d velocity = player.getVelocity();
        double vertical = client.options.jumpKey.isPressed() ? 0.32
                : client.options.sneakKey.isPressed() ? -0.32 : 0.0;
        player.setVelocity(velocity.x, vertical, velocity.z);
        player.fallDistance = 0.0f;
    }

    private static void tickSpider(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("spider") || !client.player.horizontalCollision) return;
        if (client.options.forwardKey.isPressed() || client.options.jumpKey.isPressed()) {
            Vec3d velocity = client.player.getVelocity();
            client.player.setVelocity(velocity.x, 0.2, velocity.z);
        }
    }

    private static void tickElytraStrafe(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("elytra_strafe") || !client.player.isFallFlying()) return;
        double side = (client.options.rightKey.isPressed() ? 1.0 : 0.0)
                - (client.options.leftKey.isPressed() ? 1.0 : 0.0);
        if (side == 0.0) return;
        double yaw = Math.toRadians(client.player.getYaw());
        client.player.addVelocity(Math.cos(yaw) * side * 0.035, 0.0,
                Math.sin(yaw) * side * 0.035);
    }

    private static void tickWindHop(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("wind_hop") || !client.player.isOnGround()
                || !(client.options.forwardKey.isPressed() || client.options.backKey.isPressed()
                || client.options.leftKey.isPressed() || client.options.rightKey.isPressed())) return;
        long now = client.world.getTime();
        if (now - lastWindHopTick < 8) return;
        client.player.jump();
        lastWindHopTick = now;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Existing helpers (unchanged logic, no PracticeWorldGuard)
    // ─────────────────────────────────────────────────────────────────────

    private static void tickAutoTool(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_tool") || !(client.crosshairTarget instanceof BlockHitResult hit)) return;
        var state = client.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return;
        int bestSlot = client.player.getInventory().selectedSlot;
        float bestSpeed = client.player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int slot = 0; slot < 9; slot++) {
            float speed = client.player.getInventory().getStack(slot).getMiningSpeedMultiplier(state);
            if (speed > bestSpeed * 1.05f) { bestSpeed = speed; bestSlot = slot; }
        }
        client.player.getInventory().selectedSlot = bestSlot;
    }

    private static void tickAutoEat(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_eat")
                || client.player.isUsingItem()
                || client.player.getHungerManager().getFoodLevel() > 14) return;
        long tick = client.world.getTime();
        if (tick - lastEatTick < 8) return;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (stack.contains(DataComponentTypes.FOOD)) {
                client.player.getInventory().selectedSlot = slot;
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                lastEatTick = tick;
                return;
            }
        }
    }

    private static void tickFullbright(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("fullbright");
        if (enabled && !fullbrightWasEnabled) originalGamma = client.options.getGamma().getValue();
        if (enabled)               client.options.getGamma().setValue(1.0);
        else if (fullbrightWasEnabled) client.options.getGamma().setValue(originalGamma);
        fullbrightWasEnabled = enabled;
    }

    private static void tickZoom(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("zoom");
        if (enabled && !zoomWasEnabled) originalFov = client.options.getFov().getValue();
        if (enabled)              client.options.getFov().setValue(30);
        else if (zoomWasEnabled)  client.options.getFov().setValue(originalFov);
        zoomWasEnabled = enabled;
    }

    private static void spawnHitEffect(MinecraftClient client, LivingEntity target) {
        if (client.world == null || target == null) return;
        for (int i = 0; i < 6; i++) {
            double ox = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.8;
            double oz = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.8;
            client.world.addParticle(ParticleTypes.CRIT, target.getX() + ox,
                    target.getY() + target.getHeight() * 0.6, target.getZ() + oz,
                    ox * 0.2, 0.08, oz * 0.2);
        }
    }

    private static boolean isHoldingCombatWeapon(MinecraftClient client) {
        if (client == null || client.player == null) return false;
        var item = client.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem
                || item instanceof MaceItem || item instanceof TridentItem;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  HUD
    // ─────────────────────────────────────────────────────────────────────

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null
                || client.options.hudHidden) return;
        ModuleSettings cfg = ModuleSettings.get();
        int x = 6, y = 6, line = 11;
        if (cfg.enabled("arrows")) renderTargetArrows(context, client);

        if (cfg.enabled("watermark_hud")) { draw(context, "DAMN SON  /  1.21", x, y, 0xFFC39AFF); y += line; }
        if (cfg.enabled("fps_hud"))       { draw(context, "FPS  " + client.getCurrentFps(), x, y); y += line; }
        if (cfg.enabled("coordinates_hud")) {
            draw(context, String.format(Locale.ROOT, "XYZ  %d / %d / %d",
                    client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ()), x, y);
            y += line;
            draw(context, "DIM  " + client.world.getRegistryKey().getValue().getPath(), x, y);
            y += line;
        }
        if (cfg.enabled("ping_hud")) {
            var handler = client.getNetworkHandler();
            var entry   = handler == null ? null : handler.getPlayerListEntry(client.player.getUuid());
            draw(context, "PING  " + (entry == null ? "--" : entry.getLatency() + " ms"), x, y);
            y += line;
        }
        if (cfg.enabled("biome_hud")) {
            String biome = client.world.getBiome(client.player.getBlockPos()).getKey()
                    .map(k -> k.getValue().getPath()).orElse("unknown");
            draw(context, "BIOME  " + biome, x, y); y += line;
        }
        if (cfg.enabled("direction_hud")) {
            String[] dirs = {"S","SW","W","NW","N","NE","E","SE"};
            draw(context, "FACING  " + dirs[Math.floorMod(Math.round(client.player.getYaw() / 45.0f), 8)], x, y);
            y += line;
        }
        if (cfg.enabled("speed_hud")) {
            draw(context, String.format(Locale.ROOT, "SPEED  %.2f m/s", horizontalSpeed), x, y); y += line;
        }
        if (cfg.enabled("clock_hud")) {
            long time = Math.floorMod(client.world.getTimeOfDay() + 6000L, 24000L);
            draw(context, String.format(Locale.ROOT, "TIME  %02d:%02d",
                    (int)(time / 1000L), (int)(time % 1000L * 60L / 1000L)), x, y);
            y += line;
        }
        if (cfg.enabled("armor_hud")) {
            StringBuilder armor = new StringBuilder("ARMOR  ");
            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}) {
                ItemStack stack = client.player.getEquippedStack(slot);
                if (stack.isEmpty()) armor.append("--  ");
                else if (stack.isDamageable()) {
                    int remaining = 100 - Math.round(stack.getDamage() * 100.0f / stack.getMaxDamage());
                    armor.append(remaining).append("%  ");
                } else armor.append("OK  ");
            }
            draw(context, armor.toString().trim(), x, y); y += line;
        }
        if (cfg.enabled("keystrokes_hud")) {
            drawKey(context, "W",    client.options.forwardKey.isPressed(),  x + 22, y + 1);
            drawKey(context, "A",    client.options.leftKey.isPressed(),     x,      y + 23);
            drawKey(context, "S",    client.options.backKey.isPressed(),     x + 22, y + 23);
            drawKey(context, "D",    client.options.rightKey.isPressed(),    x + 44, y + 23);
            drawKey(context, "SPC",  client.options.jumpKey.isPressed(),     x,      y + 45, 66);
            y += 68;
        }

        // ── ESP: draw name tags through walls ───────────────────────────
        if (cfg.enabled("esp") || cfg.enabled("name_tags") || cfg.enabled("anti_invisible")) {
            // We render via the HUD callback using world→screen projection.
            // The HUD context is 2D, so we use MinecraftClient's camera matrices.
            renderEspOverlay(context, client, cfg);
        }

        // ── Array list (right side) ──────────────────────────────────────
        if (cfg.enabled("array_list_hud")) {
            List<String> active = new ArrayList<>();
            for (ModuleCatalog.Module m : ModuleCatalog.MODULES) {
                if (cfg.enabled(m.id()) && !m.id().endsWith("_hud")) active.add(m.name());
            }
            int ay = 7;
            for (String name : active) {
                int tw = client.textRenderer.getWidth(name);
                int ax = client.getWindow().getScaledWidth() - tw - 12;
                context.fill(ax - 4, ay - 2, ax + tw + 6, ay + 10, 0xA8080D18);
                context.fill(ax + tw + 3, ay - 2, ax + tw + 6, ay + 10, 0xFF9C69FF);
                context.drawTextWithShadow(client.textRenderer, name, ax, ay, 0xFFF0E8FF);
                ay += 12;
            }
        }
    }

    private static void renderTargetArrows(DrawContext context, MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        int centerX = client.getWindow().getScaledWidth() / 2;
        int centerY = client.getWindow().getScaledHeight() / 2;
        for (PlayerEntity target : client.world.getPlayers()) {
            if (target == client.player || !target.isAlive()) continue;
            double dx = target.getX() - client.player.getX();
            double dz = target.getZ() - client.player.getZ();
            double distance = Math.sqrt(dx * dx + dz * dz);
            if (distance > 64.0 || distance < 0.1) continue;
            float bearing = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
            float relative = MathHelper.wrapDegrees(bearing - client.player.getYaw());
            double rad = Math.toRadians(relative - 90.0f);
            int radius = 58;
            int ax = centerX + (int) (Math.cos(rad) * radius);
            int ay = centerY + (int) (Math.sin(rad) * radius);
            int color = target.isInvisible() ? 0xFFFFC36B : 0xFFFF6B9D;
            context.drawCenteredTextWithShadow(client.textRenderer, "▲", ax, ay, color);
        }
    }

    /**
     * Simple ESP: project entity eye position to screen and draw a name/health label.
     * Falls back gracefully if the projection yields off-screen coordinates.
     */
    private static void renderEspOverlay(DrawContext context, MinecraftClient client, ModuleSettings cfg) {
        if (client.world == null || client.player == null) return;
        net.minecraft.client.render.Camera camera = client.gameRenderer.getCamera();
        net.minecraft.client.util.math.MatrixStack ms = new net.minecraft.client.util.math.MatrixStack();

        org.joml.Matrix4f projView = new org.joml.Matrix4f(client.gameRenderer.getBasicProjectionMatrix(client.options.getFov().getValue()))
                .mul(new org.joml.Matrix4f().rotation(
                        (float)Math.toRadians(camera.getPitch()), 1,0,0).rotateY(
                        (float)Math.toRadians(camera.getYaw() + 180f)));

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();

        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(64),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator())) {

            Vec3d camPos   = camera.getPos();
            Vec3d entityEye = e.getEyePos();
            double rx = entityEye.x - camPos.x;
            double ry = entityEye.y - camPos.y + 0.3;
            double rz = entityEye.z - camPos.z;

            org.joml.Vector4f clip = projView.transform(new org.joml.Vector4f((float)rx, (float)ry, (float)rz, 1.0f));
            if (clip.w <= 0) continue; // behind camera
            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;
            if (Math.abs(ndcX) > 1.1f || Math.abs(ndcY) > 1.1f) continue; // off-screen

            int sx = (int)((ndcX + 1.0f) * 0.5f * sw);
            int sy = (int)((1.0f - ndcY) * 0.5f * sh);

            String label;
            int color;
            if (e instanceof PlayerEntity pe) {
                if (!cfg.enabled("esp") && !cfg.enabled("name_tags")
                        && !(cfg.enabled("anti_invisible") && pe.isInvisible())) continue;
                float hp = e.getMaxHealth() <= 0.0f ? 0.0f : e.getHealth() / e.getMaxHealth();
                label = pe.getName().getString();
                if (cfg.enabled("name_tags")) label += String.format(Locale.ROOT, "  %.0f HP", e.getHealth());
                color = hpColor(hp);
            } else {
                if (!cfg.enabled("esp")) continue; // non-player labels require ESP
                label = e.getType().getName().getString();
                color = 0xFFCCCCCC;
            }

            int tw = client.textRenderer.getWidth(label);
            context.fill(sx - tw/2 - 3, sy - 11, sx + tw/2 + 3, sy + 1, 0x88000000);
            context.drawCenteredTextWithShadow(client.textRenderer, label, sx, sy - 9, color);
        }
    }

    private static int hpColor(float fraction) {
        fraction = MathHelper.clamp(fraction, 0.0f, 1.0f);
        int r = (int)((1.0f - fraction) * 255);
        int g = (int)(fraction * 220);
        return 0xFF000000 | (r << 16) | (g << 8);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Draw helpers
    // ─────────────────────────────────────────────────────────────────────

    private static void draw(DrawContext context, String value, int x, int y) {
        draw(context, value, x, y, 0xFFE5F4FF);
    }

    private static void draw(DrawContext context, String value, int x, int y, int color) {
        MinecraftClient client = MinecraftClient.getInstance();
        context.fill(x - 3, y - 2, x + client.textRenderer.getWidth(value) + 5, y + 10, 0x99060B16);
        context.drawTextWithShadow(client.textRenderer, Text.literal(value), x, y, color);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y) {
        drawKey(context, label, pressed, x, y, 20);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y, int width) {
        context.fill(x, y, x + width, y + 19, pressed ? 0xFF26769B : 0xD90B1422);
        context.fill(x, y, x + width, y + 1,  pressed ? 0xFF6DE0FF : 0xFF526780);
        context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer,
                label, x + width / 2, y + 5, 0xFFF4FAFF);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Util
    // ─────────────────────────────────────────────────────────────────────

    private static float clampF(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
