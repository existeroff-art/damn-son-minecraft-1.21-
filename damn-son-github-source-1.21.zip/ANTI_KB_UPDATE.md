# Anti-KB status (v0.6.6)

- Anti-KB stays restricted to a solo integrated world using PracticeWorldGuard.
- The menu exposes only its module toggle keybind, not horizontal/vertical sliders.
- Default practice profile retains 50% of horizontal velocity and 100% of vertical velocity.
- No anti-cheat bypass or undetectability claim is made.
