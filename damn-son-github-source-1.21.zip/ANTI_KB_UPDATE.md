# Anti-KB update — v0.6.2

- Removed the single-player-only condition from the local velocity-update mixin.
- The mixin now checks local player/world state and the entity ID, then scales the local player's received velocity in either single-player or multiplayer sessions.
- Set new-install defaults to 0% retained horizontal and vertical velocity (full client-side suppression of that velocity update). Existing user settings are preserved.
- Bumped config version to 9, project version to 0.6.2, and UI version label to v0.6.2.
- Opens module settings on Anti-KB by default.
- Preserved Right Shift menu, horizontal/vertical sliders, config save/load, keybinds, sounds, and existing utility modules.

## Limits

The modification is client-side. A server may correct velocity or reject/disallow the behavior; compatibility and effectiveness cannot be guaranteed for every server. The provided source does not claim to bypass anti-cheat systems.
