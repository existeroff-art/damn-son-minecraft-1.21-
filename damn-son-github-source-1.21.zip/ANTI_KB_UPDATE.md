# Anti-KB update — v0.6.4

- Anti-KB remains restricted to a solo integrated single-player world.
- Removed the horizontal/vertical sliders from the GUI. Anti-KB now uses a fixed practice preset.
- Preset: retain 50% of horizontal velocity and 100% of vertical velocity.
- Use the module's existing keybind to toggle it.
- This preset is not a promise of multiplayer compatibility or anti-cheat safety.
