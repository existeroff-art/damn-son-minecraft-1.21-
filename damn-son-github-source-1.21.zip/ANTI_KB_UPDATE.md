# Anti-KB update — v0.6.3

- Horizontal and vertical retained-velocity sliders remain configurable.
- The mixin checks that Minecraft is in an integrated single-player world before changing local velocity.
- No multiplayer bypass, stealth, or anti-cheat evasion is implemented.
- Runtime compilation/in-game behavior must still be tested with the target Minecraft/Fabric setup.
