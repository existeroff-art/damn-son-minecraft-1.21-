package com.damnson.client;

import net.minecraft.util.math.MathHelper;

import java.util.Random;

/**
 * Bypass — makes cheat behaviour look like normal player variance.
 *
 * Four independent systems, all toggled by the single "bypass" module flag:
 *
 *  1. TimingJitter   — adds small random offsets to action timing so packets
 *                      don't arrive at perfectly uniform intervals (Grim/Vulcan
 *                      flag machine-perfect tick cadence).
 *
 *  2. RotationClamp  — hard-caps the yaw/pitch delta applied per render frame
 *                      so no single frame produces an impossible camera jump.
 *                      Grim's rotation check compares delta against a CPS-scaled
 *                      human maximum; staying under that threshold avoids the flag.
 *
 *  3. ActionThrottle — tracks actions-per-second and suppresses extras when the
 *                      rate would exceed a configurable cap. Keeps pot use, attack
 *                      clicks, and item switches inside the band a human could
 *                      plausibly produce.
 *
 *  4. MovementSmooth — smooths large velocity deltas across two ticks so the
 *                      physics integrator never sees a step it couldn't explain
 *                      with normal player input.
 *
 * None of these make the cheat invisible — a determined anticheat can notice
 * anything over time. They reduce the per-action signal so the cheat stays
 * inside the envelope the server considers "plausible human."
 */
public final class BypassModule {

    // ── Shared RNG ────────────────────────────────────────────────────────────
    private static final Random RNG = new Random();

    // ── Timing jitter state ───────────────────────────────────────────────────
    // Extra ticks to hold before allowing the next action of each class.
    private static int jitterPotTicks   = 0;
    private static int jitterAttackTicks = 0;
    private static int jitterSwapTicks  = 0;

    // ── Rotation clamp constants ──────────────────────────────────────────────
    // Maximum yaw/pitch movement per render frame (~60 fps) that looks human.
    // Real players rarely exceed ~18°/frame at high sensitivity; we use 22° to
    // give aim assist room while still blocking the 90°-in-one-frame jumps that
    // Grim flags immediately.
    private static final float MAX_YAW_PER_FRAME   = 22.0f;
    private static final float MAX_PITCH_PER_FRAME = 16.0f;

    // ── Action throttle state ─────────────────────────────────────────────────
    // We track the timestamp (in ms) of the last N actions of each class to
    // compute a rolling rate and suppress when the rate is too high.
    private static final int   WINDOW_SIZE = 8;
    private static final long[] attackTimes = new long[WINDOW_SIZE];
    private static final long[] potTimes    = new long[WINDOW_SIZE];
    private static int attackHead = 0;
    private static int potHead    = 0;

    // ── Movement smooth state ─────────────────────────────────────────────────
    private static double prevVelX = 0.0;
    private static double prevVelZ = 0.0;

    private BypassModule() {}

    // ─────────────────────────────────────────────────────────────────────────
    // 1. Timing jitter
    // ─────────────────────────────────────────────────────────────────────────

    /** Call once per client tick to decrement jitter counters. */
    public static void tick() {
        if (jitterPotTicks    > 0) jitterPotTicks--;
        if (jitterAttackTicks > 0) jitterAttackTicks--;
        if (jitterSwapTicks   > 0) jitterSwapTicks--;
    }

    /**
     * Returns true when a potion-use action is allowed this tick.
     * On allow, arms the jitter counter for the next use.
     */
    public static boolean allowPotionAction(ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return true;
        if (jitterPotTicks > 0) return false;
        // 0–2 extra ticks of random hold after cooldown expires.
        jitterPotTicks = RNG.nextInt(3);
        return true;
    }

    /**
     * Returns true when an attack action is allowed this tick.
     * On allow, arms the jitter counter for the next attack.
     */
    public static boolean allowAttackAction(ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return true;
        if (jitterAttackTicks > 0) return false;
        // 0–1 extra tick jitter on attacks — small enough not to hurt CPS.
        jitterAttackTicks = RNG.nextInt(2);
        return true;
    }

    /**
     * Returns true when a hotbar-swap action is allowed this tick.
     */
    public static boolean allowSwapAction(ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return true;
        if (jitterSwapTicks > 0) return false;
        jitterSwapTicks = RNG.nextInt(2);
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. Rotation clamp
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Clamps a yaw delta to the per-frame maximum when bypass is active.
     * Pass the raw delta; receive the clamped delta to apply instead.
     */
    public static float clampYawDelta(float delta, ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return delta;
        return MathHelper.clamp(delta, -MAX_YAW_PER_FRAME, MAX_YAW_PER_FRAME);
    }

    /**
     * Clamps a pitch delta to the per-frame maximum when bypass is active.
     */
    public static float clampPitchDelta(float delta, ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return delta;
        return MathHelper.clamp(delta, -MAX_PITCH_PER_FRAME, MAX_PITCH_PER_FRAME);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. Action throttle
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Record a real attack and return false if the current rolling rate is
     * already above the cap (meaning this attack should be suppressed).
     *
     * Max CPS cap: 16 — well above human but below what a macro at 20 tps
     * looks like to Grim's CPS checker.
     */
    public static boolean recordAndAllowAttack(ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return true;
        long now = System.currentTimeMillis();
        double cps = rollingRate(attackTimes, attackHead, now);
        if (cps > 16.0) return false;
        attackTimes[attackHead] = now;
        attackHead = (attackHead + 1) % WINDOW_SIZE;
        return true;
    }

    /**
     * Record a potion use and return false if the rolling pot-use rate would
     * look automated (more than 4 pots per second is flaggable on most servers).
     */
    public static boolean recordAndAllowPot(ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) return true;
        long now = System.currentTimeMillis();
        double rate = rollingRate(potTimes, potHead, now);
        if (rate > 4.0) return false;
        potTimes[potHead] = now;
        potHead = (potHead + 1) % WINDOW_SIZE;
        return true;
    }

    private static double rollingRate(long[] times, int head, long now) {
        // Oldest sample is at head (circular buffer). If it's 0 the window isn't
        // full yet — use only filled entries.
        long oldest = times[head];
        if (oldest == 0L) return 0.0;
        double windowSeconds = Math.max(0.001, (now - oldest) / 1000.0);
        return WINDOW_SIZE / windowSeconds;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. Movement smooth
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Smooths a requested velocity so large jumps are spread across two ticks.
     * Returns the velocity to apply this tick; the remainder is carried over.
     *
     * Call with the velocity your cheat wants to apply; use the returned value
     * instead.  xz-only — vertical is left alone to avoid fighting gravity.
     */
    public static double[] smoothVelocityXZ(double wantX, double wantZ, ModuleSettings cfg) {
        if (!cfg.enabled("bypass")) {
            prevVelX = wantX;
            prevVelZ = wantZ;
            return new double[]{wantX, wantZ};
        }
        // Lerp 60% toward target each tick — aggressive enough to reach the
        // target in 2 ticks but smooth enough not to produce a step change.
        double factor = 0.60;
        double outX = prevVelX + (wantX - prevVelX) * factor;
        double outZ = prevVelZ + (wantZ - prevVelZ) * factor;
        prevVelX = outX;
        prevVelZ = outZ;
        return new double[]{outX, outZ};
    }

    /** Reset all stateful smoothing when the player rejoins or changes world. */
    public static void resetState() {
        jitterPotTicks    = 0;
        jitterAttackTicks = 0;
        jitterSwapTicks   = 0;
        prevVelX = 0.0;
        prevVelZ = 0.0;
        for (int i = 0; i < WINDOW_SIZE; i++) {
            attackTimes[i] = 0L;
            potTimes[i]    = 0L;
        }
        attackHead = 0;
        potHead    = 0;
    }
}
