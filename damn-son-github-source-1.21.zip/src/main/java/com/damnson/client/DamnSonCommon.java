package com.damnson.client;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DamnSonCommon implements ModInitializer {
    private static final Map<UUID, Boolean> FAST_GAPPLE_BY_PLAYER = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(FastGappleTogglePayload.ID, FastGappleTogglePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(FastGappleTogglePayload.ID, (payload, context) ->
                context.server().execute(() -> FAST_GAPPLE_BY_PLAYER.put(context.player().getUuid(), payload.enabled())));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                FAST_GAPPLE_BY_PLAYER.putIfAbsent(handler.player.getUuid(), false));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                FAST_GAPPLE_BY_PLAYER.remove(handler.player.getUuid()));
    }

    public static boolean isFastGappleEnabled(ServerPlayerEntity player) {
        return FAST_GAPPLE_BY_PLAYER.getOrDefault(player.getUuid(), false);
    }

    public static void setFastGappleEnabled(UUID playerId, boolean enabled) {
        FAST_GAPPLE_BY_PLAYER.put(playerId, enabled);
    }
}
