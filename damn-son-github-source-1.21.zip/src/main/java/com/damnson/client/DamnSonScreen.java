package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

/** Minimal, flat client menu with category tabs, module toggles, keybind capture and settings. */
public final class DamnSonScreen extends Screen {
    private static final String[] CATEGORIES = {"COMBAT", "MOVEMENT", "RENDER", "PLAYER", "HUD", "MISC"};

    private static final int BACKDROP = 0xB8070B12;
    private static final int PANEL = 0xFF101722;
    private static final int PANEL_INNER = 0xFF121B27;
    private static final int SIDEBAR = 0xFF0C121B;
    private static final int ROW = 0xFF17212E;
    private static final int ROW_HOVER = 0xFF202D3D;
    private static final int BORDER = 0xFF263446;
    private static final int ACCENT = 0xFF58D7C4;
    private static final int ACCENT_ALT = 0xFF9B8AFF;
    private static final int TEXT = 0xFFF1F5FA;
    private static final int MUTED = 0xFF8D9BAE;
    private static final int GOOD = 0xFF79E6B4;

    private final ModuleSettings cfg = ModuleSettings.get();
    private String category = "COMBAT";
    private String listeningFor = "";
    private String selectedModule = "anti_kb";
    private boolean settingsMode;
    private int scrollOffset;
    private int panelX, panelY, panelW, panelH, sideW, contentX, contentW, listY, listBottom;

    public DamnSonScreen() { super(Text.literal("Damn Son | Client")); }

    @Override
    protected void init() {
        panelW = Math.min(920, Math.max(360, width - 24));
        panelH = Math.min(520, Math.max(300, height - 24));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        sideW = Math.min(154, Math.max(94, panelW / 5));
        contentX = panelX + sideW + 16;
        contentW = panelX + panelW - 16 - contentX;
        listY = panelY + 91;
        listBottom = panelY + panelH - 50;

        int navY = panelY + 105;
        for (int i = 0; i < CATEGORIES.length; i++) {
            String nav = CATEGORIES[i];
            addButton((category.equals(nav) && !settingsMode ? "●  " : "   ") + nav,
                    panelX + 9, navY + i * 27, sideW - 18, 23, () -> {
                        category = nav;
                        settingsMode = false;
                        scrollOffset = 0;
                        clickSound();
                        clearAndInit();
                    });
        }

        if (!settingsMode) buildModuleList();
        else buildSettingsPage();

        int footerY = panelY + panelH - 32;
        int rightX = panelX + panelW - 14;
        int closeW = 66;
        int saveW = 60;
        addButton(settingsMode ? "←  BACK" : "MODULE SETTINGS",
                contentX, footerY, Math.min(150, Math.max(86, contentW - 220)), 22, () -> {
                    settingsMode = !settingsMode;
                    clickSound();
                    clearAndInit();
                });
        if (panelW >= 500) {
            addButton("LOAD", rightX - closeW - saveW - 12 - 58, footerY, 58, 22, () -> {
                cfg.reload(); clickSound(); clearAndInit();
            });
        }
        addButton("SAVE", rightX - closeW - 6 - saveW, footerY, saveW, 22, () -> {
            cfg.save(); clickSound();
        });
        addButton("CLOSE", rightX - closeW, footerY, closeW, 22, this::close);
    }

    private void addButton(String label, int x, int y, int buttonWidth, int buttonHeight, Runnable action) {
        addDrawableChild(new StyledButton(x, y, buttonWidth, buttonHeight, Text.literal(label), action));
    }

    private void buildModuleList() {
        List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(category);
        int rowStep = 28;
        int visible = Math.max(1, (listBottom - listY) / rowStep);
        scrollOffset = Math.max(0, Math.min(scrollOffset, Math.max(0, modules.size() - visible)));
        for (int visibleIndex = 0; visibleIndex < visible; visibleIndex++) {
            int i = visibleIndex + scrollOffset;
            if (i >= modules.size()) break;
            ModuleCatalog.Module module = modules.get(i);
            int y = listY + visibleIndex * rowStep;
            int keyW = Math.min(82, Math.max(56, contentW / 4));
            int gap = 7;
            int toggleW = contentW - keyW - gap;
            boolean enabled = cfg.enabled(module.id());
            addButton(module.name() + "  ·  " + (enabled ? "ON" : "OFF"),
                    contentX, y, toggleW, 23, () -> {
                        selectedModule = module.id();
                        cfg.setEnabled(module.id(), !cfg.enabled(module.id()));
                        cfg.save();
                        if ("fast_gapple".equals(module.id())) DamnSonClient.syncFastGappleToggle();
                        toggleSound(cfg.enabled(module.id()));
                        clearAndInit();
                    });
            addButton(listeningFor.equals(module.id()) ? "PRESS KEY" : keyName(cfg.keybind(module.id())),
                    contentX + toggleW + gap, y, keyW, 23, () -> {
                        listeningFor = module.id();
                        clickSound();
                        clearAndInit();
                    });
        }
        if (modules.size() > visible) {
            addButton("↑", contentX + contentW - 50, panelY + 61, 22, 20, () -> {
                scrollOffset = Math.max(0, scrollOffset - 1);
                clickSound();
                clearAndInit();
            });
            addButton("↓", contentX + contentW - 24, panelY + 61, 22, 20, () -> {
                scrollOffset = Math.min(modules.size() - visible, scrollOffset + 1);
                clickSound();
                clearAndInit();
            });
        }
    }

    private void buildSettingsPage() {
        ModuleCatalog.Module module = ModuleCatalog.byId(selectedModule);
        String description = module == null ? "Choose a module to view settings." : module.description();
        int x = contentX + 5;
        int w = contentW - 10;
        int y = listY;
        addButton("RESET KEYBIND", x, y, w, 23, () -> {
            cfg.setKeybind(selectedModule, 0);
            cfg.save();
            clickSound();
            clearAndInit();
        });
        y += 31;
        addButton(description, x, y, w, 30, this::clickSound);
        y += 38;
        addButton("Toggle module  ·  " + (cfg.enabled(selectedModule) ? "ON" : "OFF"), x, y, w, 23, () -> {
            cfg.setEnabled(selectedModule, !cfg.enabled(selectedModule));
            cfg.save();
            if ("fast_gapple".equals(selectedModule)) DamnSonClient.syncFastGappleToggle();
            toggleSound(cfg.enabled(selectedModule));
            clearAndInit();
        });
        y += 31;
        if ("aim_assist".equals(selectedModule)) {
            addDrawableChild(new ValueSlider(x, y, w, 20, "PRACTICE RANGE (BLOCKS)", 2, 8,
                    cfg.aimAssistRange, value -> cfg.aimAssistRange = value));
            y += 27;
            addDrawableChild(new ValueSlider(x, y, w, 20, "TRACKING STRENGTH (%)", 1, 50,
                    cfg.aimAssistStrengthPercent, value -> cfg.aimAssistStrengthPercent = value));
        } else if ("trigger_bot".equals(selectedModule)) {
            addDrawableChild(new ValueSlider(x, y, w, 20, "PRACTICE RANGE (BLOCKS)", 2, 5,
                    cfg.triggerBotRange, value -> cfg.triggerBotRange = value));
        }
        // Anti-KB keeps its fixed practice preset; no velocity sliders are exposed.
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningFor.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) cfg.setKeybind(listeningFor, 0);
            else if (keyCode != GLFW.GLFW_KEY_RIGHT_SHIFT) cfg.setKeybind(listeningFor, keyCode);
            listeningFor = "";
            cfg.save();
            clickSound();
            clearAndInit();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!settingsMode && mouseX >= contentX) {
            int before = scrollOffset;
            scrollOffset = Math.max(0, scrollOffset - (int) Math.signum(verticalAmount));
            if (before != scrollOffset) clearAndInit();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void close() {
        if (!listeningFor.isEmpty()) listeningFor = "";
        cfg.save();
        super.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, BACKDROP);
        // Subtle grid keeps the scene calm without the old animated background/logo theme.
        for (int gx = 0; gx < width; gx += 48) context.fill(gx, 0, gx + 1, height, 0x0A9EB7CA);
        for (int gy = 0; gy < height; gy += 48) context.fill(0, gy, width, gy + 1, 0x0A9EB7CA);

        context.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0x65000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, PANEL);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, ACCENT);
        context.fill(panelX, panelY + 2, panelX + 3, panelY + panelH, ACCENT);
        context.fill(panelX + panelW - 2, panelY, panelX + panelW, panelY + panelH, BORDER);
        context.fill(panelX + 1, panelY + 1, panelX + panelW - 2, panelY + panelH - 1, PANEL_INNER);
        context.fill(panelX + 3, panelY + 3, panelX + sideW, panelY + panelH - 2, SIDEBAR);
        context.fill(panelX + sideW, panelY + 3, panelX + sideW + 1, panelY + panelH - 2, BORDER);

        int brandX = panelX + 16;
        int brandY = panelY + 20;
        context.fill(brandX, brandY, brandX + 34, brandY + 34, 0xFF1D343B);
        context.fill(brandX, brandY, brandX + 3, brandY + 34, ACCENT);
        context.drawCenteredTextWithShadow(textRenderer, "DS", brandX + 19, brandY + 12, ACCENT);
        context.drawTextWithShadow(textRenderer, "DAMN SON", panelX + 58, panelY + 22, TEXT);
        context.drawTextWithShadow(textRenderer, "CLIENT UTILITIES", panelX + 58, panelY + 36, MUTED);
        context.fill(panelX + 12, panelY + panelH - 43, panelX + sideW - 12, panelY + panelH - 42, BORDER);
        context.drawTextWithShadow(textRenderer, "FABRIC 1.21", panelX + 14, panelY + panelH - 31, MUTED);
        context.drawTextWithShadow(textRenderer, "v0.6.6", panelX + sideW - 48, panelY + panelH - 31, ACCENT_ALT);

        String title = settingsMode ? "MODULE SETTINGS" : category + " MODULES";
        context.drawTextWithShadow(textRenderer, title, contentX, panelY + 20, TEXT);
        String subtitle = settingsMode ? selectedModule.toUpperCase(Locale.ROOT) : "FEATURES  /  KEYBINDS  /  CONFIGURATION";
        context.drawTextWithShadow(textRenderer, subtitle, contentX, panelY + 38, MUTED);
        int statusX = panelX + panelW - 93;
        context.fill(statusX, panelY + 24, statusX + 6, panelY + 30, GOOD);
        context.drawTextWithShadow(textRenderer, "LOCAL UI", statusX + 11, panelY + 22, GOOD);
        context.fill(contentX, panelY + 53, panelX + panelW - 15, panelY + 54, BORDER);

        if (!settingsMode) {
            List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(category);
            context.drawTextWithShadow(textRenderer, modules.size() + " MODULES  ·  SCROLL TO BROWSE",
                    contentX, panelY + 65, MUTED);
            if (!listeningFor.isEmpty()) {
                context.fill(contentX, listBottom + 5, contentX + contentW, listBottom + 24, 0xFF392D1B);
                context.drawTextWithShadow(textRenderer, "PRESS A KEY  ·  ESC = UNBOUND",
                        contentX + 7, listBottom + 10, 0xFFFFD58A);
            }
        } else {
            ModuleCatalog.Module module = ModuleCatalog.byId(selectedModule);
            if (module != null) context.drawTextWithShadow(textRenderer, module.description(), contentX, panelY + 65, MUTED);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }

    private void clickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.42F, 1.22F);
    }

    private void toggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.playSound(enabled ? SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value() : SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(),
                    0.42F, enabled ? 1.56F : 0.86F);
        }
    }

    private static String keyName(int key) {
        if (key <= 0 || key == GLFW.GLFW_KEY_UNKNOWN) return "UNBOUND";
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            default -> {
                String name = GLFW.glfwGetKeyName(key, 0);
                yield name == null ? "KEY " + key : name.toUpperCase(Locale.ROOT);
            }
        };
    }

    private static final class StyledButton extends ButtonWidget {
        private StyledButton(int x, int y, int width, int height, Text message, Runnable action) {
            super(x, y, width, height, message, button -> action.run(), DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
            int x = getX();
            int y = getY();
            int w = getWidth();
            int h = getHeight();
            String label = getMessage().getString();
            boolean selected = label.startsWith("●") || label.contains("·  ON") || label.endsWith(" ON");
            boolean hovered = isHovered();
            int fill = hovered ? ROW_HOVER : ROW;
            if (selected) fill = hovered ? 0xFF23413F : 0xFF1A302F;
            if (label.equals("CLOSE")) fill = hovered ? 0xFF4A2B34 : 0xFF2B1D25;
            context.fill(x, y, x + w, y + h, fill);
            context.fill(x, y, x + 2, y + h, selected ? ACCENT : BORDER);
            if (hovered) context.fill(x + 2, y, x + w, y + 1, ACCENT_ALT);
            int color = label.equals("CLOSE") ? 0xFFFFC8D0 : (selected ? 0xFFD8FFF6 : TEXT);
            context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, getMessage(),
                    x + w / 2, y + (h - 8) / 2, color);
        }
    }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double settingValue;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(), (Math.max(min, Math.min(max, initial)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.settingValue = clamp(initial);
            updateMessage();
        }

        private double clamp(double value) {
            if (Double.isNaN(value) || Double.isInfinite(value)) return min;
            return Math.max(min, Math.min(max, value));
        }

        @Override protected void updateMessage() {
            String shown = settingValue == Math.rint(settingValue)
                    ? Integer.toString((int) settingValue) : String.format(Locale.ROOT, "%.1f", settingValue);
            setMessage(Text.literal(label + "  ·  " + shown));
        }

        @Override protected void applyValue() {
            settingValue = clamp(min + (max - min) * this.value);
            setter.accept(settingValue);
            updateMessage();
        }
    }
}
