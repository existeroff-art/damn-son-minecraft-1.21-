package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

/** Original animated ClickGUI with category filtering, module toggles, keybind capture and settings. */
public final class DamnSonScreen extends Screen {
    private static final Identifier BACKGROUND = Identifier.of("damnson", "textures/gui/anime_bg.png");
    private static final Identifier LOGO = Identifier.of("damnson", "textures/gui/l_logo.png");
    private static final String[] CATEGORIES = {"COMBAT", "MOVEMENT", "RENDER", "PLAYER", "HUD", "MISC"};

    private final ModuleSettings cfg = ModuleSettings.get();
    private String category = "COMBAT";
    private String listeningFor = "";
    private String selectedModule = "anti_kb";
    private boolean settingsMode;
    private int scrollOffset;
    private int panelX, panelY, panelW, panelH, sideW, contentX, contentW, listY, listBottom;

    public DamnSonScreen() { super(Text.literal("Damn Son | Client")); }

    @Override
    protected void init() {
        panelW = Math.min(900, Math.max(290, width - 16));
        panelH = Math.min(500, Math.max(260, height - 16));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        sideW = Math.min(148, Math.max(84, panelW / 5));
        contentX = panelX + sideW + 13;
        contentW = panelX + panelW - 14 - contentX;
        listY = panelY + 88;
        listBottom = panelY + panelH - 48;

        int navY = panelY + 111;
        for (int i = 0; i < CATEGORIES.length; i++) {
            String nav = CATEGORIES[i];
            addDrawableChild(ButtonWidget.builder(Text.literal((category.equals(nav) && !settingsMode ? "› " : "  ") + nav), b -> {
                category = nav;
                settingsMode = false;
                scrollOffset = 0;
                clearAndInit();
            }).dimensions(panelX + 8, navY + i * 25, sideW - 16, 21).build());
        }

        if (!settingsMode) buildModuleList();
        else buildSettingsPage();

        int footerY = panelY + panelH - 31;
        addDrawableChild(ButtonWidget.builder(Text.literal(settingsMode ? "BACK" : "MODULE SETTINGS"), b -> {
            settingsMode = !settingsMode;
            clearAndInit();
        }).dimensions(contentX, footerY, Math.min(146, contentW / 2), 20).build());
        if (panelW >= 460) {
            addDrawableChild(ButtonWidget.builder(Text.literal("LOAD"), b -> { cfg.reload(); clickSound(); clearAndInit(); })
                    .dimensions(panelX + panelW - 230, footerY, 60, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("SAVE"), b -> { cfg.save(); clickSound(); })
                .dimensions(panelX + panelW - 162, footerY, 66, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close())
                .dimensions(panelX + panelW - 88, footerY, 74, 20).build());
    }

    private void buildModuleList() {
        List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(category);
        int rowStep = 27;
        int visible = Math.max(1, (listBottom - listY) / rowStep);
        scrollOffset = Math.max(0, Math.min(scrollOffset, Math.max(0, modules.size() - visible)));
        for (int visibleIndex = 0; visibleIndex < visible; visibleIndex++) {
            int i = visibleIndex + scrollOffset;
            if (i >= modules.size()) break;
            ModuleCatalog.Module module = modules.get(i);
            int y = listY + visibleIndex * rowStep;
            int keyW = Math.min(76, Math.max(52, contentW / 4));
            int toggleW = Math.max(72, contentW - keyW - 8);
            boolean enabled = cfg.enabled(module.id());
            addDrawableChild(ButtonWidget.builder(Text.literal(module.name() + "  ·  " + (enabled ? "ON" : "OFF")), b -> {
                selectedModule = module.id();
                cfg.setEnabled(module.id(), !cfg.enabled(module.id()));
                cfg.save();
                toggleSound(cfg.enabled(module.id()));
                clearAndInit();
            }).dimensions(contentX, y, toggleW, 22).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(listeningFor.equals(module.id()) ? "PRESS KEY" : keyName(cfg.keybind(module.id()))), b -> {
                listeningFor = module.id();
                clickSound();
                clearAndInit();
            }).dimensions(contentX + toggleW + 7, y, contentW - toggleW - 7, 22).build());
        }
        if (modules.size() > visible) {
            addDrawableChild(ButtonWidget.builder(Text.literal("▲"), b -> {
                scrollOffset = Math.max(0, scrollOffset - 1);
                clearAndInit();
            }).dimensions(contentX + contentW - 23, panelY + 59, 22, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("▼"), b -> {
                scrollOffset = Math.min(modules.size() - visible, scrollOffset + 1);
                clearAndInit();
            }).dimensions(contentX + contentW - 48, panelY + 59, 22, 20).build());
        }
    }

    private void buildSettingsPage() {
        ModuleCatalog.Module module = ModuleCatalog.byId(selectedModule);
        String name = module == null ? "Module" : module.name();
        int x = contentX + 5;
        int w = contentW - 10;
        int y = listY;
        addDrawableChild(ButtonWidget.builder(Text.literal("RESET KEYBIND"), b -> {
            cfg.setKeybind(selectedModule, 0);
            cfg.save();
            clearAndInit();
        }).dimensions(x, y, w, 22).build());
        y += 32;
        {
            String description = module == null ? "Select a module to view its description." : module.description();
            addDrawableChild(ButtonWidget.builder(Text.literal(description), b -> clickSound())
                    .dimensions(x, y, w, 30).build());
            y += 38;
            addDrawableChild(ButtonWidget.builder(Text.literal("Toggle module  ·  " + (cfg.enabled(selectedModule) ? "ON" : "OFF")), b -> {
                cfg.setEnabled(selectedModule, !cfg.enabled(selectedModule)); cfg.save();
                toggleSound(cfg.enabled(selectedModule));
                clearAndInit();
            }).dimensions(x, y, w, 22).build());
            y += 30;
            if ("anti_kb".equals(selectedModule)) {
                addDrawableChild(new ValueSlider(x, y, w, 20, "HORIZONTAL VELOCITY (%)", 0, 100,
                        cfg.antiKbHorizontalPercent, value -> cfg.antiKbHorizontalPercent = value));
                y += 27;
                addDrawableChild(new ValueSlider(x, y, w, 20, "VERTICAL VELOCITY (%)", 0, 100,
                        cfg.antiKbVerticalPercent, value -> cfg.antiKbVerticalPercent = value));
            } else if ("aim_assist".equals(selectedModule)) {
                addDrawableChild(new ValueSlider(x, y, w, 20, "MOB RANGE (BLOCKS)", 2, 8,
                        cfg.aimAssistRange, value -> cfg.aimAssistRange = value));
                y += 27;
                addDrawableChild(new ValueSlider(x, y, w, 20, "TRACKING STRENGTH (%)", 1, 50,
                        cfg.aimAssistStrengthPercent, value -> cfg.aimAssistStrengthPercent = value));
            } else if ("trigger_bot".equals(selectedModule)) {
                addDrawableChild(new ValueSlider(x, y, w, 20, "MOB RANGE (BLOCKS)", 2, 5,
                        cfg.triggerBotRange, value -> cfg.triggerBotRange = value));
            }
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningFor.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) cfg.setKeybind(listeningFor, 0);
            else if (keyCode != GLFW.GLFW_KEY_RIGHT_SHIFT) cfg.setKeybind(listeningFor, keyCode);
            listeningFor = "";
            cfg.save();
            clickSound();
            clearAndInit();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!settingsMode && mouseX >= contentX) {
            int before = scrollOffset;
            scrollOffset = Math.max(0, scrollOffset - (int) Math.signum(verticalAmount));
            if (before != scrollOffset) clearAndInit();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void close() {
        if (!listeningFor.isEmpty()) listeningFor = "";
        cfg.save();
        super.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / 310.0));
        int panX = 5 + (int) (Math.sin(now / 1350.0) * 4.0);
        int panY = 3 + (int) (Math.cos(now / 1810.0) * 3.0);
        context.fill(0, 0, width, height, 0xFF05030D);
        context.drawTexture(BACKGROUND, -panX, -panY, width + 10, height + 6,
                0, 0, 1024, 576, 1024, 576);
        context.fill(0, 0, width, height, 0x99000614);
        int sweepY = (int) ((now / 12L) % Math.max(1, height));
        context.fill(0, sweepY, width, Math.min(height, sweepY + 2), 0x405F28FF);
        for (int i = 0; i < 13; i++) {
            int px = Math.floorMod(i * 113 + (int) (now / (23L + i % 3)), Math.max(1, width));
            int py = Math.floorMod(i * 47 + (int) (now / (31L + i % 4)), Math.max(1, height));
            context.fill(px, py, px + 2, py + 2, i % 2 == 0 ? 0xA86F32FF : 0xA8C07AFF);
        }

        context.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0x88000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xED090E1A);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFF39C7FF);
        context.fill(panelX, panelY + panelH - 2, panelX + panelW, panelY + panelH, 0xFF9C69FF);
        context.fill(panelX, panelY, panelX + 2, panelY + panelH, 0xFF39C7FF);
        context.fill(panelX + panelW - 2, panelY, panelX + panelW, panelY + panelH, 0xFF9C69FF);
        context.fill(panelX + 1, panelY + 1, panelX + sideW, panelY + panelH - 1, 0xF20B1222);
        context.fill(panelX + sideW, panelY + 1, panelX + sideW + 1, panelY + panelH - 1, 0x8039C7FF);

        int logoSize = Math.min(42, sideW - 24);
        int logoX = panelX + (sideW - logoSize) / 2;
        int logoY = panelY + 17;
        context.fill(logoX - 3, logoY - 3, logoX + logoSize + 3, logoY + logoSize + 3, 0x5539C7FF);
        context.drawTexture(LOGO, logoX, logoY, logoSize, logoSize, 0, 0, 128, 128, 128, 128);
        context.drawCenteredTextWithShadow(textRenderer, "DAMN SON", panelX + sideW / 2, panelY + 67, 0xFFF4F7FF);
        context.drawCenteredTextWithShadow(textRenderer, "CLIENT", panelX + sideW / 2, panelY + 80, 0xFF9BC5E8);
        context.fill(panelX + 12, panelY + panelH - 43, panelX + sideW - 12, panelY + panelH - 42, 0x5539C7FF);
        context.drawCenteredTextWithShadow(textRenderer, "v0.6.3", panelX + sideW / 2, panelY + panelH - 31, 0xFF6F8AA8);

        context.drawTextWithShadow(textRenderer, settingsMode ? "MODULE SETTINGS" : category + " MODULES",
                contentX, panelY + 20, 0xFFF3F7FF);
        context.drawTextWithShadow(textRenderer, settingsMode ? selectedModule.toUpperCase(Locale.ROOT) : "CLICK TO TOGGLE  ·  KEY TO BIND",
                contentX, panelY + 39, 0xFF8EA6C6);
        int statusX = panelX + panelW - 67;
        context.fill(statusX, panelY + 21, statusX + 7, panelY + 28, 0xFF5EF0B2 | ((int) (pulse * 0x22) << 24));
        context.drawTextWithShadow(textRenderer, "READY", statusX + 11, panelY + 20, 0xFF9AF7CF);
        context.fill(contentX, panelY + 54, panelX + panelW - 14, panelY + 55, 0x388AA9CB);
        if (!settingsMode) {
            List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(category);
            int visible = Math.max(1, (listBottom - listY) / 27);
            context.drawTextWithShadow(textRenderer, modules.size() + " MODULES  ·  SCROLL TO BROWSE",
                    contentX, panelY + 65, 0xFF6D89A9);
            if (!listeningFor.isEmpty()) {
                context.fill(contentX, listBottom + 5, contentX + contentW, listBottom + 24, 0xF0251D31);
                context.drawTextWithShadow(textRenderer, "PRESS A KEY  ·  ESC = UNBOUND", contentX + 6, listBottom + 10, 0xFFFFD27A);
            }
        } else {
            ModuleCatalog.Module module = ModuleCatalog.byId(selectedModule);
            if (module != null) context.drawTextWithShadow(textRenderer, module.description(), contentX, panelY + 65, 0xFF6D89A9);
        }
        int beamX = panelX + (int) ((now / 7L) % Math.max(1, panelW));
        context.fill(Math.max(panelX, beamX - 20), panelY + 2, Math.min(panelX + panelW, beamX + 20), panelY + 4,
                0x306F29FF | ((int) (pulse * 0x28) << 24));
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }

    private void clickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.35F, 1.28F);
    }

    private void toggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),
                0.42F, enabled ? 1.66F : 0.76F);
    }

    private static String keyName(int key) {
        if (key <= 0 || key == GLFW.GLFW_KEY_UNKNOWN) return "UNBOUND";
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            default -> {
                String name = GLFW.glfwGetKeyName(key, 0);
                yield name == null ? "KEY " + key : name.toUpperCase(Locale.ROOT);
            }
        };
    }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double settingValue;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(), (Math.max(min, Math.min(max, initial)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.settingValue = clamp(initial);
            updateMessage();
        }

        private double clamp(double value) {
            if (Double.isNaN(value) || Double.isInfinite(value)) return min;
            return Math.max(min, Math.min(max, value));
        }

        @Override protected void updateMessage() {
            String shown = settingValue == Math.rint(settingValue)
                    ? Integer.toString((int) settingValue) : String.format(Locale.ROOT, "%.1f", settingValue);
            setMessage(Text.literal(label + "  ·  " + shown));
        }

        @Override protected void applyValue() {
            settingValue = clamp(min + (max - min) * this.value);
            setter.accept(settingValue);
            updateMessage();
        }
    }
}
