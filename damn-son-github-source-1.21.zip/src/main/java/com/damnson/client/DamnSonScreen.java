package com.damnson.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/** Configurable AA/TB settings UI. FreeBuff must implement and validate the actual gameplay modules. */
public final class DamnSonScreen extends Screen {
    private final ModuleSettings cfg = ModuleSettings.get();

    public DamnSonScreen() { super(Text.literal("Damn Son")); }

    @Override
    protected void init() {
        int left = this.width / 2 - 155;
        int top = Math.max(36, this.height / 2 - 130);
        addDrawableChild(ButtonWidget.builder(toggleText("AA", cfg.aimAssistEnabled), b -> {
            cfg.aimAssistEnabled = !cfg.aimAssistEnabled; b.setMessage(toggleText("AA", cfg.aimAssistEnabled)); cfg.save();
        }).dimensions(left, top, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("TB", cfg.triggerBotEnabled), b -> {
            cfg.triggerBotEnabled = !cfg.triggerBotEnabled; b.setMessage(toggleText("TB", cfg.triggerBotEnabled)); cfg.save();
        }).dimensions(left + 165, top, 145, 20).build());

        addDrawableChild(new ValueSlider(left, top + 28, 145, 20, "AA Range", 1, 12, cfg.aimRange, v -> cfg.aimRange = v));
        addDrawableChild(new ValueSlider(left, top + 52, 145, 20, "AA Speed", 1, 20, cfg.aimSpeed, v -> cfg.aimSpeed = v));
        addDrawableChild(new ValueSlider(left, top + 76, 145, 20, "AA Max Speed", 1, 30, cfg.aimMaxSpeed, v -> cfg.aimMaxSpeed = v));
        addDrawableChild(new ValueSlider(left, top + 100, 145, 20, "AA FOV", 1, 180, cfg.aimFov, v -> cfg.aimFov = v));
        addDrawableChild(new ValueSlider(left + 165, top + 28, 145, 20, "TB Range", 1, 6, cfg.triggerRange, v -> cfg.triggerRange = v));
        addDrawableChild(new ValueSlider(left + 165, top + 52, 145, 20, "TB Delay ms", 0, 1000, cfg.triggerDelayMs, v -> cfg.triggerDelayMs = (int) v));
        addDrawableChild(ButtonWidget.builder(toggleText("Humanize", cfg.humanize), b -> {
            cfg.humanize = !cfg.humanize; b.setMessage(toggleText("Humanize", cfg.humanize)); cfg.save();
        }).dimensions(left, top + 128, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Focus Mode", cfg.focusMode), b -> {
            cfg.focusMode = !cfg.focusMode; b.setMessage(toggleText("Focus Mode", cfg.focusMode)); cfg.save();
        }).dimensions(left, top + 152, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Smart Bypass", cfg.smartBypass), b -> {
            cfg.smartBypass = !cfg.smartBypass; b.setMessage(toggleText("Smart Bypass", cfg.smartBypass)); cfg.save();
        }).dimensions(left, top + 176, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Aim Point: " + cfg.aimPoint), b -> {
            cfg.aimPoint = switch (cfg.aimPoint) { case "HEAD" -> "CHEST"; case "CHEST" -> "LEGS"; default -> "HEAD"; };
            b.setMessage(Text.literal("Aim Point: " + cfg.aimPoint)); cfg.save();
        }).dimensions(left, top + 200, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Target: " + cfg.targetMode), b -> {
            cfg.targetMode = cfg.targetMode.equals("PLAYERS") ? "HOSTILE" : cfg.targetMode.equals("HOSTILE") ? "ALL" : "PLAYERS";
            b.setMessage(Text.literal("Target: " + cfg.targetMode)); cfg.save();
        }).dimensions(left + 165, top + 148, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("AA Only Weapon", cfg.onlyWeapon), b -> {
            cfg.onlyWeapon = !cfg.onlyWeapon; b.setMessage(toggleText("AA Only Weapon", cfg.onlyWeapon)); cfg.save();
        }).dimensions(left + 165, top + 76, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("TB Only Weapon", cfg.triggerOnlyWeapon), b -> {
            cfg.triggerOnlyWeapon = !cfg.triggerOnlyWeapon; b.setMessage(toggleText("TB Only Weapon", cfg.triggerOnlyWeapon)); cfg.save();
        }).dimensions(left + 165, top + 100, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Players Only", cfg.triggerPlayersOnly), b -> {
            cfg.triggerPlayersOnly = !cfg.triggerPlayersOnly; b.setMessage(toggleText("Players Only", cfg.triggerPlayersOnly)); cfg.save();
        }).dimensions(left + 165, top + 124, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Save settings"), b -> cfg.save())
                .dimensions(left + 165, top + 176, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(this.width / 2 - 50, top + 228, 100, 20).build());
    }

    private static Text toggleText(String label, boolean enabled) {
        return Text.literal(label + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = this.width / 2 - 155;
        int top = Math.max(36, this.height / 2 - 130);
        // Dark translucent panels inspired by the reference video; controls remain native widgets.
        context.fill(left - 6, top - 5, left + 151, top + 224, 0xD91A1A1A);
        context.fill(left + 159, top - 5, left + 316, top + 224, 0xD91A1A1A);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, top - 29, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Single-player settings", width / 2, top - 16, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }

    private static final class ValueSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final java.util.function.DoubleConsumer setter;
        private double value;

        ValueSlider(int x, int y, int width, int height, String label, double min, double max,
                    double initial, java.util.function.DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(), (initial - min) / (max - min));
            this.label = label; this.min = min; this.max = max; this.setter = setter;
            this.value = clamp(initial); updateMessage();
        }
        private double clamp(double v) { return Math.max(min, Math.min(max, v)); }
        @Override protected void updateMessage() {
            setMessage(Text.literal(label + ": " + (value == Math.rint(value) ? Integer.toString((int) value) : String.format(java.util.Locale.ROOT, "%.1f", value))));
        }
        @Override protected void applyValue() {
            value = clamp(min + (max - min) * value);
            setter.accept(value); updateMessage(); ModuleSettings.get().save();
        }
    }
}
