package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

/** Compact, centered Rockstar-style module menu with per-category scrolling. */
public final class DamnSonScreen extends Screen {
    private static final int C_BACKDROP   = 0x25000000;
    private static final int C_COL_BG     = 0xE3080D18;
    private static final int C_COL_HDR    = 0xFF0B101A;
    private static final int C_HDR_ACCENT = 0xFFFF6B9D;
    private static final int C_HDR_LINE   = 0xFF19202C;
    private static final int C_ROW_HOVER  = 0xFF171C27;
    private static final int C_ROW_ON     = 0xFF21151F;
    private static final int C_BORDER     = 0xFF242633;
    private static final int C_TEXT       = 0xFFE5E7EE;
    private static final int C_MUTED      = 0xFF858998;
    private static final int C_CHECK      = 0xFFFF6B9D;
    private static final int C_ARROW      = 0xFFFFA2BF;
    private static final int C_ON_LABEL   = 0xFFFFD0DE;

    private static final String[] CAT_ICONS = { "✦", "↑", "◈", "♦", "…" };
    private static final String[] CAT_LABELS = ModuleCatalog.CATEGORIES;

    private final ModuleSettings cfg = ModuleSettings.get();
    private final int[] scrollOffsets = new int[CAT_LABELS.length];
    private String settingsModuleId;
    private String listeningForKeybind = "";

    private int colW, colGap, hdrH, rowH, colPadX, settingsW;
    private int totalW, startX, startY, colH, visibleRows;
    private int scrollDragCategory = -1;
    private int scrollDragGrabOffset;
    private String draggingSlider;

    public DamnSonScreen() { super(Text.literal("Damn Son")); }

    @Override
    protected void init() {
        colGap = 4;
        colW = Math.min(156, Math.max(104, (width - 24 - (CAT_LABELS.length - 1) * colGap) / CAT_LABELS.length));
        settingsW = colW;
        hdrH = 34;
        rowH = 18;
        colPadX = 7;
        colH = Math.min(258, Math.max(192, (int) (height * 0.52f)));
        colH = Math.min(colH, Math.max(120, height - 42));
        totalW = CAT_LABELS.length * colW + (CAT_LABELS.length - 1) * colGap;
        startX = Math.max(4, (width - totalW) / 2);
        startY = Math.max(6, (height - colH) / 2);
        visibleRows = Math.max(1, (colH - hdrH - 6) / rowH);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Keep the game visible behind the floating panels, like the supplied reference.
        ctx.fill(0, 0, width, height, C_BACKDROP);
        ctx.drawCenteredTextWithShadow(textRenderer, "DAMN SON  ·  RIGHT SHIFT / ESC TO CLOSE",
                width / 2, Math.max(2, startY - 14), C_HDR_ACCENT);

        int columnsToDraw = settingsModuleId == null ? CAT_LABELS.length : CAT_LABELS.length - 1;
        for (int ci = 0; ci < columnsToDraw; ci++) {
            int cx = startX + ci * (colW + colGap);
            renderColumn(ctx, mx, my, ci, cx);
        }

        if (settingsModuleId != null) {
            int sx = startX + (CAT_LABELS.length - 1) * (colW + colGap);
            renderSettingsPanel(ctx, sx);
        }

        String hint = "LMB: toggle    RMB: settings    wheel / bar: scroll";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2,
                Math.min(height - 10, startY + colH + 7), C_MUTED);

        if (!listeningForKeybind.isEmpty()) {
            String banner = "PRESS A KEY  ·  ESC = UNBIND";
            int bw = Math.min(width - 16, textRenderer.getWidth(banner) + 18);
            int bx = (width - bw) / 2;
            int by = Math.max(2, startY - 29);
            ctx.fill(bx, by, bx + bw, by + 18, 0xEE24151C);
            ctx.fill(bx, by, bx + bw, by + 1, C_HDR_ACCENT);
            ctx.drawCenteredTextWithShadow(textRenderer, banner, bx + bw / 2, by + 5, 0xFFFFD0DE);
        }
    }

    private void renderColumn(DrawContext ctx, int mx, int my, int ci, int cx) {
        int cy = startY;
        String category = CAT_LABELS[ci];
        List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(category);
        boolean hoveredColumn = inRect(mx, my, cx, cy, colW, colH);

        ctx.fill(cx + 2, cy + 3, cx + colW + 2, cy + colH + 3, 0x50000000);
        ctx.fill(cx, cy, cx + colW, cy + colH, C_COL_BG);
        ctx.fill(cx, cy, cx + 2, cy + colH, hoveredColumn ? C_HDR_ACCENT : C_BORDER);
        ctx.fill(cx + 2, cy, cx + colW, cy + 1, C_HDR_LINE);
        ctx.fill(cx + colW - 1, cy, cx + colW, cy + colH, C_BORDER);
        ctx.fill(cx + 2, cy + 1, cx + colW - 1, cy + hdrH, C_COL_HDR);
        ctx.fill(cx + 2, cy + hdrH - 1, cx + colW - 1, cy + hdrH, C_HDR_LINE);

        ctx.drawTextWithShadow(textRenderer, CAT_ICONS[ci], cx + colPadX, cy + 9, C_HDR_ACCENT);
        ctx.drawTextWithShadow(textRenderer, category, cx + colPadX + 12, cy + 9, C_TEXT);
        String count = modules.size() + " modules";
        ctx.drawTextWithShadow(textRenderer, count, cx + colPadX, cy + 22, C_MUTED);

        int maxScroll = Math.max(0, modules.size() - visibleRows);
        scrollOffsets[ci] = Math.max(0, Math.min(scrollOffsets[ci], maxScroll));
        int viewportTop = cy + hdrH + 3;
        int viewportBottom = cy + colH - 3;
        ctx.enableScissor(cx + 2, viewportTop, cx + colW - 2, viewportBottom);
        for (int vi = 0; vi < visibleRows; vi++) {
            int idx = vi + scrollOffsets[ci];
            if (idx >= modules.size()) break;
            renderModuleRow(ctx, mx, my, modules.get(idx), cx, cy + hdrH + 3 + vi * rowH);
        }
        ctx.disableScissor();

        if (maxScroll > 0) {
            int trackX = cx + colW - 3;
            int trackY = viewportTop;
            int trackH = Math.max(1, viewportBottom - viewportTop);
            int thumbH = Math.max(12, trackH * visibleRows / modules.size());
            int thumbY = trackY + (int) ((trackH - thumbH) * (scrollOffsets[ci] / (float) maxScroll));
            ctx.fill(trackX, trackY, trackX + 2, viewportBottom, 0xFF10141E);
            ctx.fill(trackX, thumbY, trackX + 2, thumbY + thumbH, C_HDR_ACCENT);
        }
    }

    private void renderModuleRow(DrawContext ctx, int mx, int my, ModuleCatalog.Module module, int cx, int ry) {
        boolean enabled = cfg.enabled(module.id());
        boolean hovered = inRect(mx, my, cx, ry, colW - 1, rowH);
        boolean selected = module.id().equals(settingsModuleId);
        int bg = !module.implemented() ? 0xFF101218 : selected ? 0xFF2B1B26 : enabled ? (hovered ? 0xFF33202B : C_ROW_ON)
                : hovered ? C_ROW_HOVER : C_COL_BG;
        ctx.fill(cx + 2, ry, cx + colW - 1, ry + rowH - 1, bg);
        if (enabled) ctx.fill(cx + 2, ry, cx + 4, ry + rowH - 1, C_HDR_ACCENT);

        int nameX = cx + colPadX + (enabled ? 2 : 0);
        int reserveRight = !module.implemented() ? 37 : enabled ? 17 : (hovered ? 15 : 5);
        ctx.enableScissor(nameX, ry, cx + colW - reserveRight, ry + rowH - 1);
        ctx.drawTextWithShadow(textRenderer, module.name(), nameX, ry + 5,
                !module.implemented() ? C_MUTED : enabled ? C_ON_LABEL : (hovered ? C_TEXT : 0xFFBBC0CC));
        ctx.disableScissor();

        if (!module.implemented()) ctx.drawTextWithShadow(textRenderer, "SOON", cx + colW - 33, ry + 5, C_MUTED);
        else if (enabled) ctx.drawTextWithShadow(textRenderer, "✔", cx + colW - 14, ry + 5, C_CHECK);
        else if (hovered) ctx.drawTextWithShadow(textRenderer, "›", cx + colW - 12, ry + 5, C_ARROW);
    }

    private void renderSettingsPanel(DrawContext ctx, int sx) {
        ModuleCatalog.Module module = ModuleCatalog.byId(settingsModuleId);
        if (module == null) return;
        int cy = startY;
        ctx.fill(sx + 2, cy + 3, sx + settingsW + 2, cy + colH + 3, 0x50000000);
        ctx.fill(sx, cy, sx + settingsW, cy + colH, 0xED0A0D16);
        ctx.fill(sx, cy, sx + 2, cy + colH, C_HDR_ACCENT);
        ctx.fill(sx + 2, cy, sx + settingsW, cy + 1, C_HDR_LINE);
        ctx.fill(sx + settingsW - 1, cy, sx + settingsW, cy + colH, C_BORDER);
        ctx.fill(sx + 2, cy + 1, sx + settingsW - 1, cy + hdrH, C_COL_HDR);
        ctx.fill(sx + 2, cy + hdrH - 1, sx + settingsW - 1, cy + hdrH, C_HDR_LINE);
        ctx.drawTextWithShadow(textRenderer, "SETTINGS", sx + colPadX, cy + 8, C_HDR_ACCENT);
        drawTruncated(ctx, module.name(), sx + colPadX, cy + 21, settingsW - 2 * colPadX, C_TEXT);

        int px = sx + colPadX;
        int pw = settingsW - colPadX * 2;
        int descY = cy + hdrH + 5;
        ctx.fill(px, descY, px + pw, descY + 17, 0xFF0D121B);
        drawTruncated(ctx, module.description(), px + 3, descY + 4, pw - 6, C_MUTED);

        int toggleY = descY + 20;
        boolean on = cfg.enabled(module.id());
        ctx.fill(px, toggleY, px + pw, toggleY + 18, on ? 0xFF2B1822 : 0xFF101722);
        ctx.fill(px, toggleY, px + 2, toggleY + 18, on ? C_CHECK : C_BORDER);
        ctx.drawTextWithShadow(textRenderer, "TOGGLE  " + (on ? "ON" : "OFF"), px + 5, toggleY + 5,
                on ? C_ON_LABEL : C_TEXT);

        int keyY = toggleY + 22;
        String keyLabel = listeningForKeybind.equals(module.id()) ? "PRESS KEY..." : "KEY  " + keyName(cfg.keybind(module.id()));
        ctx.fill(px, keyY, px + pw, keyY + 18, 0xFF0D121B);
        ctx.fill(px, keyY, px + 2, keyY + 18, C_ARROW);
        drawTruncated(ctx, keyLabel, px + 5, keyY + 5, pw - 9, C_MUTED);

        int sliderY = keyY + 22;
        // Keep long settings content inside the panel viewport so it cannot paint
        // over the fixed footer on short windows / mobile-sized game surfaces.
        int closeY = cy + colH - 20;
        int sliderViewportTop = sliderY;
        int sliderViewportBottom = Math.max(sliderViewportTop, closeY - 3);
        ctx.enableScissor(px, sliderViewportTop, px + pw, sliderViewportBottom);
        renderModuleSliders(ctx, module.id(), px, sliderY, pw);
        ctx.disableScissor();


        ctx.fill(px, closeY, px + pw, closeY + 16, 0xFF10131C);
        ctx.fill(px, closeY, px + pw, closeY + 1, C_BORDER);
        ctx.drawCenteredTextWithShadow(textRenderer, "CLOSE PANEL", px + pw / 2, closeY + 4, C_MUTED);
    }

    private void renderModuleSliders(DrawContext ctx, String id, int px, int py, int pw) {
        switch (id) {
            case "aim_bot" -> {
                drawSliderRow(ctx, px, py, pw, "RANGE", cfg.aimBotRange, 2, 32, "aim_bot_range"); py += 21;
                drawSliderRow(ctx, px, py, pw, "FOV (360=FULL)", cfg.aimBotFov, 10, 360, "aim_bot_fov"); py += 21;
                drawSliderRow(ctx, px, py, pw, "STRENGTH", cfg.aimBotSmooth, 1, 100, "aim_bot_smooth"); py += 21;
                drawAimPointSelector(ctx, px, py, pw); py += 21;
                drawWeaponOnlyToggle(ctx, px, py, pw);
            }
            case "trigger_bot" -> {
                drawSliderRow(ctx, px, py, pw, "RANGE", cfg.triggerBotRange, 2, 6, "trigger_bot_range"); py += 21;
                drawSliderRow(ctx, px, py, pw, "DELAY (TICKS)", cfg.triggerBotDelayTicks, 0, 10, "trigger_bot_delay");
            }
            case "auto_potion" -> {
                drawSliderRow(ctx, px, py, pw, "HEALTH THRESHOLD", cfg.autoPotionThreshold, 2, 20, "auto_potion_threshold"); py += 21;
                drawSliderRow(ctx, px, py, pw, "COOLDOWN (TICKS)", cfg.autoPotionCooldownTicks, 5, 40, "auto_potion_cooldown");
            }
            case "aura" -> drawSliderRow(ctx, px, py, pw, "RANGE", cfg.auraRange, 2, 6, "aura_range");
            case "reach" -> drawSliderRow(ctx, px, py, pw, "EXTRA REACH", cfg.reachExtra, 0, 3, "reach_reach");
            case "speed" -> drawSliderRow(ctx, px, py, pw, "MULTIPLIER", cfg.speedMultiplier, 0.1, 4, "speed_speed");
            case "velocity" -> {
                drawSliderRow(ctx, px, py, pw, "HORIZONTAL %", cfg.velocityHorizontalPercent, 0, 100, "velocity_h"); py += 21;
                drawSliderRow(ctx, px, py, pw, "VERTICAL %", cfg.velocityVerticalPercent, 0, 100, "velocity_v");
            }
            case "anti_kb" -> {
                drawSliderRow(ctx, px, py, pw, "HORIZONTAL %", cfg.antiKbHorizontalPercent, 0, 100, "anti_kb_h"); py += 21;
                drawSliderRow(ctx, px, py, pw, "VERTICAL %", cfg.antiKbVerticalPercent, 0, 100, "anti_kb_v");
            }
            default -> { }
        }
    }

    private void drawWeaponOnlyToggle(DrawContext ctx, int px, int py, int pw) {
        boolean on = cfg.aimBotWeaponsOnly;
        ctx.fill(px, py, px + pw, py + 18, on ? 0xFF21151F : 0xFF101722);
        ctx.fill(px, py, px + 2, py + 18, on ? C_CHECK : C_BORDER);
        String label = "WEAPONS ONLY  " + (on ? "ON" : "OFF");
        ctx.drawTextWithShadow(textRenderer, label, px + 5, py + 5, on ? C_ON_LABEL : C_MUTED);
    }

    private void drawAimPointSelector(DrawContext ctx, int px, int py, int pw) {
        ctx.fill(px, py, px + pw, py + 18, 0xFF0D121B);
        ctx.drawTextWithShadow(textRenderer, "AIM POINT", px + 3, py + 2, C_MUTED);
        String[] labels = {"HEAD", "CHEST", "BODY"};
        int right = px + pw - 2;
        int segmentW = Math.max(1, (pw - 8) / 3);
        int start = right - segmentW * 3;
        for (int i = 0; i < 3; i++) {
            int x1 = start + i * segmentW;
            int x2 = i == 2 ? right : x1 + segmentW - 1;
            boolean selected = cfg.aimBotTargetPoint == i;
            ctx.fill(x1, py + 2, x2, py + 16, selected ? 0xFF8E3154 : 0xFF202432);
            ctx.drawCenteredTextWithShadow(textRenderer, labels[i], (x1 + x2) / 2, py + 5,
                    selected ? C_TEXT : C_MUTED);
        }
    }

    private void drawSliderRow(DrawContext ctx, int px, int py, int pw, String label,
                               double value, double min, double max, String sliderId) {
        ctx.fill(px, py, px + pw, py + 18, 0xFF0D121B);
        int trackY = py + 13;
        ctx.fill(px + 2, trackY, px + pw - 2, trackY + 2, 0xFF2A2D39);
        double fraction = Math.max(0, Math.min(1, (value - min) / (max - min)));
        int thumbX = px + 2 + (int) ((pw - 4) * fraction);
        ctx.fill(thumbX - 2, trackY - 2, thumbX + 3, trackY + 4, C_HDR_ACCENT);
        ctx.drawTextWithShadow(textRenderer, label, px + 2, py + 2, C_MUTED);
        String shown;
        shown = value == (int) value ? String.valueOf((int) value) : String.format(Locale.ROOT, "%.1f", value);
        ctx.drawTextWithShadow(textRenderer, shown, px + pw - textRenderer.getWidth(shown) - 2, py + 2, C_TEXT);
    }

    private String sliderAtY(String id, int sliderY, int mouseY) {
        String[] sliders = slidersForModule(id);
        for (int i = 0; i < sliders.length; i++) {
            int y = sliderY + i * 21;
            if (inRect(0, mouseY, 0, y, 1, 18)) return sliders[i];
        }
        return null;
    }

    private void applySlider(String sliderId, int mouseX, int px, int pw) {
        double fraction = Math.max(0, Math.min(1, (double) (mouseX - (px + 2)) / Math.max(1, pw - 4)));
        switch (sliderId) {
            case "aim_bot_range" -> cfg.aimBotRange = 2 + fraction * 30;
            case "aim_bot_fov" -> cfg.aimBotFov = 10 + fraction * 350;
            case "aim_bot_smooth" -> cfg.aimBotSmooth = 1 + fraction * 99;
            case "aim_bot_target_point" -> cfg.aimBotTargetPoint = (int) Math.round(fraction * 2.0);
            case "auto_potion_threshold" -> cfg.autoPotionThreshold = Math.round(2 + fraction * 18);
            case "auto_potion_cooldown" -> cfg.autoPotionCooldownTicks = Math.round(5 + fraction * 35);
            case "trigger_bot_range" -> cfg.triggerBotRange = 2 + fraction * 4;
            case "trigger_bot_delay" -> cfg.triggerBotDelayTicks = Math.round(fraction * 10);
            case "aura_range" -> cfg.auraRange = 2 + fraction * 4;
            case "reach_reach" -> cfg.reachExtra = fraction * 3;
            case "speed_speed" -> cfg.speedMultiplier = 0.1 + fraction * 3.9;
            case "velocity_h" -> cfg.velocityHorizontalPercent = fraction * 100;
            case "velocity_v" -> cfg.velocityVerticalPercent = fraction * 100;
            case "anti_kb_h" -> cfg.antiKbHorizontalPercent = fraction * 100;
            case "anti_kb_v" -> cfg.antiKbVerticalPercent = fraction * 100;
            default -> { return; }
        }
        cfg.save();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int mx = (int) mouseX, my = (int) mouseY;

        if (settingsModuleId != null) {
            int sx = startX + (CAT_LABELS.length - 1) * (colW + colGap);
            int px = sx + colPadX;
            int pw = settingsW - colPadX * 2;
            int descY = startY + hdrH + 5;
            int toggleY = descY + 20;
            int keyY = toggleY + 22;
            int sliderY = keyY + 22;
            int closeY = startY + colH - 20;

            // The footer is fixed and must win hit-testing over settings rows
            // that extend below the visible viewport.
            if (button == 0 && inRect(mx, my, px, closeY, pw, 16)) {
                settingsModuleId = null;
                draggingSlider = null;
                clickSound();
                return true;
            }

            if (button == 0 && inRect(mx, my, px, toggleY, pw, 18)) {
                cfg.setEnabled(settingsModuleId, !cfg.enabled(settingsModuleId));
                cfg.save();
                toggleSound(cfg.enabled(settingsModuleId));
                if ("fast_gapple".equals(settingsModuleId)) DamnSonClient.syncFastGappleToggle();
                return true;
            }
            if (button == 0 && inRect(mx, my, px, keyY, pw, 18)) {
                listeningForKeybind = settingsModuleId;
                clickSound();
                return true;
            }
            if (button == 0 && "aim_bot".equals(settingsModuleId)
                    && inRect(mx, my, px, sliderY + 3 * 21, pw, 18)) {
                int segmentW = Math.max(1, (pw - 8) / 3);
                int start = px + pw - 2 - segmentW * 3;
                int selected = Math.max(0, Math.min(2, (mx - start) / segmentW));
                cfg.aimBotTargetPoint = selected;
                cfg.save();
                clickSound();
                return true;
            }
            if (button == 0 && "aim_bot".equals(settingsModuleId)
                    && inRect(mx, my, px, sliderY + 4 * 21, pw, 18)) {
                cfg.aimBotWeaponsOnly = !cfg.aimBotWeaponsOnly;
                cfg.save();
                toggleSound(cfg.aimBotWeaponsOnly);
                return true;
            }
            if (button == 0) {
                String sliderId = sliderAtY(settingsModuleId, sliderY, my);
                if (sliderId != null && inRect(mx, my, px, sliderY, pw, 18 + 21 * (slidersForModule(settingsModuleId).length - 1))) {
                    draggingSlider = sliderId;
                    applySlider(sliderId, mx, px, pw);
                    return true;
                }
            }
            if (!inRect(mx, my, sx, startY, settingsW, colH)) {
                settingsModuleId = null;
                draggingSlider = null;
            } else {
                return true;
            }
        }

        int columnsToCheck = settingsModuleId == null ? CAT_LABELS.length : CAT_LABELS.length - 1;
        for (int ci = 0; ci < columnsToCheck; ci++) {
            int cx = startX + ci * (colW + colGap);
            if (!inRect(mx, my, cx, startY, colW, colH)) continue;
            List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(CAT_LABELS[ci]);
            int maxScroll = Math.max(0, modules.size() - visibleRows);
            int trackX = cx + colW - 5;
            int trackY = startY + hdrH + 3;
            int trackH = Math.max(1, colH - hdrH - 6);
            int thumbH = modules.isEmpty() ? trackH : Math.max(12, trackH * visibleRows / modules.size());
            int thumbY = trackY + (maxScroll == 0 ? 0 : (int) ((trackH - thumbH) * (scrollOffsets[ci] / (float) maxScroll)));
            if (button == 0 && maxScroll > 0 && inRect(mx, my, trackX - 2, trackY, 6, trackH)) {
                scrollDragCategory = ci;
                if (inRect(mx, my, trackX - 2, thumbY, 6, thumbH)) {
                    scrollDragGrabOffset = my - thumbY;
                } else {
                    scrollDragGrabOffset = thumbH / 2;
                    updateScrollFromMouse(ci, my, trackY, trackH, thumbH, scrollDragGrabOffset, maxScroll);
                }
                return true;
            }

            int viewTop = startY + hdrH + 3;
            for (int vi = 0; vi < visibleRows; vi++) {
                int idx = vi + scrollOffsets[ci];
                if (idx >= modules.size()) break;
                int ry = viewTop + vi * rowH;
                if (!inRect(mx, my, cx + 2, ry, colW - 3, rowH - 1)) continue;
                ModuleCatalog.Module module = modules.get(idx);
                if (!module.implemented()) return true;
                if (button == 0) {
                    if (!listeningForKeybind.isEmpty()) {
                        listeningForKeybind = "";
                        clickSound();
                        return true;
                    }
                    cfg.setEnabled(module.id(), !cfg.enabled(module.id()));
                    cfg.save();
                    if ("fast_gapple".equals(module.id())) DamnSonClient.syncFastGappleToggle();
                    toggleSound(cfg.enabled(module.id()));
                    return true;
                }
                if (button == 1) {
                    settingsModuleId = module.id();
                    listeningForKeybind = "";
                    clickSound();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && scrollDragCategory >= 0) {
            int ci = scrollDragCategory;
            List<ModuleCatalog.Module> modules = ModuleCatalog.inCategory(CAT_LABELS[ci]);
            int maxScroll = Math.max(0, modules.size() - visibleRows);
            int trackY = startY + hdrH + 3;
            int trackH = Math.max(1, colH - hdrH - 6);
            int thumbH = Math.max(12, trackH * visibleRows / Math.max(1, modules.size()));
            updateScrollFromMouse(ci, (int) mouseY, trackY, trackH, thumbH, scrollDragGrabOffset, maxScroll);
            return true;
        }
        if (button == 0 && draggingSlider != null && settingsModuleId != null) {
            int sx = startX + (CAT_LABELS.length - 1) * (colW + colGap);
            int px = sx + colPadX;
            int pw = settingsW - colPadX * 2;
            applySlider(draggingSlider, (int) mouseX, px, pw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            scrollDragCategory = -1;
            draggingSlider = null;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void updateScrollFromMouse(int ci, int mouseY, int trackY, int trackH,
                                       int thumbH, int grabOffset, int maxScroll) {
        if (maxScroll <= 0) { scrollOffsets[ci] = 0; return; }
        int available = Math.max(1, trackH - thumbH);
        int top = Math.max(trackY, Math.min(trackY + available, mouseY - grabOffset));
        scrollOffsets[ci] = Math.max(0, Math.min(maxScroll,
                Math.round((top - trackY) / (float) available * maxScroll)));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!listeningForKeybind.isEmpty()) return true;
        int columnsToCheck = settingsModuleId == null ? CAT_LABELS.length : CAT_LABELS.length - 1;
        for (int ci = 0; ci < columnsToCheck; ci++) {
            int cx = startX + ci * (colW + colGap);
            if (!inRect((int) mouseX, (int) mouseY, cx, startY, colW, colH)) continue;
            int maxScroll = Math.max(0, ModuleCatalog.inCategory(CAT_LABELS[ci]).size() - visibleRows);
            int step = Math.max(1, (int) Math.ceil(Math.abs(verticalAmount) * 2));
            scrollOffsets[ci] = Math.max(0, Math.min(maxScroll,
                    scrollOffsets[ci] - (int) Math.signum(verticalAmount) * step));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!listeningForKeybind.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) cfg.setKeybind(listeningForKeybind, 0);
            else if (keyCode != GLFW.GLFW_KEY_RIGHT_SHIFT) cfg.setKeybind(listeningForKeybind, keyCode);
            listeningForKeybind = "";
            cfg.save();
            clickSound();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public void close() { listeningForKeybind = ""; cfg.save(); super.close(); }
    @Override public boolean shouldPause() { return false; }

    private static String[] slidersForModule(String id) {
        return switch (id) {
            case "aim_bot" -> new String[]{"aim_bot_range", "aim_bot_fov", "aim_bot_smooth"};
            case "trigger_bot" -> new String[]{"trigger_bot_range", "trigger_bot_delay"};
            case "auto_potion" -> new String[]{"auto_potion_threshold", "auto_potion_cooldown"};
            case "aura" -> new String[]{"aura_range"};
            case "reach" -> new String[]{"reach_reach"};
            case "speed" -> new String[]{"speed_speed"};
            case "velocity" -> new String[]{"velocity_h", "velocity_v"};
            case "anti_kb" -> new String[]{"anti_kb_h", "anti_kb_v"};
            default -> new String[0];
        };
    }

    private void drawTruncated(DrawContext ctx, String value, int x, int y, int maxWidth, int color) {
        if (maxWidth <= 0) return;
        String shown = value == null ? "" : value;
        while (!shown.isEmpty() && textRenderer.getWidth(shown) > maxWidth) {
            shown = shown.substring(0, shown.length() - 1);
        }
        ctx.enableScissor(x, y - 1, x + maxWidth, y + 10);
        ctx.drawTextWithShadow(textRenderer, shown, x, y, color);
        ctx.disableScissor();
    }

    private static boolean inRect(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static String keyName(int key) {
        if (key <= 0 || key == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            default -> {
                String name = GLFW.glfwGetKeyName(key, 0);
                yield name == null ? "K" + key : name.toUpperCase(Locale.ROOT);
            }
        };
    }

    private void clickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, 0.28f));
    }

    private void toggleSound(boolean enabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), enabled ? 1.22f : 0.82f, 0.36f));
    }
}
