package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** User-configurable settings for the local single-player client. */
public final class ModuleSettings {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public boolean aimAssistEnabled = false;
    public double aimRange = 6.0;
    public double aimSpeed = 10.0;
    public double aimMaxSpeed = 15.0;
    public double aimFov = 175.0;
    public boolean humanize = true;
    public boolean focusMode = true;
    public boolean smartBypass = true;
    public boolean onlyWeapon = true;
    public String aimPoint = "HEAD";
    public String targetMode = "PLAYERS";
    public int aimBindKey = 0;

    public boolean triggerBotEnabled = false;
    public double triggerRange = 4.0;
    public int triggerDelayMs = 120;
    public boolean triggerOnlyWeapon = true;
    public boolean triggerPlayersOnly = true;
    public int triggerMinDelayMs = 80;
    public boolean triggerCriticalOnly = false;

    public static ModuleSettings get() { return INSTANCE; }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                ModuleSettings loaded = GSON.fromJson(Files.readString(FILE), ModuleSettings.class);
                if (loaded != null) return loaded;
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }
}
