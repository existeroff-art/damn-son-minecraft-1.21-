package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persistent client module settings. */
public final class ModuleSettings {
    public int configVersion = 5;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public Map<String, Boolean> moduleStates = new HashMap<>();
    public Map<String, Integer> moduleKeybinds = new HashMap<>();

    public boolean aimAssistEnabled = false;
    public int aimToggleKey = 82;
    public double aimRange = 4.5;
    public double aimSpeed = 13.0;
    public double aimMaxSpeed = 22.0;
    public double aimFov = 360.0;
    public boolean onlyWeapon = false;
    public boolean targetPlayers = true;
    public String aimPoint = "HEAD";

    public boolean triggerBotEnabled = false;
    public int triggerToggleKey = 86;
    public boolean shieldBreakerEnabled = false;
    public int shieldBreakerToggleKey = 66;
    public double shieldRange = 3.0;

    public boolean fpsHudEnabled = true;
    public boolean coordinatesHudEnabled = false;
    public boolean keystrokesHudEnabled = false;
    public boolean armorHudEnabled = false;
    public boolean toggleSprintEnabled = false;

    public static ModuleSettings get() { return INSTANCE; }

    public boolean enabled(String id) {
        if (moduleStates != null && moduleStates.containsKey(id)) return Boolean.TRUE.equals(moduleStates.get(id));
        return switch (id) {
            case "aim_assist" -> aimAssistEnabled;
            case "trigger_bot" -> triggerBotEnabled;
            case "shield_breaker" -> shieldBreakerEnabled;
            case "auto_sprint" -> toggleSprintEnabled;
            case "fps_hud" -> fpsHudEnabled;
            case "coordinates_hud" -> coordinatesHudEnabled;
            case "keystrokes_hud" -> keystrokesHudEnabled;
            case "armor_hud" -> armorHudEnabled;
            default -> false;
        };
    }

    public void setEnabled(String id, boolean enabled) {
        if (moduleStates == null) moduleStates = new HashMap<>();
        moduleStates.put(id, enabled);
        switch (id) {
            case "aim_assist" -> aimAssistEnabled = enabled;
            case "trigger_bot" -> triggerBotEnabled = enabled;
            case "shield_breaker" -> shieldBreakerEnabled = enabled;
            case "auto_sprint" -> toggleSprintEnabled = enabled;
            case "fps_hud" -> fpsHudEnabled = enabled;
            case "coordinates_hud" -> coordinatesHudEnabled = enabled;
            case "keystrokes_hud" -> keystrokesHudEnabled = enabled;
            case "armor_hud" -> armorHudEnabled = enabled;
            default -> { }
        }
    }

    public int keybind(String id) {
        if (moduleKeybinds != null && moduleKeybinds.containsKey(id)) return moduleKeybinds.get(id);
        return switch (id) {
            case "aim_assist" -> aimToggleKey;
            case "trigger_bot" -> triggerToggleKey;
            case "shield_breaker" -> shieldBreakerToggleKey;
            default -> 0;
        };
    }

    public void setKeybind(String id, int key) {
        if (moduleKeybinds == null) moduleKeybinds = new HashMap<>();
        moduleKeybinds.put(id, key);
        switch (id) {
            case "aim_assist" -> aimToggleKey = key;
            case "trigger_bot" -> triggerToggleKey = key;
            case "shield_breaker" -> shieldBreakerToggleKey = key;
            default -> { }
        }
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                int storedVersion = json.has("configVersion") ? json.get("configVersion").getAsInt() : 0;
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded != null) {
                    if (loaded.moduleStates == null) loaded.moduleStates = new HashMap<>();
                    if (loaded.moduleKeybinds == null) loaded.moduleKeybinds = new HashMap<>();
                    if (!json.has("fpsHudEnabled")) loaded.fpsHudEnabled = true;
                    loaded.aimToggleKey = loaded.aimToggleKey <= 0 ? 82 : loaded.aimToggleKey;
                    loaded.triggerToggleKey = loaded.triggerToggleKey <= 0 ? 86 : loaded.triggerToggleKey;
                    loaded.shieldBreakerToggleKey = loaded.shieldBreakerToggleKey <= 0 ? 66 : loaded.shieldBreakerToggleKey;
                    loaded.shieldRange = clamp(loaded.shieldRange, 1.0, 3.0);
                    loaded.aimRange = clamp(loaded.aimRange, 1.0, 6.0);
                    loaded.aimSpeed = clamp(loaded.aimSpeed, 1.0, 20.0);
                    loaded.aimMaxSpeed = clamp(loaded.aimMaxSpeed, 1.0, 30.0);
                    loaded.aimFov = clamp(loaded.aimFov, 30.0, 360.0);
                    if (!"HEAD".equals(loaded.aimPoint) && !"CHEST".equals(loaded.aimPoint)
                            && !"LEGS".equals(loaded.aimPoint)) loaded.aimPoint = "HEAD";
                    loaded.onlyWeapon = false;
                    loaded.configVersion = 5;
                    if (storedVersion < 5) loaded.save();
                    return loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
