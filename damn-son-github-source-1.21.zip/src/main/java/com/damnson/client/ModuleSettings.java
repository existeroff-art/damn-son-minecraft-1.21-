package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** Persistent settings for the six-module Damn Son profile. */
public final class ModuleSettings {
    public int configVersion = 19;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Set<String> ALLOWED_MODULES = Set.of(
            "aim_bot", "trigger_bot", "fast_gapple", "snap_tap", "auto_potion", "potion_refill", "bypass");
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public Map<String, Boolean> moduleStates = new HashMap<>();
    public Map<String, Integer> moduleKeybinds = new HashMap<>();

    // Aim Assist settings.
    public double aimBotRange = 8.0;
    public double aimBotFov = 360.0;
    public double aimBotSmooth = 85.0;
    public int aimBotTargetPoint = 0; // 0=head, 1=chest, 2=body
    public boolean aimBotWeaponsOnly = true;

    // Auto Pot settings.
    public double autoPotionThreshold = 8.0;
    public double autoPotionCooldownTicks = 20.0;

    // Trigger Bot settings.
    public double triggerBotRange = 3.5;
    public double triggerBotDelayTicks = 2.0;

    public ModuleSettings() {}

    public static ModuleSettings get() { return INSTANCE; }

    private static boolean allowedModule(String id) {
        return id != null && ALLOWED_MODULES.contains(id);
    }

    private static void pruneHiddenModules(ModuleSettings settings) {
        if (settings.moduleStates == null) settings.moduleStates = new HashMap<>();
        else settings.moduleStates.keySet().removeIf(id -> !allowedModule(id));
        if (settings.moduleKeybinds == null) settings.moduleKeybinds = new HashMap<>();
        else settings.moduleKeybinds.keySet().removeIf(id -> !allowedModule(id));
    }

    public boolean enabled(String id) {
        if (!allowedModule(id) || moduleStates == null) return false;
        return Boolean.TRUE.equals(moduleStates.get(id));
    }

    public void setEnabled(String id, boolean enabled) {
        if (!allowedModule(id)) return;
        if (moduleStates == null) moduleStates = new HashMap<>();
        moduleStates.put(id, enabled);
    }

    public int keybind(String id) {
        if (!allowedModule(id) || moduleKeybinds == null) return 0;
        return moduleKeybinds.getOrDefault(id, 0);
    }

    public void setKeybind(String id, int key) {
        if (!allowedModule(id)) return;
        if (moduleKeybinds == null) moduleKeybinds = new HashMap<>();
        moduleKeybinds.put(id, key);
    }

    public void save() {
        pruneHiddenModules(this);
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    public void reload() {
        ModuleSettings loaded = load();
        configVersion = loaded.configVersion;
        moduleStates = new HashMap<>(loaded.moduleStates);
        moduleKeybinds = new HashMap<>(loaded.moduleKeybinds);
        aimBotRange = loaded.aimBotRange;
        aimBotFov = loaded.aimBotFov;
        aimBotSmooth = loaded.aimBotSmooth;
        aimBotTargetPoint = loaded.aimBotTargetPoint;
        aimBotWeaponsOnly = loaded.aimBotWeaponsOnly;
        autoPotionThreshold = loaded.autoPotionThreshold;
        autoPotionCooldownTicks = loaded.autoPotionCooldownTicks;
        triggerBotRange = loaded.triggerBotRange;
        triggerBotDelayTicks = loaded.triggerBotDelayTicks;
        pruneHiddenModules(this);
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded == null) loaded = new ModuleSettings();
                pruneHiddenModules(loaded);

                // Explicit defaults for fields absent in older configs.
                if (!json.has("aimBotRange")) loaded.aimBotRange = 8.0;
                if (!json.has("aimBotFov")) loaded.aimBotFov = 360.0;
                if (!json.has("aimBotSmooth")) loaded.aimBotSmooth = 85.0;
                if (!json.has("aimBotTargetPoint")) loaded.aimBotTargetPoint = 0;
                if (!json.has("aimBotWeaponsOnly")) loaded.aimBotWeaponsOnly = true;
                if (!json.has("autoPotionThreshold")) loaded.autoPotionThreshold = 8.0;
                if (!json.has("autoPotionCooldownTicks")) loaded.autoPotionCooldownTicks = 20.0;
                if (!json.has("triggerBotRange")) loaded.triggerBotRange = 3.5;
                if (!json.has("triggerBotDelayTicks")) loaded.triggerBotDelayTicks = 2.0;

                // Migrate pre-v15 Aim Assist defaults while preserving newer user settings.
                if (loaded.configVersion < 15) {
                    loaded.aimBotFov = 360.0;
                    loaded.aimBotRange = Math.max(8.0, loaded.aimBotRange);
                    loaded.aimBotSmooth = Math.max(85.0, loaded.aimBotSmooth);
                }

                loaded.aimBotRange = clamp(loaded.aimBotRange, 2.0, 32.0);
                loaded.aimBotFov = clamp(loaded.aimBotFov, 10.0, 360.0);
                loaded.aimBotSmooth = clamp(loaded.aimBotSmooth, 1.0, 100.0);
                loaded.aimBotTargetPoint = (int) clamp(loaded.aimBotTargetPoint, 0.0, 2.0);
                loaded.autoPotionThreshold = clamp(loaded.autoPotionThreshold, 2.0, 20.0);
                loaded.autoPotionCooldownTicks = clamp(loaded.autoPotionCooldownTicks, 1.0, 40.0);
                loaded.triggerBotRange = clamp(loaded.triggerBotRange, 2.0, 6.0);
                loaded.triggerBotDelayTicks = clamp(loaded.triggerBotDelayTicks, 0.0, 10.0);
                loaded.configVersion = 19;
                loaded.save(); // also removes entries for all retired modules from the user's config
                return loaded;
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
