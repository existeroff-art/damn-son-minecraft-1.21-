package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persistent client module settings. */
public final class ModuleSettings {
    public int configVersion = 9;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public Map<String, Boolean> moduleStates = new HashMap<>();
    public Map<String, Integer> moduleKeybinds = new HashMap<>();

    public boolean fpsHudEnabled = true;
    public boolean coordinatesHudEnabled = false;
    public boolean keystrokesHudEnabled = false;
    public boolean armorHudEnabled = false;
    public boolean toggleSprintEnabled = false;

    // Percentage of the received local-player velocity that remains after Anti-KB is applied.
    public double antiKbHorizontalPercent = 0.0;
    public double antiKbVerticalPercent = 0.0;

    public static ModuleSettings get() { return INSTANCE; }

    public boolean enabled(String id) {
        if (moduleStates != null && moduleStates.containsKey(id)) return Boolean.TRUE.equals(moduleStates.get(id));
        return switch (id) {
            case "auto_sprint" -> toggleSprintEnabled;
            case "fps_hud" -> fpsHudEnabled;
            case "coordinates_hud" -> coordinatesHudEnabled;
            case "keystrokes_hud" -> keystrokesHudEnabled;
            case "armor_hud" -> armorHudEnabled;
            default -> false;
        };
    }

    public void setEnabled(String id, boolean enabled) {
        if (moduleStates == null) moduleStates = new HashMap<>();
        moduleStates.put(id, enabled);
        switch (id) {
            case "auto_sprint" -> toggleSprintEnabled = enabled;
            case "fps_hud" -> fpsHudEnabled = enabled;
            case "coordinates_hud" -> coordinatesHudEnabled = enabled;
            case "keystrokes_hud" -> keystrokesHudEnabled = enabled;
            case "armor_hud" -> armorHudEnabled = enabled;
            default -> { }
        }
    }

    public int keybind(String id) {
        return moduleKeybinds == null ? 0 : moduleKeybinds.getOrDefault(id, 0);
    }

    public void setKeybind(String id, int key) {
        if (moduleKeybinds == null) moduleKeybinds = new HashMap<>();
        moduleKeybinds.put(id, key);
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    public void reload() {
        ModuleSettings loaded = load();
        configVersion = loaded.configVersion;
        moduleStates = new HashMap<>(loaded.moduleStates == null ? Map.of() : loaded.moduleStates);
        moduleKeybinds = new HashMap<>(loaded.moduleKeybinds == null ? Map.of() : loaded.moduleKeybinds);
        fpsHudEnabled = loaded.fpsHudEnabled;
        coordinatesHudEnabled = loaded.coordinatesHudEnabled;
        keystrokesHudEnabled = loaded.keystrokesHudEnabled;
        armorHudEnabled = loaded.armorHudEnabled;
        toggleSprintEnabled = loaded.toggleSprintEnabled;
        antiKbHorizontalPercent = clamp(loaded.antiKbHorizontalPercent, 0.0, 100.0);
        antiKbVerticalPercent = clamp(loaded.antiKbVerticalPercent, 0.0, 100.0);
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                int storedVersion = json.has("configVersion") ? json.get("configVersion").getAsInt() : 0;
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded != null) {
                    if (loaded.moduleStates == null) loaded.moduleStates = new HashMap<>();
                    if (loaded.moduleKeybinds == null) loaded.moduleKeybinds = new HashMap<>();
                    if (!json.has("fpsHudEnabled")) loaded.fpsHudEnabled = true;
                    if (!json.has("antiKbHorizontalPercent")) loaded.antiKbHorizontalPercent = 0.0;
                    if (!json.has("antiKbVerticalPercent")) loaded.antiKbVerticalPercent = 0.0;
                    loaded.antiKbHorizontalPercent = clamp(loaded.antiKbHorizontalPercent, 0.0, 100.0);
                    loaded.antiKbVerticalPercent = clamp(loaded.antiKbVerticalPercent, 0.0, 100.0);
                    loaded.configVersion = 9;
                    if (storedVersion < 9) loaded.save();
                    return loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
