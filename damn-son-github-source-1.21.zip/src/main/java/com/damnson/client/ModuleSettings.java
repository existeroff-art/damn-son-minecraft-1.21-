package com.damnson.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persistent client module settings. */
public final class ModuleSettings {
    public int configVersion = 17;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("damn-son.json");
    private static final ModuleSettings INSTANCE = load();

    public Map<String, Boolean> moduleStates = new HashMap<>();
    public Map<String, Integer> moduleKeybinds = new HashMap<>();

    // Legacy compat fields
    public boolean fpsHudEnabled = true;
    public boolean coordinatesHudEnabled = false;
    public boolean keystrokesHudEnabled = false;
    public boolean armorHudEnabled = false;
    public boolean toggleSprintEnabled = false;

    // Anti-KB (fixed profile, unchanged)
    public double antiKbHorizontalPercent = 50.0;
    public double antiKbVerticalPercent   = 100.0;

    // Velocity (configurable)
    public double velocityHorizontalPercent = 60.0;
    public double velocityVerticalPercent   = 100.0;

    // Aim Assist (FOV is the total horizontal/vertical cone width; 360 = full circle)
    public double aimBotRange   = 8.0;    // target acquisition range in blocks
    public double aimBotFov     = 360.0;  // total FOV; 360 means no angle filtering
    public double aimBotSmooth  = 85.0;   // 1–100; higher = stronger, faster tracking
    public int aimBotTargetPoint = 0;     // 0=head, 1=chest, 2=body
    public boolean aimBotWeaponsOnly = true; // track only while holding a combat weapon

    // Auto Potion
    public double autoPotionThreshold = 8.0;       // health points, 20 = full health
    public double autoPotionCooldownTicks = 20.0;  // minimum ticks between throws

    // Trigger Bot
    public double triggerBotRange = 3.5;  // blocks
    public double triggerBotDelayTicks = 2.0; // configurable delay, 0-10 ticks

    // Aura
    public double auraRange     = 3.8;   // blocks

    // Reach
    public double reachExtra    = 0.8;   // extra blocks added to entity_interaction_range

    // Speed
    public double speedMultiplier = 1.5; // ×1 base + this fraction added

    // Practice compat fields (kept so old configs don't break)
    public double aimAssistRange          = 4.0;
    public double aimAssistStrengthPercent = 18.0;

    public static ModuleSettings get() { return INSTANCE; }

    public boolean enabled(String id) {
        if (moduleStates != null && moduleStates.containsKey(id))
            return Boolean.TRUE.equals(moduleStates.get(id));
        return switch (id) {
            case "fast_gapple"  -> false;
            case "auto_sprint"  -> toggleSprintEnabled;
            case "fps_hud"      -> fpsHudEnabled;
            case "coordinates_hud" -> coordinatesHudEnabled;
            case "keystrokes_hud"  -> keystrokesHudEnabled;
            case "armor_hud"    -> armorHudEnabled;
            default -> false;
        };
    }

    public void setEnabled(String id, boolean enabled) {
        if (moduleStates == null) moduleStates = new HashMap<>();
        moduleStates.put(id, enabled);
        switch (id) {
            case "auto_sprint"       -> toggleSprintEnabled    = enabled;
            case "fps_hud"           -> fpsHudEnabled          = enabled;
            case "coordinates_hud"   -> coordinatesHudEnabled  = enabled;
            case "keystrokes_hud"    -> keystrokesHudEnabled   = enabled;
            case "armor_hud"         -> armorHudEnabled        = enabled;
            default -> {}
        }
    }

    public int keybind(String id) {
        return moduleKeybinds == null ? 0 : moduleKeybinds.getOrDefault(id, 0);
    }

    public void setKeybind(String id, int key) {
        if (moduleKeybinds == null) moduleKeybinds = new HashMap<>();
        moduleKeybinds.put(id, key);
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[Damn Son] Could not save config: " + e.getMessage());
        }
    }

    public void reload() {
        ModuleSettings loaded = load();
        configVersion = loaded.configVersion;
        configVersion          = loaded.configVersion;
        moduleStates           = new HashMap<>(loaded.moduleStates == null ? Map.of() : loaded.moduleStates);
        moduleKeybinds         = new HashMap<>(loaded.moduleKeybinds == null ? Map.of() : loaded.moduleKeybinds);
        fpsHudEnabled          = loaded.fpsHudEnabled;
        coordinatesHudEnabled  = loaded.coordinatesHudEnabled;
        keystrokesHudEnabled   = loaded.keystrokesHudEnabled;
        armorHudEnabled        = loaded.armorHudEnabled;
        toggleSprintEnabled    = loaded.toggleSprintEnabled;
        antiKbHorizontalPercent = clamp(loaded.antiKbHorizontalPercent,  0.0, 100.0);
        antiKbVerticalPercent   = clamp(loaded.antiKbVerticalPercent,    0.0, 100.0);
        velocityHorizontalPercent = clamp(loaded.velocityHorizontalPercent, 0.0, 100.0);
        velocityVerticalPercent   = clamp(loaded.velocityVerticalPercent,   0.0, 100.0);
        aimBotRange    = clamp(loaded.aimBotRange,    2.0, 32.0);
        aimBotFov      = clamp(loaded.aimBotFov,      10.0, 360.0);
        aimBotSmooth   = clamp(loaded.aimBotSmooth,   1.0,  100.0);
        aimBotTargetPoint = (int) clamp(loaded.aimBotTargetPoint, 0, 2);
        aimBotWeaponsOnly = loaded.aimBotWeaponsOnly;
        autoPotionThreshold = clamp(loaded.autoPotionThreshold, 2.0, 20.0);
        autoPotionCooldownTicks = clamp(loaded.autoPotionCooldownTicks, 5.0, 40.0);
        triggerBotRange = clamp(loaded.triggerBotRange, 2.0, 6.0);
        triggerBotDelayTicks = clamp(loaded.triggerBotDelayTicks, 0.0, 10.0);
        auraRange      = clamp(loaded.auraRange,      2.0, 6.0);
        reachExtra     = clamp(loaded.reachExtra,     0.0, 3.0);
        speedMultiplier = clamp(loaded.speedMultiplier, 0.1, 4.0);
    }

    private static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                String raw = Files.readString(FILE);
                JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
                ModuleSettings loaded = GSON.fromJson(json, ModuleSettings.class);
                if (loaded != null) {
                    if (loaded.moduleStates == null)   loaded.moduleStates   = new HashMap<>();
                    if (loaded.moduleKeybinds == null) loaded.moduleKeybinds = new HashMap<>();
                    // Configs created before version 15 capped FOV at 180 and used weak default strength.
                    // Migrate those defaults so the requested 360-degree, high-strength profile is active.
                    if (loaded.configVersion < 15) {
                        loaded.aimBotFov = 360.0;
                        loaded.aimBotRange = Math.max(8.0, loaded.aimBotRange);
                        loaded.aimBotSmooth = Math.max(85.0, loaded.aimBotSmooth);
                    }
                    if (!json.has("fpsHudEnabled"))    loaded.fpsHudEnabled  = true;
                    if (!json.has("antiKbHorizontalPercent")) loaded.antiKbHorizontalPercent = 50.0;
                    if (!json.has("antiKbVerticalPercent"))   loaded.antiKbVerticalPercent   = 100.0;
                    if (!json.has("velocityHorizontalPercent")) loaded.velocityHorizontalPercent = 60.0;
                    if (!json.has("velocityVerticalPercent"))   loaded.velocityVerticalPercent   = 100.0;
                    if (!json.has("aimBotRange"))   loaded.aimBotRange   = 8.0;
                    if (!json.has("aimBotFov"))     loaded.aimBotFov     = 360.0;
                    if (!json.has("aimBotSmooth"))  loaded.aimBotSmooth  = 85.0;
                    if (!json.has("aimBotTargetPoint")) loaded.aimBotTargetPoint = 0;
                    if (!json.has("aimBotWeaponsOnly")) loaded.aimBotWeaponsOnly = true;
                    if (!json.has("autoPotionThreshold")) loaded.autoPotionThreshold = 8.0;
                    if (!json.has("autoPotionCooldownTicks")) loaded.autoPotionCooldownTicks = 20.0;
                    if (!json.has("triggerBotRange")) loaded.triggerBotRange = 3.5;
                    if (!json.has("triggerBotDelayTicks")) loaded.triggerBotDelayTicks = 2.0;
                    if (!json.has("auraRange"))     loaded.auraRange     = 3.8;
                    if (!json.has("reachExtra"))    loaded.reachExtra    = 0.8;
                    if (!json.has("speedMultiplier")) loaded.speedMultiplier = 1.5;
                    loaded.antiKbHorizontalPercent    = clamp(loaded.antiKbHorizontalPercent,    0.0, 100.0);
                    loaded.antiKbVerticalPercent      = clamp(loaded.antiKbVerticalPercent,      0.0, 100.0);
                    loaded.velocityHorizontalPercent  = clamp(loaded.velocityHorizontalPercent,  0.0, 100.0);
                    loaded.velocityVerticalPercent    = clamp(loaded.velocityVerticalPercent,    0.0, 100.0);
                    loaded.aimBotRange    = clamp(loaded.aimBotRange,    2.0, 32.0);
                    loaded.aimBotFov      = clamp(loaded.aimBotFov,      10.0, 360.0);
                    loaded.aimBotSmooth   = clamp(loaded.aimBotSmooth,   1.0,  100.0);
                    loaded.aimBotTargetPoint = (int) clamp(loaded.aimBotTargetPoint, 0, 2);
                    loaded.autoPotionThreshold = clamp(loaded.autoPotionThreshold, 2.0, 20.0);
                    loaded.autoPotionCooldownTicks = clamp(loaded.autoPotionCooldownTicks, 5.0, 40.0);
                    loaded.triggerBotRange = clamp(loaded.triggerBotRange, 2.0, 6.0);
                    loaded.triggerBotDelayTicks = clamp(loaded.triggerBotDelayTicks, 0.0, 10.0);
                    loaded.auraRange      = clamp(loaded.auraRange,      2.0, 6.0);
                    loaded.reachExtra     = clamp(loaded.reachExtra,     0.0, 3.0);
                    loaded.speedMultiplier = clamp(loaded.speedMultiplier, 0.1, 4.0);
                    loaded.configVersion  = 17;
                    loaded.save();
                    return loaded;
                }
            }
        } catch (Exception e) {
            System.err.println("[Damn Son] Invalid config; using defaults: " + e.getMessage());
        }
        return new ModuleSettings();
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
