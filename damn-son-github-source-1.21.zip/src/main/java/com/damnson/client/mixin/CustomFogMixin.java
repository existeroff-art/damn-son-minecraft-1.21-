package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BackgroundRenderer.class)
public abstract class CustomFogMixin {
    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void damnson$extendAtmosphericFog(Camera camera, @Coerce Object fogType,
                                                      float viewDistance, boolean thickFog,
                                                      float tickDelta, CallbackInfo ci) {
        if (!ModuleSettings.get().enabled("custom_fog")
                || camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        float end = Math.max(viewDistance + 16.0f, viewDistance * 1.75f);
        RenderSystem.setShaderFogStart(end * 0.55f);
        RenderSystem.setShaderFogEnd(end);
    }
}
