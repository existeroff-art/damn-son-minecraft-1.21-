package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class NoWebMixin {
    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
    private void damnson$ignoreCobwebSlowdown(BlockState state, Vec3d multiplier, CallbackInfo ci) {
        Entity self = (Entity) (Object) this;
        MinecraftClient client = MinecraftClient.getInstance();
        if (self == client.player && state.isOf(Blocks.COBWEB)
                && ModuleSettings.get().enabled("no_web")) {
            ci.cancel();
        }
    }
}
