package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    /**
     * Velocity module: scales the velocity packet applied to our own player.
     * No solo/practice guard — works on any server.
     */
    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
    private void damnson$scaleLocalPlayerVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (packet.getEntityId() != client.player.getId()) return;

        ModuleSettings cfg = ModuleSettings.get();

        // Velocity module (configurable multiplier)
        if (cfg.enabled("velocity")) {
            Vec3d vel = client.player.getVelocity();
            double h = Math.max(0.0, Math.min(100.0, cfg.velocityHorizontalPercent)) / 100.0;
            double v = Math.max(0.0, Math.min(100.0, cfg.velocityVerticalPercent))   / 100.0;
            client.player.setVelocity(vel.x * h, vel.y * v, vel.z * h);
            return; // don't double-apply
        }

        // Anti-KB (fixed profile, lower priority than Velocity)
        if (cfg.enabled("anti_kb")) {
            Vec3d vel = client.player.getVelocity();
            double h = Math.max(0.0, Math.min(100.0, cfg.antiKbHorizontalPercent)) / 100.0;
            double v = Math.max(0.0, Math.min(100.0, cfg.antiKbVerticalPercent))   / 100.0;
            client.player.setVelocity(vel.x * h, vel.y * v, vel.z * h);
        }
    }
}
