package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import com.damnson.client.PracticeWorldGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
    private void damnson$scaleLocalPlayerVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        // Practice-only: do not alter velocity received in any multiplayer session,
        // including single-player worlds opened to LAN with other players connected.
        if (!PracticeWorldGuard.isSoloIntegratedWorld(client) || client.player == null || client.world == null
                || packet.getEntityId() != client.player.getId()) return;

        ModuleSettings cfg = ModuleSettings.get();
        if (!cfg.enabled("anti_kb")) return;

        Vec3d velocity = client.player.getVelocity();
        double horizontal = Math.max(0.0, Math.min(100.0, cfg.antiKbHorizontalPercent)) / 100.0;
        double vertical = Math.max(0.0, Math.min(100.0, cfg.antiKbVerticalPercent)) / 100.0;
        client.player.setVelocity(velocity.x * horizontal, velocity.y * vertical, velocity.z * horizontal);
    }
}
