package com.damnson.client.mixin;

import com.damnson.client.ModuleSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputSnapTapMixin {
    @Shadow public float movementSideways;
    @Shadow public float movementForward;
    @Shadow public boolean pressingLeft;
    @Shadow public boolean pressingRight;
    @Shadow public boolean pressingForward;
    @Shadow public boolean pressingBack;

    private static boolean damnson$wasLeft;
    private static boolean damnson$wasRight;
    private static boolean damnson$wasForward;
    private static boolean damnson$wasBack;
    private static long damnson$sequence;
    private static long damnson$leftOrder;
    private static long damnson$rightOrder;
    private static long damnson$forwardOrder;
    private static long damnson$backOrder;

    @Inject(method = "tick", at = @At("TAIL"))
    private void damnson$applySnapTap(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.currentScreen != null || !ModuleSettings.get().enabled("snap_tap")) {
            damnson$reset();
            return;
        }

        if (pressingLeft && !damnson$wasLeft) damnson$leftOrder = ++damnson$sequence;
        if (pressingRight && !damnson$wasRight) damnson$rightOrder = ++damnson$sequence;
        if (pressingForward && !damnson$wasForward) damnson$forwardOrder = ++damnson$sequence;
        if (pressingBack && !damnson$wasBack) damnson$backOrder = ++damnson$sequence;

        if (pressingLeft && pressingRight) {
            movementSideways = (damnson$leftOrder > damnson$rightOrder ? 1.0F : -1.0F)
                    * (slowDown ? slowDownFactor : 1.0F);
        }
        if (pressingForward && pressingBack) {
            movementForward = (damnson$forwardOrder > damnson$backOrder ? 1.0F : -1.0F)
                    * (slowDown ? slowDownFactor : 1.0F);
        }

        damnson$wasLeft = pressingLeft;
        damnson$wasRight = pressingRight;
        damnson$wasForward = pressingForward;
        damnson$wasBack = pressingBack;
    }

    private static void damnson$reset() {
        damnson$wasLeft = false;
        damnson$wasRight = false;
        damnson$wasForward = false;
        damnson$wasBack = false;
        damnson$leftOrder = 0;
        damnson$rightOrder = 0;
        damnson$forwardOrder = 0;
        damnson$backOrder = 0;
    }
}
