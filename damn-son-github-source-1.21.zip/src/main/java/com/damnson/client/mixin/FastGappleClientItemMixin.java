package com.damnson.client.mixin;

import com.damnson.client.FastGappleTogglePayload;
import com.damnson.client.ModuleSettings;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Item.class)
public abstract class FastGappleClientItemMixin {
    @Inject(method = "getMaxUseTime", at = @At("HEAD"), cancellable = true)
    private void damnson$reduceLocalGoldenAppleUseTime(ItemStack stack, LivingEntity user,
                                                        CallbackInfoReturnable<Integer> cir) {
        if (!(user instanceof ClientPlayerEntity clientPlayer)
                || clientPlayer != MinecraftClient.getInstance().player
                || !(stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE))) return;
        MinecraftClient client = MinecraftClient.getInstance();
        boolean serverSupportsToggle = client.isInSingleplayer() || ClientPlayNetworking.canSend(FastGappleTogglePayload.ID);
        if (serverSupportsToggle && ModuleSettings.get().enabled("fast_gapple")) cir.setReturnValue(12);
    }
}
