package com.damnson.client.mixin;

import com.damnson.client.UtilityModules;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class AimAssistRenderMixin {
    @Inject(method = "render(Z)V", at = @At("HEAD"))
    private void damnson$interpolateAimAssist(boolean tick, CallbackInfo ci) {
        UtilityModules.onRenderFrame();
    }
}
