package com.damnson.client.mixin;

import com.damnson.client.DamnSonCommon;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Item.class)
public abstract class FastGappleItemMixin {
    @Inject(method = "getMaxUseTime", at = @At("HEAD"), cancellable = true)
    private void damnson$reduceGoldenAppleUseTime(ItemStack stack, LivingEntity user,
                                                   CallbackInfoReturnable<Integer> cir) {
        if (!(stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE))) return;
        if (user instanceof ServerPlayerEntity serverPlayer && DamnSonCommon.isFastGappleEnabled(serverPlayer)) {
            cir.setReturnValue(12);
        }
    }
}
