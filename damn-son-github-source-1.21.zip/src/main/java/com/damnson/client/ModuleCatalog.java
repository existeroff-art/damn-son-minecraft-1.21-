package com.damnson.client;

import java.util.List;

public final class ModuleCatalog {
    public record Module(String id, String name, String category, String description) {}

    public static final List<Module> MODULES = List.of(
            new Module("anti_kb", "Anti-KB", "COMBAT", "Solo integrated world only; fixed profile, toggle with keybind"),
            new Module("aim_assist", "Aim Assist", "COMBAT", "Practice only: smoothly tracks nearby non-player mobs"),
            new Module("trigger_bot", "Trigger Bot", "COMBAT", "Practice only: attacks a non-player mob under the crosshair"),
            new Module("auto_sprint", "Auto Sprint", "MOVEMENT", "Sprint while moving forward"),
            new Module("auto_jump", "Auto Jump", "MOVEMENT", "Hold jump while moving forward"),
            new Module("snap_tap", "Snap Tap", "MOVEMENT", "Last-input priority for opposite WASD keys; check server rules"),
            new Module("fullbright", "Fullbright", "RENDER", "Set vanilla brightness to maximum"),
            new Module("zoom", "Zoom", "RENDER", "Lower FOV while enabled"),
            new Module("auto_eat", "Auto Eat", "PLAYER", "Eat food when hunger is low"),
            new Module("fast_gapple", "Fast Gapple", "PLAYER", "Faster golden-apple use; requires an enabled server-side Damn Son install"),
            new Module("auto_tool", "Auto Tool", "PLAYER", "Select the best hotbar tool for the targeted block"),
            new Module("auto_respawn", "Auto Respawn", "PLAYER", "Respawn after death"),
            new Module("toggle_sneak", "Toggle Sneak", "MISC", "Keep sneak active while enabled"),
            new Module("fps_hud", "FPS HUD", "HUD", "Show the current frame rate"),
            new Module("coordinates_hud", "Coordinates HUD", "HUD", "Show XYZ and dimension"),
            new Module("keystrokes_hud", "Keystrokes", "HUD", "Show movement and jump keys"),
            new Module("armor_hud", "Armor HUD", "HUD", "Show remaining armor durability"),
            new Module("ping_hud", "Ping HUD", "HUD", "Show your current server latency"),
            new Module("biome_hud", "Biome HUD", "HUD", "Show the current biome"),
            new Module("direction_hud", "Direction HUD", "HUD", "Show the direction you face"),
            new Module("speed_hud", "Speed HUD", "HUD", "Show horizontal movement speed"),
            new Module("clock_hud", "World Clock", "HUD", "Show in-game time"),
            new Module("watermark_hud", "Watermark", "HUD", "Show the client brand"),
            new Module("array_list_hud", "Active Modules", "HUD", "List enabled modules on-screen")
    );

    private ModuleCatalog() {}

    public static List<Module> inCategory(String category) {
        return MODULES.stream().filter(m -> m.category().equals(category)).toList();
    }

    public static Module byId(String id) {
        return MODULES.stream().filter(m -> m.id().equals(id)).findFirst().orElse(null);
    }
}
