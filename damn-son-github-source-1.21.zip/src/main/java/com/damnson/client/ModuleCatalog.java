package com.damnson.client;

import java.util.List;

public final class ModuleCatalog {
    public record Module(String id, String name, String category, String description) {}

    public static final String[] CATEGORIES = {"COMBAT", "MOVEMENT", "VISUALS", "PLAYER", "OTHER"};

    public static final List<Module> MODULES = List.of(
        // ── COMBAT ─────────────────────────────────────────────────────────
        new Module("aim_bot",      "Aim Assist",   "COMBAT",   "Smooth target tracking; configure range, FOV and speed"),
        new Module("anti_bot",     "Anti Bot",     "COMBAT",   "Restrict Aim Assist and Aura targets to player entities"),
        new Module("aura",         "Aura",         "COMBAT",   "Auto-attack nearest entity in range"),
        new Module("auto_armor",   "Auto Armor",   "COMBAT",   "Equip armor automatically when an armor slot is empty"),
        new Module("auto_gapple",  "Auto GApple",  "COMBAT",   "Eat a golden apple when health drops below 7 hearts"),
        new Module("auto_potion",  "Auto Potion",  "COMBAT",   "Use a hotbar splash potion at low health"),
        new Module("auto_soup",    "Auto Soup",    "COMBAT",   "Use mushroom stew when health is low"),
        new Module("auto_totem",   "Auto Totem",   "COMBAT",   "Move a totem from inventory into the off-hand"),
        new Module("back_track",   "Back Track",   "COMBAT",   "Delay entity position replication"),
        new Module("criticals",    "Criticals",    "COMBAT",   "Time Aura attacks for the falling phase after a micro-hop"),
        new Module("reach",        "Reach",        "COMBAT",   "Extend melee attack range"),
        new Module("trigger_bot",  "Trigger Bot",  "COMBAT",   "Attack crosshair targets after a configurable tick delay"),
        new Module("velocity",     "Velocity",     "COMBAT",   "Reduce incoming horizontal/vertical knockback"),
        new Module("anti_kb",      "Anti-KB",      "COMBAT",   "Reduce knockback with adjustable horizontal and vertical values"),

        // ── MOVEMENT ───────────────────────────────────────────────────────
        new Module("auto_sprint",    "Auto Sprint",    "MOVEMENT", "Sprint while moving forward"),
        new Module("auto_jump",      "Auto Jump",      "MOVEMENT", "Hold jump while moving forward"),
        new Module("snap_tap",       "Snap Tap",       "MOVEMENT", "Last-input priority for opposite WASD keys"),
        new Module("elytra_strafe",  "Elytra Strafe",  "MOVEMENT", "Add lateral steering while gliding"),
        new Module("flight",         "Flight",         "MOVEMENT", "Client-side vertical control with jump and sneak"),
        new Module("no_slow",        "No Slow",        "MOVEMENT", "Remove slowdown during item use"),
        new Module("no_web",         "No Web",         "MOVEMENT", "Move freely through cobwebs"),
        new Module("speed",          "Speed",          "MOVEMENT", "Increase movement speed attribute"),
        new Module("spider",         "Spider",         "MOVEMENT", "Climb when colliding with a wall"),
        new Module("timer",          "Timer",          "MOVEMENT", "Alter game tick speed"),
        new Module("wind_hop",       "Wind Hop",       "MOVEMENT", "Hop periodically while moving on the ground"),

        // ── VISUALS ────────────────────────────────────────────────────────
        new Module("fullbright",       "Ambience",       "VISUALS", "Maximum brightness"),
        new Module("zoom",             "Zoom",           "VISUALS", "Lower FOV while enabled"),
        new Module("esp",              "ESP",            "VISUALS", "Render colored name tags through walls"),
        new Module("anti_invisible",   "Anti Invisible", "VISUALS", "Show labels for invisible players"),
        new Module("arrows",           "Arrows",         "VISUALS", "Show direction indicators for nearby players"),
        new Module("custom_fog",       "Custom Fog",     "VISUALS", "Extend atmospheric fog distance outside fluids"),
        new Module("kill_effects",     "Kill Effects",   "VISUALS", "Spawn hit particles when Aura or Trigger Bot attacks"),
        new Module("name_tags",        "Name Tags",      "VISUALS", "Show health above player name tags"),
        new Module("array_list_hud",   "Active Modules", "VISUALS", "List enabled modules on-screen"),

        // ── PLAYER ─────────────────────────────────────────────────────────
        new Module("auto_eat",      "Auto Eat",      "PLAYER", "Eat food when hunger drops below 7"),
        new Module("fast_gapple",   "Fast Gapple",   "PLAYER", "Faster golden apple use (server install required)"),
        new Module("auto_tool",     "Auto Tool",     "PLAYER", "Select best hotbar tool for targeted block"),
        new Module("auto_respawn",  "Auto Respawn",  "PLAYER", "Respawn automatically after death"),
        new Module("auto_farm",     "Auto Farm",     "PLAYER", "Auto-break mature crops under the crosshair"),
        new Module("auto_brew",     "Auto Brew",     "PLAYER", "Auto-brew potions in a brewing stand"),
        new Module("blink",         "Blink",         "PLAYER", "Buffer outbound packets; flush on toggle-off"),
        new Module("free_camera",   "Free Camera",   "PLAYER", "Detach camera from your body"),

        // ── OTHER ──────────────────────────────────────────────────────────
        new Module("toggle_sneak",     "Toggle Sneak",  "OTHER", "Keep sneak active while enabled"),
        new Module("death_cords",      "Death Cords",   "OTHER", "Print coordinates to chat on death"),
        new Module("fps_hud",          "FPS HUD",       "OTHER", "Show current frame rate"),
        new Module("coordinates_hud",  "Coordinates",   "OTHER", "Show XYZ and dimension"),
        new Module("ping_hud",         "Ping HUD",      "OTHER", "Show server latency"),
        new Module("biome_hud",        "Biome HUD",     "OTHER", "Show current biome"),
        new Module("direction_hud",    "Direction",     "OTHER", "Show facing direction"),
        new Module("speed_hud",        "Speed HUD",     "OTHER", "Show horizontal movement speed"),
        new Module("clock_hud",        "World Clock",   "OTHER", "Show in-game time"),
        new Module("armor_hud",        "Armor HUD",     "OTHER", "Show armor durability"),
        new Module("keystrokes_hud",   "Keystrokes",    "OTHER", "Show movement key states"),
        new Module("watermark_hud",    "Watermark",     "OTHER", "Show client brand in HUD")
    );

    private ModuleCatalog() {}

    public static List<Module> inCategory(String category) {
        return MODULES.stream().filter(m -> m.category().equals(category)).toList();
    }

    public static Module byId(String id) {
        return MODULES.stream().filter(m -> m.id().equals(id)).findFirst().orElse(null);
    }
}
