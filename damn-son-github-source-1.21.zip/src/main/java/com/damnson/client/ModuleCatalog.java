package com.damnson.client;

import java.util.List;

/** Only the six modules requested for this build are available in the menu. */
public final class ModuleCatalog {
    public record Module(String id, String name, String category, String description) {
        public boolean implemented() { return true; }
    }

    public static final String[] CATEGORIES = {"COMBAT", "MOVEMENT", "PLAYER", "BYPASS"};

    public static final List<Module> MODULES = List.of(
            new Module("aim_bot", "Aim Assist", "COMBAT", "Range, FOV, strength, aim point and weapon filter"),
            new Module("trigger_bot", "Trigger Bot", "COMBAT", "Crosshair target range and delay"),
            new Module("snap_tap", "Snap Tap", "MOVEMENT", "Last-input priority for opposite WASD keys"),
            new Module("auto_potion", "Auto Pot", "PLAYER", "Use a healing splash potion below a health threshold"),
            new Module("potion_refill", "Auto Pot Refill", "PLAYER", "Refill a used hotbar potion from matching inventory potions"),
            new Module("fast_gapple", "Fast Gap", "PLAYER", "Faster golden-apple use; server support may be required"),
            new Module("bypass", "Bypass", "BYPASS", "Jitter, rotation clamp, action throttle and movement smooth — makes actions look human")
    );

    private ModuleCatalog() {}

    public static List<Module> inCategory(String category) {
        return MODULES.stream().filter(module -> module.category().equals(category)).toList();
    }

    public static Module byId(String id) {
        return MODULES.stream().filter(module -> module.id().equals(id)).findFirst().orElse(null);
    }
}
