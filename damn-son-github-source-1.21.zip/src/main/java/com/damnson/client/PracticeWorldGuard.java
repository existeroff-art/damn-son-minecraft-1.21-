package com.damnson.client;

import net.minecraft.client.MinecraftClient;

/**
 * Restricts combat practice helpers to a solo integrated world. This also rejects
 * single-player worlds opened to LAN when additional players are connected.
 */
public final class PracticeWorldGuard {
    private PracticeWorldGuard() {}

    public static boolean isSoloIntegratedWorld(MinecraftClient client) {
        if (client == null || !client.isInSingleplayer()) return false;
        var server = client.getServer();
        return server != null && server.getPlayerManager().getPlayerList().size() <= 1;
    }
}
