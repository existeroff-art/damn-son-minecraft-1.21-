package com.damnson.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public final class DamnSonClient implements ClientModInitializer {
    private static KeyBinding openMenu;
    private static boolean rightShiftWasDown;
    private final Map<String, Boolean> keyWasDown = new HashMap<>();

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.damnson.open_menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.damnson"));
        UtilityModules.registerHud();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean openRequested = false;
            while (openMenu.wasPressed()) openRequested = true;
            boolean shiftDown = client.getWindow() != null
                    && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (shiftDown && !rightShiftWasDown) openRequested = true;
            rightShiftWasDown = shiftDown;

            if (openRequested) {
                if (client.currentScreen instanceof DamnSonScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new DamnSonScreen());
            }

            ModuleSettings cfg = ModuleSettings.get();
            if (client.getWindow() != null && client.currentScreen == null) {
                long window = client.getWindow().getHandle();
                for (ModuleCatalog.Module module : ModuleCatalog.MODULES) {
                    int key = cfg.keybind(module.id());
                    boolean down = key > 0 && GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                    boolean wasDown = keyWasDown.getOrDefault(module.id(), false);
                    if (down && !wasDown) {
                        cfg.setEnabled(module.id(), !cfg.enabled(module.id()));
                        cfg.save();
                        playToggleSound(client, cfg.enabled(module.id()));
                    }
                    keyWasDown.put(module.id(), down);
                }
            } else {
                for (ModuleCatalog.Module module : ModuleCatalog.MODULES) keyWasDown.put(module.id(), false);
            }

            if (client.currentScreen == null) CombatModules.tick(client);
            UtilityModules.tick(client);
        });
        System.out.println("[Damn Son] Client initialized. Right Shift opens the menu.");
    }

    private static void playToggleSound(net.minecraft.client.MinecraftClient client, boolean enabled) {
        if (client.player != null) {
            client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),
                    0.38F, enabled ? 1.62F : 0.82F);
        }
    }
}
