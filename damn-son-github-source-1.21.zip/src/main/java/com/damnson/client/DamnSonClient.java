package com.damnson.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public final class DamnSonClient implements ClientModInitializer {
    private static KeyBinding openMenu;
    private static boolean rightShiftWasDown;
    private static boolean fastGappleSyncPending;
    private final Map<String, Boolean> keyWasDown = new HashMap<>();

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.damnson.open_menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.damnson"));

        UtilityModules.registerHud();

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            fastGappleSyncPending = true;
            syncFastGappleToggle();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> fastGappleSyncPending = true);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // ── Menu open/close ──────────────────────────────────────────
            boolean openRequested = false;
            while (openMenu.wasPressed()) openRequested = true;
            boolean shiftDown = client.getWindow() != null
                    && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (shiftDown && !rightShiftWasDown) openRequested = true;
            rightShiftWasDown = shiftDown;

            if (openRequested) {
                if (client.currentScreen instanceof DamnSonScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new DamnSonScreen());
            }

            // ── Module keybinds ──────────────────────────────────────────
            ModuleSettings cfg = ModuleSettings.get();
            if (client.getWindow() != null && client.currentScreen == null) {
                long window = client.getWindow().getHandle();
                for (ModuleCatalog.Module module : ModuleCatalog.MODULES) {
                    if (!module.implemented()) continue;
                    int key = cfg.keybind(module.id());
                    boolean down    = key > 0 && GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                    boolean wasDown = keyWasDown.getOrDefault(module.id(), false);
                    if (down && !wasDown) {
                        cfg.setEnabled(module.id(), !cfg.enabled(module.id()));
                        cfg.save();
                        if ("fast_gapple".equals(module.id())) syncFastGappleToggle();
                        playToggleSound(client, cfg.enabled(module.id()));
                    }
                    keyWasDown.put(module.id(), down);
                }
            } else {
                for (ModuleCatalog.Module module : ModuleCatalog.MODULES) keyWasDown.put(module.id(), false);
            }

            if (fastGappleSyncPending) syncFastGappleToggle();
            UtilityModules.tick(client);
        });

        System.out.println("[Damn Son] v0.7.7 — Right Shift opens the menu.");
    }

    public static void syncFastGappleToggle() {
        var client = net.minecraft.client.MinecraftClient.getInstance();
        if (client == null || client.player == null || client.getNetworkHandler() == null) return;
        boolean enabled = ModuleSettings.get().enabled("fast_gapple");
        if (client.isInSingleplayer()) DamnSonCommon.setFastGappleEnabled(client.player.getUuid(), enabled);
        if (ClientPlayNetworking.canSend(FastGappleTogglePayload.ID))
            ClientPlayNetworking.send(new FastGappleTogglePayload(enabled));
        fastGappleSyncPending = false;
    }

    private static void playToggleSound(net.minecraft.client.MinecraftClient client, boolean enabled) {
        if (client != null) client.getSoundManager().play(PositionedSoundInstance.master(
                SoundEvents.UI_BUTTON_CLICK.value(), enabled ? 1.22f : 0.82f, 0.36f));
    }
}
