package com.damnson.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class UtilityModules {
    private static double previousX;
    private static double previousZ;
    private static double horizontalSpeed;
    private static long lastEatTick;
    private static long lastAutoJumpTick;
    private static boolean fullbrightWasEnabled;
    private static double originalGamma = 1.0;
    private static boolean zoomWasEnabled;
    private static int originalFov = 70;
    private static boolean sneakWasEnabled;

    private UtilityModules() {}

    public static void registerHud() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
    }

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) return;
        ModuleSettings cfg = ModuleSettings.get();

        if (cfg.enabled("auto_respawn") && client.player.isDead() && client.currentScreen != null) {
            client.player.requestRespawn();
            client.setScreen(null);
        }

        if (client.currentScreen != null) return;

        boolean sneakEnabled = cfg.enabled("toggle_sneak");
        if (sneakEnabled) client.options.sneakKey.setPressed(true);
        else if (sneakWasEnabled) client.options.sneakKey.setPressed(false);
        sneakWasEnabled = sneakEnabled;

        if (cfg.enabled("auto_sprint") && client.options.forwardKey.isPressed()
                && !client.options.sneakKey.isPressed() && !client.player.isUsingItem()
                && !client.player.isFallFlying() && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }

        boolean autoJump = cfg.enabled("auto_jump") && client.options.forwardKey.isPressed()
                && client.player.isOnGround() && !client.player.isTouchingWater()
                && !client.player.isInLava() && !client.player.isUsingItem();
        long worldTick = client.world.getTime();
        if (autoJump && worldTick - lastAutoJumpTick >= 10) {
            client.player.jump();
            lastAutoJumpTick = worldTick;
        }

        tickAutoTool(client, cfg);
        tickAutoEat(client, cfg);
        tickFullbright(client, cfg);
        tickZoom(client, cfg);

        horizontalSpeed = Math.sqrt(Math.pow(client.player.getX() - previousX, 2)
                + Math.pow(client.player.getZ() - previousZ, 2)) * 20.0;
        previousX = client.player.getX();
        previousZ = client.player.getZ();
    }

    private static void tickAutoTool(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_tool") || !(client.crosshairTarget instanceof BlockHitResult hit)) return;
        var state = client.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return;
        int bestSlot = client.player.getInventory().selectedSlot;
        float bestSpeed = client.player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            float speed = stack.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed * 1.05F) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }
        client.player.getInventory().selectedSlot = bestSlot;
    }

    private static void tickAutoEat(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("auto_eat") || client.player.getHungerManager().getFoodLevel() > 14
                || client.player.isUsingItem() || client.player.getHungerManager().getFoodLevel() >= 20) return;
        long tick = client.world.getTime();
        if (tick - lastEatTick < 8) return;
        int foodSlot = -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (stack.contains(DataComponentTypes.FOOD)) {
                foodSlot = slot;
                break;
            }
        }
        if (foodSlot < 0) return;
        client.player.getInventory().selectedSlot = foodSlot;
        client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
        lastEatTick = tick;
    }

    private static void tickFullbright(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("fullbright");
        if (enabled && !fullbrightWasEnabled) originalGamma = client.options.getGamma().getValue();
        if (enabled) client.options.getGamma().setValue(1.0);
        else if (fullbrightWasEnabled) client.options.getGamma().setValue(originalGamma);
        fullbrightWasEnabled = enabled;
    }

    private static void tickZoom(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("zoom");
        if (enabled && !zoomWasEnabled) originalFov = client.options.getFov().getValue();
        if (enabled) client.options.getFov().setValue(30);
        else if (zoomWasEnabled) client.options.getFov().setValue(originalFov);
        zoomWasEnabled = enabled;
    }

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null || client.options.hudHidden) return;
        ModuleSettings cfg = ModuleSettings.get();
        int x = 6;
        int y = 6;
        int line = 11;

        if (cfg.enabled("watermark_hud")) {
            draw(context, "DAMN SON  /  1.21", x, y, 0xFFC39AFF);
            y += line;
        }
        if (cfg.enabled("fps_hud")) {
            draw(context, "FPS  " + client.getCurrentFps(), x, y);
            y += line;
        }
        if (cfg.enabled("coordinates_hud")) {
            draw(context, String.format(Locale.ROOT, "XYZ  %d / %d / %d",
                    client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ()), x, y);
            y += line;
            String dimension = client.world.getRegistryKey().getValue().getPath();
            draw(context, "DIM  " + dimension, x, y);
            y += line;
        }
        if (cfg.enabled("ping_hud")) {
            var handler = client.getNetworkHandler();
            var entry = handler == null ? null : handler.getPlayerListEntry(client.player.getUuid());
            draw(context, "PING  " + (entry == null ? "--" : entry.getLatency() + " ms"), x, y);
            y += line;
        }
        if (cfg.enabled("biome_hud")) {
            String biome = client.world.getBiome(client.player.getBlockPos()).getKey()
                    .map(key -> key.getValue().getPath()).orElse("unknown");
            draw(context, "BIOME  " + biome, x, y);
            y += line;
        }
        if (cfg.enabled("direction_hud")) {
            String[] directions = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
            int index = Math.floorMod(Math.round(client.player.getYaw() / 45.0F), 8);
            draw(context, "FACING  " + directions[index], x, y);
            y += line;
        }
        if (cfg.enabled("speed_hud")) {
            draw(context, String.format(Locale.ROOT, "SPEED  %.2f m/s", horizontalSpeed), x, y);
            y += line;
        }
        if (cfg.enabled("clock_hud")) {
            long time = Math.floorMod(client.world.getTimeOfDay() + 6000L, 24000L);
            int hour = (int) (time / 1000L);
            int minute = (int) ((time % 1000L) * 60L / 1000L);
            draw(context, String.format(Locale.ROOT, "TIME  %02d:%02d", hour, minute), x, y);
            y += line;
        }
        if (cfg.enabled("armor_hud")) {
            StringBuilder armor = new StringBuilder("ARMOR  ");
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot slot : slots) {
                ItemStack stack = client.player.getEquippedStack(slot);
                if (stack.isEmpty()) armor.append("--  ");
                else if (stack.isDamageable()) {
                    int remaining = 100 - Math.round(stack.getDamage() * 100.0F / stack.getMaxDamage());
                    armor.append(remaining).append("%  ");
                } else armor.append("OK  ");
            }
            draw(context, armor.toString().trim(), x, y);
            y += line;
        }
        if (cfg.enabled("keystrokes_hud")) {
            drawKey(context, "W", client.options.forwardKey.isPressed(), x + 22, y + 1);
            drawKey(context, "A", client.options.leftKey.isPressed(), x, y + 23);
            drawKey(context, "S", client.options.backKey.isPressed(), x + 22, y + 23);
            drawKey(context, "D", client.options.rightKey.isPressed(), x + 44, y + 23);
            drawKey(context, "JUMP", client.options.jumpKey.isPressed(), x, y + 45, 66);
        }
        if (cfg.enabled("array_list_hud")) {
            List<String> active = new ArrayList<>();
            for (ModuleCatalog.Module module : ModuleCatalog.MODULES) {
                if (cfg.enabled(module.id()) && !module.id().endsWith("_hud")) active.add(module.name());
            }
            int ay = 7;
            for (String name : active) {
                int textWidth = client.textRenderer.getWidth(name);
                int ax = client.getWindow().getScaledWidth() - textWidth - 12;
                context.fill(ax - 4, ay - 2, ax + textWidth + 6, ay + 10, 0xA8080D18);
                context.fill(ax + textWidth + 3, ay - 2, ax + textWidth + 6, ay + 10, 0xFF9C69FF);
                context.drawTextWithShadow(client.textRenderer, name, ax, ay, 0xFFF0E8FF);
                ay += 12;
            }
        }
    }

    private static void draw(DrawContext context, String value, int x, int y) {
        draw(context, value, x, y, 0xFFE5F4FF);
    }

    private static void draw(DrawContext context, String value, int x, int y, int color) {
        MinecraftClient client = MinecraftClient.getInstance();
        context.fill(x - 3, y - 2, x + client.textRenderer.getWidth(value) + 5, y + 10, 0x99060B16);
        context.drawTextWithShadow(client.textRenderer, Text.literal(value), x, y, color);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y) {
        drawKey(context, label, pressed, x, y, 20);
    }

    private static void drawKey(DrawContext context, String label, boolean pressed, int x, int y, int width) {
        int bg = pressed ? 0xFF26769B : 0xD90B1422;
        context.fill(x, y, x + width, y + 19, bg);
        context.fill(x, y, x + width, y + 1, pressed ? 0xFF6DE0FF : 0xFF526780);
        context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, label,
                x + width / 2, y + 5, 0xFFF4FAFF);
    }
}
