package com.damnson.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.*;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


/** Runtime for the six requested modules only. */
public final class UtilityModules {
    private static Object lastPlayerReference;

    // Existing Aim Assist state. Acquisition stays on the tick; smoothing runs once per rendered frame.
    private static LivingEntity aimTarget;
    private static boolean aimBotWasEnabled;
    private static long aimAcquireNextTick;
    private static long lastAimFrameNanos;

    // Existing Trigger Bot state.
    private static LivingEntity triggerTarget;
    private static long triggerFirstSeen;
    private static long triggerDelay = 5;

    // Auto Potion state.
    private static long lastAutoPotionTick;
    private static int pendingPotionSlot = -1;
    private static int pendingPotionOldSlot = -1;
    private static int pendingPotionSourceSlot = -1;
    private static float pendingPotionOldPitch;
    private static PotionContentsComponent pendingAutoPotionContents;
    private static long pendingPotionUseTick = -1L;
    private static int pendingPotionRestoreSource = -1;
    private static int pendingPotionRestoreHotbar = -1;

    // Refill trackers avoid ItemStack.copy() allocations on every tick.
    private static final boolean[] previousHotbarWasSplashPotion = new boolean[9];
    private static final PotionContentsComponent[] previousHotbarPotionContents = new PotionContentsComponent[9];
    private static final long[] pendingPotionRefillAt = new long[9];
    private static final PotionContentsComponent[] pendingPotionContents = new PotionContentsComponent[9];

    private UtilityModules() {}

    public static void tick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) {
            lastAimFrameNanos = 0L;
            return;
        }
        ModuleSettings cfg = ModuleSettings.get();
        if (lastPlayerReference != client.player) {
            lastPlayerReference = client.player;
            aimTarget = null;
            aimBotWasEnabled = false;
            aimAcquireNextTick = 0L;
            lastAimFrameNanos = 0L;
            triggerTarget = null;
            triggerFirstSeen = 0L;
            lastAutoPotionTick = 0L;
            pendingPotionSlot = -1;
            pendingPotionOldSlot = -1;
            pendingPotionSourceSlot = -1;
            pendingPotionUseTick = -1L;
            pendingAutoPotionContents = null;
            pendingPotionRestoreSource = -1;
            pendingPotionRestoreHotbar = -1;
            for (int i = 0; i < 9; i++) {
                pendingPotionRefillAt[i] = 0L;
                pendingPotionContents[i] = null;
                ItemStack stack = client.player.getInventory().getStack(i);
                boolean splash = stack.getItem() instanceof SplashPotionItem;
                previousHotbarWasSplashPotion[i] = splash;
                previousHotbarPotionContents[i] = splash ? stack.get(DataComponentTypes.POTION_CONTENTS) : null;
            }
        }

        finishPendingAutoPotion(client, cfg);
        if (client.currentScreen != null) {
            lastAimFrameNanos = 0L;
            triggerTarget = null;
            triggerFirstSeen = 0L;
            return;
        }

        tickPotionRefill(client, cfg);
        updateAimBotTarget(client, cfg);
        tickTriggerBot(client, cfg);
        tickAutoPotion(client, cfg);
    }

    /** Aim correction runs before the camera frame and never searches entities here. */

    private static void updateAimBotTarget(MinecraftClient client, ModuleSettings cfg) {
        boolean enabled = cfg.enabled("aim_bot");
        if (!enabled) {
            if (aimBotWasEnabled) aimTarget = null;
            aimBotWasEnabled = false;
            lastAimFrameNanos = 0L;
            aimAcquireNextTick = 0L;
            return;
        }
        if (!aimBotWasEnabled) { aimTarget = null; aimAcquireNextTick = 0L; }
        aimBotWasEnabled = true;
    
        if (cfg.aimBotWeaponsOnly && !isCombatWeapon(client.player.getMainHandStack())) {
            aimTarget = null;
            return;
        }
    
        double range = Math.max(2.0, cfg.aimBotRange);
        float fov = MathHelper.clamp((float) cfg.aimBotFov, 10.0f, 360.0f);
        boolean fullCircle = fov >= 359.9f;
    
        // Keep a lock while the target remains valid. A small range/FOV hysteresis
        // avoids one-tick unlock/relock loops when a moving target crosses a boundary.
        if (aimTarget != null) {
            boolean invalid = !aimTarget.isAlive() || aimTarget.isRemoved()
                    || client.world.getEntityById(aimTarget.getId()) == null;
            if (!invalid) {
                Vec3d point = getAimPoint(aimTarget, 1.0f, cfg.aimBotTargetPoint);
                Vec3d delta = point.subtract(client.player.getEyePos());
                float targetYaw = yawTo(delta);
                float targetPitch = pitchTo(delta);
                double keepRange = range + 0.65;
                float halfFov = fov * 0.5f;
                invalid = delta.lengthSquared() > keepRange * keepRange;
                if (!invalid && !fullCircle) {
                    invalid = Math.abs(MathHelper.wrapDegrees(targetYaw - client.player.getYaw())) > halfFov + 7.0f
                            || Math.abs(targetPitch - client.player.getPitch()) > halfFov + 7.0f;
                }
            }
            if (invalid) aimTarget = null;
        }
    
        if (aimTarget == null && client.world.getTime() >= aimAcquireNextTick) {
            aimTarget = findAimCandidate(client, cfg, range, fov, fullCircle);
            // When no entity is in range, do not allocate/filter/sort the entire
            // candidate list on every single client tick.
            aimAcquireNextTick = client.world.getTime() + 3L;
        }
    }

    public static void onRenderFrame() {
        MinecraftClient client = MinecraftClient.getInstance();
        ModuleSettings cfg = ModuleSettings.get();
        if (client == null || client.player == null || client.world == null
                || client.currentScreen != null || !cfg.enabled("aim_bot") || aimTarget == null
                || !aimTarget.isAlive() || aimTarget.isRemoved()
                || (cfg.aimBotWeaponsOnly && !isCombatWeapon(client.player.getMainHandStack()))) {
            lastAimFrameNanos = 0L;
            return;
        }
    
        long now = System.nanoTime();
        if (lastAimFrameNanos == 0L) {
            lastAimFrameNanos = now;
            return;
        }
        double deltaSeconds = Math.max(0.0, Math.min(0.05, (now - lastAimFrameNanos) / 1_000_000_000.0));
        lastAimFrameNanos = now;
        if (deltaSeconds <= 0.0) return;
    
        float tickDelta = client.getRenderTickCounter().getTickDelta(true);
        Vec3d delta = getAimPoint(aimTarget, tickDelta, cfg.aimBotTargetPoint)
                .subtract(client.player.getCameraPosVec(tickDelta));
        float targetYaw = yawTo(delta);
        float targetPitch = pitchTo(delta);
        float yawDelta = MathHelper.wrapDegrees(targetYaw - client.player.getYaw());
        float pitchDelta = targetPitch - client.player.getPitch();
    
        float strength = MathHelper.clamp((float) cfg.aimBotSmooth, 1.0f, 100.0f);
        double response = 2.0 + strength * 0.24;
        float factor = (float) (1.0 - Math.exp(-response * deltaSeconds));
        client.player.setYaw(client.player.getYaw() + yawDelta * factor);
        client.player.setPitch(MathHelper.clamp(
                client.player.getPitch() + pitchDelta * factor, -90.0f, 90.0f));
    }

    private static boolean isCombatWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        Item item = stack.getItem();
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof BowItem
                || item instanceof CrossbowItem || item instanceof TridentItem || item == Items.MACE;
    }

    private static LivingEntity findAimCandidate(MinecraftClient client, ModuleSettings cfg,
                                                  double range, float fov, boolean fullCircle) {
        double rangeSquared = range * range;
        LivingEntity best = null;
        double bestAngleError = Double.POSITIVE_INFINITY;
        double bestDistanceSquared = Double.POSITIVE_INFINITY;
        Vec3d eyePos = client.player.getEyePos();
        float halfFov = fov * 0.5f;
    
        // One-pass selection avoids allocating and sorting a temporary candidate list.
        for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                e -> e != client.player && e.isAlive() && !e.isRemoved() && !e.isSpectator())) {
            Vec3d delta = getAimPoint(entity, 1.0f, cfg.aimBotTargetPoint).subtract(eyePos);
            double distanceSquared = delta.lengthSquared();
            if (distanceSquared > rangeSquared || distanceSquared < 1.0e-6) continue;
            if (!fullCircle) {
                float dyaw = Math.abs(MathHelper.wrapDegrees(yawTo(delta) - client.player.getYaw()));
                float dpitch = Math.abs(pitchTo(delta) - client.player.getPitch());
                if (dyaw > halfFov || dpitch > halfFov) continue;
            }
            double angleError = angularErrorSquared(client, delta);
            if (angleError < bestAngleError
                    || (Double.compare(angleError, bestAngleError) == 0 && distanceSquared < bestDistanceSquared)) {
                best = entity;
                bestAngleError = angleError;
                bestDistanceSquared = distanceSquared;
            }
        }
        return best;
    }

    private static Vec3d getAimPoint(LivingEntity entity, float tickDelta, int targetPoint) {
        Vec3d interpolated = entity.getLerpedPos(MathHelper.clamp(tickDelta, 0.0f, 1.0f));
        double heightFraction = switch (Math.max(0, Math.min(2, targetPoint))) {
            case 0 -> 0.90; // head / eye line
            case 1 -> 0.68; // upper chest
            default -> 0.52; // center mass
        };
        return interpolated.add(0.0, entity.getHeight() * heightFraction, 0.0);
    }

    private static float yawTo(Vec3d delta) {
        return (float) (Math.atan2(delta.z, delta.x) * (180.0 / Math.PI)) - 90.0f;
    }

    private static float pitchTo(Vec3d delta) {
        return (float) -(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))
                * (180.0 / Math.PI));
    }

    private static double angularErrorSquared(MinecraftClient client, Vec3d delta) {
        double yaw = MathHelper.wrapDegrees(yawTo(delta) - client.player.getYaw());
        double pitch = pitchTo(delta) - client.player.getPitch();
        return yaw * yaw + pitch * pitch;
    }

    private static void tickTriggerBot(MinecraftClient client, ModuleSettings cfg) {
        if (!cfg.enabled("trigger_bot") || client.interactionManager == null) {
            triggerTarget = null;
            triggerFirstSeen = 0;
            return;
        }
        if (client.player.isUsingItem()) {
            triggerTarget = null;
            triggerFirstSeen = 0;
            return;
        }
    
        LivingEntity target = null;
        if (client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity le
                && le.isAlive() && !le.isRemoved() && !le.isSpectator()
                && le.isAttackable()) {
            double range = cfg.triggerBotRange;
            if (client.player.getEyePos().squaredDistanceTo(le.getEyePos()) <= range * range) {
                target = le;
            }
        }
    
        long now = client.world.getTime();
        if (target != triggerTarget) {
            triggerTarget = target;
            triggerFirstSeen = now;
            triggerDelay = Math.max(0L, Math.min(10L, Math.round(cfg.triggerBotDelayTicks)));
        }
    
        if (target == null) return;
        if (now - triggerFirstSeen < triggerDelay) return;
    
        // Let vanilla attack cooldown control repeat timing. The old extra 8–12 tick
        // interval plus a new delay after every hit made follow-up attacks sluggish.
        if (client.player.getAttackCooldownProgress(0.5f) < 0.90f) return;
    
        client.interactionManager.attackEntity(client.player, target);
        client.player.swingHand(Hand.MAIN_HAND);
    }

    private static void tickAutoPotion(MinecraftClient client, ModuleSettings cfg) {
        if (pendingPotionSlot >= 0 || !cfg.enabled("auto_potion") || client.interactionManager == null
                || client.player.isUsingItem() || client.player.isCreative()
                || client.player.getHealth() > cfg.autoPotionThreshold || client.currentScreen != null) return;
        long now = client.world.getTime();
        if (now - lastAutoPotionTick < Math.max(5L, Math.round(cfg.autoPotionCooldownTicks))) return;
    
        var inventory = client.player.getInventory();
        int potionSlot = findHealingPotionInHotbar(inventory, true);
        int sourceSlot = -1;
        if (potionSlot < 0) {
            sourceSlot = findHealingPotionInMainInventory(inventory, true);
            if (sourceSlot < 0) return;
            potionSlot = inventory.selectedSlot;
            // In PlayerScreenHandler, SWAP button=n swaps a main-inventory source
            // with hotbar index n. Stage now and use on the next tick.
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    sourceSlot, potionSlot, SlotActionType.SWAP, client.player);
            ItemStack borrowed = inventory.getStack(potionSlot);
            if (!hasPotionEffect(borrowed, StatusEffects.INSTANT_HEALTH)
                    && !hasPotionEffect(borrowed, StatusEffects.REGENERATION)) {
                client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                        sourceSlot, potionSlot, SlotActionType.SWAP, client.player);
                return;
            }
        }
    
        ItemStack potionStack = inventory.getStack(potionSlot);
        pendingAutoPotionContents = potionStack.get(DataComponentTypes.POTION_CONTENTS);
        pendingPotionSlot = potionSlot;
        pendingPotionOldSlot = inventory.selectedSlot;
        pendingPotionOldPitch = client.player.getPitch();
        pendingPotionSourceSlot = sourceSlot;
        pendingPotionUseTick = now + 1L;
        inventory.selectedSlot = potionSlot;
        client.player.setPitch(90.0f);
    }

    private static void finishPendingAutoPotion(MinecraftClient client, ModuleSettings cfg) {
        if (pendingPotionSlot >= 0 && client.world.getTime() >= pendingPotionUseTick) {
            var inventory = client.player.getInventory();
            int slot = pendingPotionSlot;
            int oldSlot = pendingPotionOldSlot;
            int sourceSlot = pendingPotionSourceSlot;
            PotionContentsComponent usedContents = pendingAutoPotionContents;
            try {
                // The prior tick's movement update has had a chance to report the
                // temporary pitch and slot. Send use now, then restore local state.
                inventory.selectedSlot = slot;
                if (client.interactionManager != null) {
                    client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                    lastAutoPotionTick = client.world.getTime();
                }
            } finally {
                client.player.setPitch(pendingPotionOldPitch);
                inventory.selectedSlot = oldSlot;
                if (sourceSlot >= 0) {
                    // If a container screen is open, restore only once back in the
                    // player's inventory handler so slot indices can't target a chest.
                    pendingPotionRestoreSource = sourceSlot;
                    pendingPotionRestoreHotbar = slot;
                } else if (cfg.enabled("potion_refill") && usedContents != null) {
                    pendingPotionContents[slot] = usedContents;
                    pendingPotionRefillAt[slot] = client.world.getTime();
                }
                pendingPotionSlot = -1;
                pendingPotionOldSlot = -1;
                pendingPotionSourceSlot = -1;
                pendingPotionUseTick = -1L;
                pendingAutoPotionContents = null;
            }
        }
        if (pendingPotionRestoreSource >= 0 && client.currentScreen == null
                && client.interactionManager != null && client.player.currentScreenHandler == client.player.playerScreenHandler) {
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                    pendingPotionRestoreSource, pendingPotionRestoreHotbar, SlotActionType.SWAP, client.player);
            pendingPotionRestoreSource = -1;
            pendingPotionRestoreHotbar = -1;
        }
    }

    private static int findHealingPotionInHotbar(net.minecraft.entity.player.PlayerInventory inventory,
                                                  boolean allowRegeneration) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (hasPotionEffect(stack, StatusEffects.INSTANT_HEALTH)) return i;
        }
        if (allowRegeneration) {
            for (int i = 0; i < 9; i++) {
                if (hasPotionEffect(inventory.getStack(i), StatusEffects.REGENERATION)) return i;
            }
        }
        return -1;
    }

    private static int findHealingPotionInMainInventory(net.minecraft.entity.player.PlayerInventory inventory,
                                                         boolean allowRegeneration) {
        for (int i = 9; i < 36; i++) {
            if (hasPotionEffect(inventory.getStack(i), StatusEffects.INSTANT_HEALTH)) return i;
        }
        if (allowRegeneration) {
            for (int i = 9; i < 36; i++) {
                if (hasPotionEffect(inventory.getStack(i), StatusEffects.REGENERATION)) return i;
            }
        }
        return -1;
    }

    private static boolean hasPotionEffect(ItemStack stack,
            net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effectType) {
        if (!(stack.getItem() instanceof SplashPotionItem)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (StatusEffectInstance effect : contents.getEffects()) {
            if (effect.getEffectType().equals(effectType)) return true;
        }
        return false;
    }

    /** Refill an emptied hotbar splash-potion slot with the same potion from slots 9–35. */
    private static void tickPotionRefill(MinecraftClient client, ModuleSettings cfg) {
        if (client.interactionManager == null || client.player == null) return;
        var inventory = client.player.getInventory();
        long now = client.world.getTime();
        boolean enabled = cfg.enabled("potion_refill");

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack current = inventory.getStack(hotbar);
            if (enabled && previousHotbarWasSplashPotion[hotbar] && current.isEmpty()
                    && pendingPotionContents[hotbar] == null) {
                PotionContentsComponent contents = previousHotbarPotionContents[hotbar];
                if (contents != null) {
                    pendingPotionContents[hotbar] = contents;
                    pendingPotionRefillAt[hotbar] = now;
                }
            }

            if (enabled) {
                PotionContentsComponent wanted = pendingPotionContents[hotbar];
                if (wanted != null && now - pendingPotionRefillAt[hotbar] >= 1L && current.isEmpty()) {
                    int source = -1;
                    for (int invSlot = 9; invSlot < 36; invSlot++) {
                        ItemStack candidate = inventory.getStack(invSlot);
                        if (candidate.getItem() instanceof SplashPotionItem
                                && wanted.equals(candidate.get(DataComponentTypes.POTION_CONTENTS))) {
                            source = invSlot;
                            break;
                        }
                    }
                    if (source >= 0) {
                        client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId,
                                source, hotbar, SlotActionType.SWAP, client.player);
                        pendingPotionContents[hotbar] = null;
                        pendingPotionRefillAt[hotbar] = 0L;
                    } else if (now - pendingPotionRefillAt[hotbar] > 60L) {
                        pendingPotionContents[hotbar] = null;
                        pendingPotionRefillAt[hotbar] = 0L;
                    }
                }
            } else {
                pendingPotionContents[hotbar] = null;
                pendingPotionRefillAt[hotbar] = 0L;
            }
        }

        // Keep the snapshot current even when disabled, so enabling the module can't refill an older slot.
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            boolean splash = stack.getItem() instanceof SplashPotionItem;
            previousHotbarWasSplashPotion[i] = splash;
            previousHotbarPotionContents[i] = splash ? stack.get(DataComponentTypes.POTION_CONTENTS) : null;
        }
    }
}
