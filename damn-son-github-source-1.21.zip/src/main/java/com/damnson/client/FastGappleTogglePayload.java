package com.damnson.client;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record FastGappleTogglePayload(boolean enabled) implements CustomPayload {
    public static final Id<FastGappleTogglePayload> ID = new Id<>(Identifier.of("damnson", "fast_gapple_toggle"));
    public static final PacketCodec<RegistryByteBuf, FastGappleTogglePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.BOOL, FastGappleTogglePayload::enabled, FastGappleTogglePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
