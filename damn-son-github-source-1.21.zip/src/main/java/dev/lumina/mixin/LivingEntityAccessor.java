package dev.lumina.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {
    @Accessor("jumpingCooldown")
    void lumina$setJumpingCooldown(int value);

    // itemUseTimeLeft is the Yarn 1.21+build.9 name for the remaining-use-ticks field.
    // If the build fails here with "no field itemUseTimeLeft", check the Yarn mappings
    // for LivingEntity and update the string to the correct name.
    @Accessor("itemUseTimeLeft")
    int lumina$getItemUseTimeLeft();

    @Accessor("itemUseTimeLeft")
    void lumina$setItemUseTimeLeft(int value);
}
