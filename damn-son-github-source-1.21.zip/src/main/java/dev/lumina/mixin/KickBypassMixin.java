package dev.lumina.mixin;

import dev.lumina.LuminaClient;
import dev.lumina.module.util.Bypass;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts server-sent disconnect / kick packets.
 *
 * When Bypass is enabled and "Block Kick" is on, the mixin swallows the
 * DisconnectS2CPacket entirely — the client never sees the kick screen and
 * keeps its session alive. This covers:
 *   - Anti-cheat kicks (Grim, Vulcan, Matrix silent disconnect)
 *   - Server-side kick commands (/kick)
 *   - Timeout kicks (the packet form, not network-level drops)
 *
 * What it CANNOT block:
 *   - A TCP-level connection drop (server closes the socket — nothing to intercept)
 *   - LoginDisconnect (this mixin only covers the play phase)
 *
 * How it works:
 *   ClientPlayNetworkHandler.onDisconnect() is the single choke-point for all
 *   play-phase disconnect packets. Injecting at HEAD and cancelling the CI
 *   prevents the method body from running — no kick screen, no world unload.
 *
 *   The server still thinks it kicked you. Your client silently drops the
 *   packet and keeps ticking. From the server's view you disconnected; from
 *   yours you're still in the world (until the socket actually drops).
 *
 *   Practical result: on most anti-cheats a flag fires → server sends
 *   DisconnectS2CPacket → we eat it → you stay in the game. The flag resets
 *   on their side because as far as the server knows, you left.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class KickBypassMixin {

    @Inject(method = "onDisconnect", at = @At("HEAD"), cancellable = true)
    private void lumina$blockKick(DisconnectS2CPacket packet, CallbackInfo ci) {
        if (LuminaClient.modules == null) return;
        Bypass bypass = LuminaClient.modules.bypass;
        if (!bypass.isEnabled() || !bypass.isBlockKickEnabled()) return;

        // Log the swallowed reason so you know what got intercepted
        LuminaClient.LOGGER.info(
            "[Bypass] Swallowed kick: {}",
            packet.reason().getString()
        );

        ci.cancel(); // ← packet dies here; client stays connected
    }
}
