package dev.lumina.mixin;

import dev.lumina.LuminaClient;
import dev.lumina.module.util.Bypass;
import net.minecraft.client.ClientBrandRetriever;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hooks into ClientBrandRetriever.getClientModName().
 * Vanilla returns "vanilla"; Fabric overrides it to "fabric".
 * We override it back to "vanilla" when Bypass + SpoofBrand is on,
 * so the server receives "vanilla" as the client brand.
 */
@Mixin(value = ClientBrandRetriever.class, priority = 2000)
public class BypassBrandMixin {

    @Inject(method = "getClientModName", at = @At("HEAD"), cancellable = true)
    private static void spoofBrand(CallbackInfoReturnable<String> cir) {
        if (LuminaClient.modules == null) return;
        Bypass bp = LuminaClient.modules.bypass;
        if (bp != null && bp.enabled && bp.spoofBrand.value) {
            cir.setReturnValue("vanilla");
        }
    }
}
