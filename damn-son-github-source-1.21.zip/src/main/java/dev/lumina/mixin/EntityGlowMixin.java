package dev.lumina.mixin;

import dev.lumina.module.render.GlowEsp;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Makes the render pipeline see ESP-selected entities as glowing without mutating server entity flags. */
@Mixin(Entity.class)
public abstract class EntityGlowMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void lumina$forceGlow(CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof LivingEntity living)) return;
        GlowEsp esp = GlowEsp.INSTANCE;
        if (esp != null && esp.shouldHighlight(living)) cir.setReturnValue(true);
    }
}
