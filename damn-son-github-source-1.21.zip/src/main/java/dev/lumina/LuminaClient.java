package dev.lumina;

import dev.lumina.gui.ClickGui;
import dev.lumina.hud.Hud;
import dev.lumina.module.Mod;
import dev.lumina.module.combat.AimAssist;
import dev.lumina.module.ModuleManager;
import dev.lumina.render.Render2D;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LuminaClient implements ClientModInitializer {
    public static final String ID = "lumina";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    public static ModuleManager modules;
    public static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load(modules);

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumina.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.lumina"));

        CoreShaderRegistrationCallback.EVENT.register(ctx ->
                ctx.register(Identifier.of(ID, "rounded"), VertexFormats.POSITION_COLOR, p -> Render2D.program = p));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.save(modules));

        LOGGER.info("Lumina loaded");
    }

    private void tick(MinecraftClient mc) {
        while (guiKey.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
        }
        if (mc.player == null || mc.world == null) {
            // Clear transient camera ownership when disconnecting/loading a world. Otherwise a
            // combat sequence interrupted by a disconnect could leave aim/attack modules locked.
            AimAssist.clearRotationLocks();
            if (modules != null) modules.autoPot.onWorldLost();
            return;
        }

        long window = mc.getWindow().getHandle();
        for (Mod m : modules.all) {
            if (m.key > 0) {
                boolean down = InputUtil.isKeyPressed(window, m.key);
                if (down && !m.keyDown && mc.currentScreen == null && m.toggleable) m.toggle();
                m.keyDown = down;
            }
            if (m.enabled) {
                try {
                    m.onTick();
                } catch (Throwable t) {
                    LOGGER.error("Module {} crashed in tick, disabling", m.name, t);
                    // Run onDisable() cleanup so slot restores and camera locks are not stranded.
                    m.setEnabled(false);
                }
            }
        }
    }
}
