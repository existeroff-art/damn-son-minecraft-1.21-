package dev.lumina.gui;

import dev.lumina.Config;
import dev.lumina.LuminaClient;
import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.render.Render2D;
import dev.lumina.render.Theme;
import dev.lumina.setting.Setting;
import dev.lumina.util.Anim;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClickGui extends Screen {
    private static final int WHITE = 0xFFF4F4F8;
    private static final int GRAY = 0xFF9A9AA8;
    private static final int DIM = 0xFF6B6B78;

    private interface Click { void on(double x, double y, int button); }

    private static final class Region {
        float x, y, w, h;
        Click click, drag;
        boolean hit(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private final List<Region> regions = new ArrayList<>();
    private final Map<String, Float> hovers = new HashMap<>();
    private Region dragging;

    private Category category = Category.COMBAT;
    private Mod selected;
    private String search = "";
    private boolean searchFocus;
    private Mod bindTarget;

    private float open, ease, ga, dt;
    private float scrollList, scrollListT, listMax;
    private float scrollSet, scrollSetT, setMax;
    private final float[] listB = new float[4];
    private final float[] setB = new float[4];
    private int mx, my;
    private long last = System.nanoTime();

    public ClickGui() {
        super(Text.literal("Lumina"));
        List<Mod> l = LuminaClient.modules.in(category);
        if (!l.isEmpty()) selected = l.get(0);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        Config.save(LuminaClient.modules);
        super.close();
    }

    // ------------------------------------------------------------------ helpers

    private int c(int argb) { return Render2D.mulAlpha(argb, ga); }

    private int al(int rgb, int a) { return Render2D.alpha(rgb, a); }

    private void fill(DrawContext ctx, float x, float y, float w, float h, float r, int col) {
        Render2D.fill(ctx, x, y, w, h, r, c(col));
    }

    private boolean inside(float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private float hv(String key, boolean on) {
        float v = hovers.getOrDefault(key, 0f);
        v = Anim.approach(v, on ? 1f : 0f, 14f, dt);
        hovers.put(key, v);
        return v;
    }

    private void region(float x, float y, float w, float h, float clipT, float clipB, Click click, Click drag) {
        if (y + h <= clipT || y >= clipB) return;
        Region r = new Region();
        r.x = x;
        r.y = Math.max(y, clipT);
        r.h = Math.min(y + h, clipB) - r.y;
        r.w = w;
        r.click = click;
        r.drag = drag;
        regions.add(r);
    }

    private static String keyName(int k) {
        if (k <= 0) return "None";
        try {
            return InputUtil.fromKeyCode(k, 0).getLocalizedText().getString();
        } catch (Exception e) {
            return "Key " + k;
        }
    }

    private List<Mod> visibleMods() {
        if (search.isEmpty()) return LuminaClient.modules.in(category);
        List<Mod> out = new ArrayList<>();
        for (Mod m : LuminaClient.modules.all) {
            if (m.name.toLowerCase().contains(search.toLowerCase())) out.add(m);
        }
        return out;
    }

    private void select(Mod m) {
        selected = m;
        scrollSet = scrollSetT = 0;
        bindTarget = null;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta); // vanilla gaussian blur of the world
        ctx.fillGradient(0, 0, width, height,
                Render2D.mulAlpha(Render2D.alpha(Theme.a1(), 52), ga),
                Render2D.mulAlpha(0xB0000000, ga));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        mx = mouseX;
        my = mouseY;
        open = Anim.approach(open, 1f, 7f, dt);
        ease = Anim.easeOut(open);
        ga = ease;
        regions.clear();

        for (Mod m : LuminaClient.modules.all) m.guiAnim = Anim.approach(m.guiAnim, m.enabled ? 1f : 0f, 14f, dt);

        renderBackground(ctx, mouseX, mouseY, delta);

        float pw = Math.min(600, width - 24), ph = Math.min(360, height - 24);
        float px = (width - pw) / 2f, py = (height - ph) / 2f + (1f - ease) * 20f;
        float panelA = (float) LuminaClient.modules.theme.opacity.value;

        // shadow, glass body, accent glow, border
        Render2D.glow(ctx, px, py + 10, pw, ph, 22, c(0xA0000000), 24f);
        Render2D.vgrad(ctx, px, py, pw, ph, 20,
                Render2D.mulAlpha(0xFF111117, panelA * ga), Render2D.mulAlpha(0xFF16161D, panelA * ga));
        Render2D.glow(ctx, px + pw * 0.25f, py - 1, pw * 0.5f, 4, 2, c(al(Theme.a1(), 80)), 14f);
        Render2D.outline(ctx, px, py, pw, ph, 20, c(0x24FFFFFF), 1f);

        float sx = px + 10, sy = py + 10, sw = 116, sh = ph - 20;
        renderSidebar(ctx, sx, sy, sw, sh);

        float mx0 = sx + sw + 10;
        float mw = px + pw - 10 - mx0;
        float hh = 30;
        renderHeader(ctx, mx0, sy, mw, hh);

        float cy = sy + hh + 10;
        float chh = py + ph - 10 - cy;
        float lw = Math.min(150, mw * 0.42f);
        renderList(ctx, mx0, cy, lw, chh);
        renderSettings(ctx, mx0 + lw + 10, cy, mw - lw - 10, chh);

        ctx.draw();
    }

    private void renderSidebar(DrawContext ctx, float sx, float sy, float sw, float sh) {
        fill(ctx, sx, sy, sw, sh, 14, 0x10FFFFFF);

        // profile card
        float cx = sx + 6, cy = sy + 6, cw = sw - 12, ch = 44;
        fill(ctx, cx, cy, cw, ch, 11, 0x12FFFFFF);
        Render2D.rect(ctx, cx, cy, cw, ch, 11, c(al(Theme.a1(), 46)), c(al(Theme.a2(), 8)),
                c(al(Theme.a2(), 8)), c(al(Theme.a1(), 46)), 0f, 0f);
        Render2D.rect(ctx, cx + 7, cy + 7, 30, 30, 15, c(Theme.a1()), c(Theme.a2()), c(Theme.a2()), c(Theme.a1()), 0f, 0f);
        String user = mc().getSession().getUsername();
        Render2D.textCentered(ctx, user.isEmpty() ? "?" : user.substring(0, 1).toUpperCase(), cx + 22, cy + 18, c(0xFFFFFFFF), 1.3f);
        Render2D.circle(ctx, cx + 34, cy + 34, 5.2f, c(0xFF15151B));
        Render2D.circle(ctx, cx + 34, cy + 34, 3.6f, c(0xFF3DDC84));
        Render2D.text(ctx, Render2D.fit(user, 0.95f, cw - 48), cx + 43, cy + 11, c(WHITE), 0.95f);
        long active = LuminaClient.modules.all.stream().filter(m -> m.enabled && !m.hudHidden).count();
        Render2D.text(ctx, active + " active", cx + 43, cy + 25, c(GRAY), 0.75f);

        float y = cy + ch + 12;
        y = sectionLabel(ctx, "Main", sx, sw, y);
        for (Category cat : Category.values()) if (cat.main) y = categoryRow(ctx, cat, sx, sw, y);
        y += 6;
        y = sectionLabel(ctx, "Other", sx, sw, y);
        for (Category cat : Category.values()) if (!cat.main) y = categoryRow(ctx, cat, sx, sw, y);

        // save button
        float bx = sx + 8, bw = sw - 16, bh = 26, by = sy + sh - bh - 8;
        float h = hv("save", inside(bx, by, bw, bh));
        Render2D.glow(ctx, bx, by, bw, bh, 13, c(al(Theme.a1(), (int) (60 * h))), 8f);
        Render2D.rect(ctx, bx, by, bw, bh, 13, c(al(Theme.a1(), 110 + (int) (60 * h))), c(al(Theme.a2(), 110 + (int) (60 * h))),
                c(al(Theme.a2(), 110 + (int) (60 * h))), c(al(Theme.a1(), 110 + (int) (60 * h))), 0f, 0f);
        Render2D.textCentered(ctx, "Save Config", bx + bw / 2, by + 9, c(WHITE), 0.9f);
        region(bx, by, bw, bh, 0, 99999, (x, yy, b) -> Config.save(LuminaClient.modules), null);
    }

    private float sectionLabel(DrawContext ctx, String s, float sx, float sw, float y) {
        float tw = Render2D.width(s, 0.78f);
        float cx = sx + sw / 2f;
        Render2D.textCentered(ctx, s, cx, y, c(DIM), 0.78f);
        fill(ctx, sx + 12, y + 3.5f, cx - tw / 2 - 6 - (sx + 12), 1, 0.5f, 0x18FFFFFF);
        fill(ctx, cx + tw / 2 + 6, y + 3.5f, sx + sw - 12 - (cx + tw / 2 + 6), 1, 0.5f, 0x18FFFFFF);
        return y + 14;
    }

    private float categoryRow(DrawContext ctx, Category cat, float sx, float sw, float y) {
        float x = sx + 8, w = sw - 16, h = 24;
        boolean active = cat == category && search.isEmpty();
        float hov = hv("cat" + cat.name(), inside(x, y, w, h));
        if (active) {
            fill(ctx, x, y, w, h, 10, al(Theme.a1(), 40));
        } else {
            fill(ctx, x, y, w, h, 10, al(0xFFFFFF, (int) (22 * hov)));
        }
        Render2D.circle(ctx, x + 11, y + h / 2, active ? 2.6f : 1.8f, c(active ? Theme.a1() : DIM));
        Render2D.text(ctx, cat.label, x + 22, y + 8, c(active ? WHITE : Render2D.lerp(GRAY, WHITE, hov)), 0.95f);
        region(x, y, w, h, 0, 99999, (xx, yy, b) -> {
            category = cat;
            search = "";
            searchFocus = false;
            scrollList = scrollListT = 0;
            List<Mod> l = LuminaClient.modules.in(cat);
            if (!l.isEmpty()) select(l.get(0));
        }, null);
        return y + h + 3;
    }

    private void renderHeader(DrawContext ctx, float x, float y, float w, float h) {
        fill(ctx, x, y, w, h, 12, 0x12FFFFFF);
        Render2D.text(ctx, search.isEmpty() ? category.label : "Results", x + 14, y + 11, c(GRAY), 1f);

        float sbw = Math.min(130, w * 0.5f), sbx = x + w - sbw - 6, sby = y + 5, sbh = h - 10;
        fill(ctx, sbx, sby, sbw, sbh, 9, 0x70000000);
        Render2D.outline(ctx, sbx, sby, sbw, sbh, 9, c(searchFocus ? al(Theme.a1(), 210) : 0x22FFFFFF), 1f);
        String shown;
        int col;
        if (search.isEmpty() && !searchFocus) {
            shown = "Search Modules...";
            col = DIM;
        } else {
            shown = search + ((System.currentTimeMillis() / 500) % 2 == 0 && searchFocus ? "_" : "");
            col = WHITE;
        }
        Render2D.text(ctx, Render2D.fit(shown, 0.82f, sbw - 34), sbx + 10, sby + 6.2f, c(col), 0.82f);
        Render2D.outline(ctx, sbx + sbw - 19, sby + (sbh - 8) / 2 - 0.5f, 8, 8, 4, c(GRAY), 1.2f);
        region(sbx, sby, sbw, sbh, 0, 99999, (xx, yy, b) -> searchFocus = true, null);
    }

    private void renderList(DrawContext ctx, float x, float y, float w, float h) {
        List<Mod> mods = visibleMods();
        float rowH = 28, gap = 4;
        listB[0] = x; listB[1] = y; listB[2] = w; listB[3] = h;
        listMax = Math.max(0, mods.size() * (rowH + gap) - gap - h);
        scrollListT = Anim.clamp(scrollListT, 0, listMax);
        scrollList = Anim.approach(scrollList, scrollListT, 16f, dt);

        ctx.enableScissor((int) x, (int) y, (int) (x + w), (int) (y + h));
        for (int i = 0; i < mods.size(); i++) {
            Mod m = mods.get(i);
            float ry = y + i * (rowH + gap) - scrollList;
            if (ry + rowH < y || ry > y + h) continue;
            boolean hov = inside(x, ry, w, rowH) && my >= y && my <= y + h;
            float hh = hv("row" + m.name, hov);
            boolean sel = m == selected;

            fill(ctx, x + 1, ry, w - 2, rowH, 10, sel ? al(Theme.a1(), 36) : Render2D.lerp(0x0DFFFFFF, 0x1CFFFFFF, hh));
            if (sel) Render2D.outline(ctx, x + 1, ry, w - 2, rowH, 10, c(al(Theme.a1(), 150)), 1f);
            Render2D.text(ctx, m.name, x + 12, ry + 9.5f, c(m.enabled ? WHITE : Render2D.lerp(GRAY, WHITE, hh)), 0.95f);

            final Mod mm = m;
            region(x + 1, ry, w - 2, rowH, y, y + h, (xx, yy, b) -> {
                if (b == 0) select(mm);
                else if (b == 1 && mm.toggleable) mm.toggle();
            }, null);

            if (m.toggleable) {
                float swx = x + w - 12 - 24, swy = ry + (rowH - 13) / 2;
                drawSwitch(ctx, swx, swy, m.guiAnim);
                region(swx - 3, swy - 3, 30, 19, y, y + h, (xx, yy, b) -> { if (b <= 1) mm.toggle(); }, null);
            }
        }
        ctx.disableScissor();
        drawScrollbar(ctx, x, y, w, h, scrollList, listMax);
    }


    /** Draws a thin scrollbar track + thumb on the right edge of a panel. */
    private void drawScrollbar(DrawContext ctx, float x, float y, float w, float h, float scroll, float max) {
        if (max <= 0f) return;
        float trackX = x + w - 4;
        float trackH = h - 4;
        float trackY = y + 2;
        // Track
        fill(ctx, trackX, trackY, 3, trackH, 1.5f, 0x22FFFFFF);
        // Thumb
        float thumbH = Math.max(18, trackH * trackH / (trackH + max));
        float thumbY = trackY + (trackH - thumbH) * (max > 0 ? scroll / max : 0);
        Render2D.rect(ctx, trackX, thumbY, 3, thumbH, 1.5f,
                c(al(Theme.a1(), 160)), c(al(Theme.a2(), 160)),
                c(al(Theme.a2(), 160)), c(al(Theme.a1(), 160)), 0f, 0f);
    }

    private void drawSwitch(DrawContext ctx, float x, float y, float a) {
        float w = 24, h = 13;
        int off = 0xFF3A3A46;
        if (a > 0.02f) Render2D.glow(ctx, x, y, w, h, 6.5f, c(al(Theme.a1(), (int) (80 * a))), 6f);
        Render2D.rect(ctx, x, y, w, h, 6.5f,
                c(Render2D.lerp(off, Theme.a1(), a)), c(Render2D.lerp(off, Theme.a2(), a)),
                c(Render2D.lerp(off, Theme.a2(), a)), c(Render2D.lerp(off, Theme.a1(), a)), 0f, 0f);
        Render2D.circle(ctx, x + 6.5f + (w - 13) * a, y + h / 2, 4.6f, c(0xFFFFFFFF));
    }

    private void renderSettings(DrawContext ctx, float x, float y, float w, float h) {
        fill(ctx, x, y, w, h, 14, 0x0EFFFFFF);
        setB[0] = x; setB[1] = y; setB[2] = w; setB[3] = h;
        if (selected == null) return;

        Render2D.text(ctx, selected.name, x + 14, y + 10, c(WHITE), 1.25f);
        Render2D.text(ctx, Render2D.fit(selected.description, 0.78f, w - 28), x + 14, y + 25, c(GRAY), 0.78f);
        fill(ctx, x + 12, y + 40, w - 24, 1, 0.5f, 0x18FFFFFF);

        float cy = y + 46, ch = h - 52;
        List<Setting> vis = new ArrayList<>();
        for (Setting s : selected.settings) if (s.visible.getAsBoolean()) vis.add(s);

        float total = 0;
        for (Setting s : vis) total += rowHeight(s) + 4;
        if (selected.toggleable) total += 32 + 4;
        setMax = Math.max(0, total - 4 - ch);
        scrollSetT = Anim.clamp(scrollSetT, 0, setMax);
        scrollSet = Anim.approach(scrollSet, scrollSetT, 16f, dt);

        ctx.enableScissor((int) x + 1, (int) cy, (int) (x + w - 1), (int) (cy + ch));
        float ry = cy - scrollSet;
        for (Setting s : vis) {
            float rh = rowHeight(s);
            if (ry + rh >= cy && ry <= cy + ch) drawSetting(ctx, s, x, ry, w, rh, cy, cy + ch);
            ry += rh + 4;
        }
        if (selected.toggleable && ry + 32 >= cy && ry <= cy + ch) drawBind(ctx, x, ry, w, 32, cy, cy + ch);
        ctx.disableScissor();
        drawScrollbar(ctx, x, y, w, h, scrollSet, setMax);
    }

    private float rowHeight(Setting s) { return s instanceof Setting.Num ? 46 : 32; }

    private void label(DrawContext ctx, Setting s, float x, float ry, float maxW) {
        Render2D.text(ctx, s.name, x + 20, ry + 6, c(WHITE), 0.92f);
        Render2D.text(ctx, Render2D.fit(s.description, 0.7f, maxW), x + 20, ry + 17.5f, c(DIM), 0.7f);
    }

    private void drawSetting(DrawContext ctx, Setting s, float x, float ry, float w, float rh, float clipT, float clipB) {
        fill(ctx, x + 8, ry, w - 16, rh, 9, 0x0CFFFFFF);

        if (s instanceof Setting.Bool b) {
            b.anim = Anim.approach(b.anim, b.value ? 1f : 0f, 14f, dt);
            label(ctx, s, x, ry, w - 100);
            float swx = x + w - 18 - 24, swy = ry + (rh - 13) / 2;
            drawSwitch(ctx, swx, swy, b.anim);
            region(x + 8, ry, w - 16, rh, clipT, clipB, (xx, yy, btn) -> b.value = !b.value, null);

        } else if (s instanceof Setting.Mode m) {
            label(ctx, s, x, ry, w - 130);
            String txt = m.get();
            float pw = Math.max(54, Render2D.width(txt, 0.82f) + 20), ph = 18;
            float pxx = x + w - 18 - pw, pyy = ry + (rh - ph) / 2;
            boolean hov = inside(pxx, pyy, pw, ph) && my >= clipT && my <= clipB;
            float hh = hv("mode" + selected.name + s.name, hov);
            fill(ctx, pxx, pyy, pw, ph, 9, Render2D.lerp(0x22FFFFFF, al(Theme.a1(), 90), hh));
            Render2D.outline(ctx, pxx, pyy, pw, ph, 9, c(al(Theme.a1(), (int) (40 + 120 * hh))), 1f);
            Render2D.textCentered(ctx, txt, pxx + pw / 2, pyy + 5.2f, c(WHITE), 0.82f);
            region(pxx, pyy, pw, ph, clipT, clipB, (xx, yy, btn) -> {
                if (btn == 0) m.cycle(1);
                else if (btn == 1) m.cycle(-1);
            }, null);

        } else if (s instanceof Setting.Num n) {
            label(ctx, s, x, ry, w - 100);
            String vt = n.text();
            Render2D.text(ctx, vt, x + w - 18 - Render2D.width(vt, 0.9f), ry + 6, c(Theme.a1()), 0.9f);

            float tx = x + 20, tw = w - 40, ty = ry + 33;
            if (n.shown < 0) n.shown = n.fraction();
            n.shown = Anim.approach(n.shown, n.fraction(), 18f, dt);
            fill(ctx, tx, ty, tw, 4, 2, 0x30FFFFFF);
            float fw = Math.max(4, tw * n.shown);
            Render2D.rect(ctx, tx, ty, fw, 4, 2, c(Theme.a1()), c(Theme.a2()), c(Theme.a2()), c(Theme.a1()), 0f, 0f);
            float kx = tx + tw * n.shown;
            Render2D.glow(ctx, kx - 4, ty - 3, 8, 10, 4, c(al(Theme.a1(), 110)), 5f);
            Render2D.circle(ctx, kx, ty + 2, 5f, c(0xFFFFFFFF));

            final float ftx = tx, ftw = tw;
            Click setter = (xx, yy, btn) -> {
                double f = Math.max(0, Math.min(1, (xx - ftx) / ftw));
                n.set(n.min + f * (n.max - n.min));
            };
            region(tx - 6, ry + 24, tw + 12, 20, clipT, clipB, setter, setter);
        }
    }

    private void drawBind(DrawContext ctx, float x, float ry, float w, float rh, float clipT, float clipB) {
        fill(ctx, x + 8, ry, w - 16, rh, 9, 0x0CFFFFFF);
        Render2D.text(ctx, "Keybind", x + 20, ry + 6, c(WHITE), 0.92f);
        Render2D.text(ctx, "Key that toggles this module", x + 20, ry + 17.5f, c(DIM), 0.7f);

        boolean listening = bindTarget == selected;
        String txt = listening ? "..." : keyName(selected.key);
        float pw = Math.max(54, Render2D.width(txt, 0.82f) + 20), ph = 18;
        float pxx = x + w - 18 - pw, pyy = ry + (rh - ph) / 2;
        boolean hov = inside(pxx, pyy, pw, ph) && my >= clipT && my <= clipB;
        float hh = hv("bind" + selected.name, hov || listening);
        fill(ctx, pxx, pyy, pw, ph, 9, Render2D.lerp(0x22FFFFFF, al(Theme.a1(), 90), hh));
        Render2D.outline(ctx, pxx, pyy, pw, ph, 9, c(al(Theme.a1(), (int) (40 + 120 * hh))), 1f);
        Render2D.textCentered(ctx, txt, pxx + pw / 2, pyy + 5.2f, c(WHITE), 0.82f);
        final Mod target = selected;
        region(pxx, pyy, pw, ph, clipT, clipB, (xx, yy, btn) -> {
            if (btn == 0) bindTarget = target;
            else if (btn == 1) target.key = -1;
        }, null);
    }

    private static net.minecraft.client.MinecraftClient mc() { return net.minecraft.client.MinecraftClient.getInstance(); }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        searchFocus = false;
        bindTarget = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (r.hit(x, y)) {
                r.click.on(x, y, button);
                if (r.drag != null) dragging = r;
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (dragging != null && dragging.drag != null) {
            dragging.drag.on(x, y, button);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        dragging = null;
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        if (x >= listB[0] && x <= listB[0] + listB[2] && y >= listB[1] && y <= listB[1] + listB[3]) {
            scrollListT = Anim.clamp(scrollListT - (float) vertical * 32f, 0, listMax);
        } else if (x >= setB[0] && x <= setB[0] + setB[2] && y >= setB[1] && y <= setB[1] + setB[3]) {
            scrollSetT = Anim.clamp(scrollSetT - (float) vertical * 32f, 0, setMax);
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindTarget != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindTarget.key = -1;
            } else {
                bindTarget.key = keyCode;
            }
            bindTarget = null;
            return true;
        }
        if (searchFocus) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocus = false;
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                scrollList = scrollListT = 0;
            }
            return true;
        }
        if (LuminaClient.guiKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocus && chr >= 32 && search.length() < 24) {
            search += chr;
            scrollList = scrollListT = 0;
            return true;
        }
        return false;
    }
}
