package dev.lumina.module;

public enum Category {
    COMBAT("Combat", true),
    RENDER("Render", true),
    UTIL("Util", false);

    public final String label;
    public final boolean main;

    Category(String label, boolean main) {
        this.label = label;
        this.main = main;
    }
}
