package dev.lumina.module.util;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import net.minecraft.util.math.MathHelper;

/**
 * GCD rotation snapping.
 *
 * Minecraft processes mouse input as:
 *   sensitivityMult = sens * 0.6 + 0.2
 *   yaw  += rawMouseX * sensitivityMult^3 * 8.0 * 0.15
 *
 * Every real rotation change is therefore a multiple of this GCD.
 * Injected rotations that aren't multiples stick out to any checker that
 * looks at rotation deltas (Grim, Vulcan, Matrix all do this).
 *
 * This module samples the player's real mouse movement to measure their
 * exact GCD via Euclidean algorithm, then exposes snapYaw/snapPitch so
 * AimAssist can align every injected delta to the same grid.
 *
 * Enable it alongside AimAssist. AimAssist only applies snapping while
 * this module is on.
 */
public class Bypass extends Mod {

    // EMA-smoothed GCD estimate — starts at a sensible 50%-sensitivity default
    private float yawGcd   = 0.070f;
    private float pitchGcd = 0.070f;

    private boolean calibrated = false;
    private int     calibCount = 0;

    // State from last tick
    private float lastYaw        = Float.NaN;
    private float lastPitch      = Float.NaN;
    private float prevYawDelta   = Float.NaN;
    private float prevPitchDelta = Float.NaN;

    public Bypass() {
        super("Bypass", "GCD snapping — injected rotations look like real mouse input", Category.UTIL);
    }

    @Override
    public void onEnable() {
        lastYaw = lastPitch = Float.NaN;
        prevYawDelta = prevPitchDelta = Float.NaN;
        calibrated = false;
        calibCount = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        float yaw   = mc.player.getYaw();
        float pitch = mc.player.getPitch();

        if (!Float.isNaN(lastYaw)) {
            float dy = Math.abs(MathHelper.wrapDegrees(yaw   - lastYaw));
            float dp = Math.abs(pitch - lastPitch);

            // Only learn from frames where the player actually moved the mouse
            if (dy > 0.003f && !Float.isNaN(prevYawDelta) && prevYawDelta > 0.003f) {
                float g = euclidGcd(dy, prevYawDelta);
                if (g > 0.002f && g < 3.0f) {
                    // EMA — heavy weight on history so a few weird frames don't throw it off
                    yawGcd = yawGcd * 0.88f + g * 0.12f;
                    calibCount++;
                    if (calibCount >= 15) calibrated = true;
                }
            }
            if (dp > 0.003f && !Float.isNaN(prevPitchDelta) && prevPitchDelta > 0.003f) {
                float g = euclidGcd(dp, prevPitchDelta);
                if (g > 0.002f && g < 3.0f) {
                    pitchGcd = pitchGcd * 0.88f + g * 0.12f;
                }
            }

            if (dy > 0.003f) prevYawDelta   = dy;
            if (dp > 0.003f) prevPitchDelta = dp;
        }

        lastYaw   = yaw;
        lastPitch = pitch;
    }

    /**
     * Snap a yaw delta to the nearest GCD multiple.
     * Pass your raw computed yaw step; get back the version that looks mouse-driven.
     */
    public float snapYaw(float delta) {
        if (yawGcd < 0.001f) return delta;
        float snapped = Math.round(delta / yawGcd) * yawGcd;
        // Don't collapse a real delta to zero — use the smallest nonzero grid step
        if (snapped == 0f && Math.abs(delta) > yawGcd * 0.25f)
            snapped = Math.signum(delta) * yawGcd;
        return snapped;
    }

    /**
     * Snap a pitch delta to the nearest GCD multiple.
     */
    public float snapPitch(float delta) {
        if (pitchGcd < 0.001f) return delta;
        float snapped = Math.round(delta / pitchGcd) * pitchGcd;
        if (snapped == 0f && Math.abs(delta) > pitchGcd * 0.25f)
            snapped = Math.signum(delta) * pitchGcd;
        return snapped;
    }

    public float   getYawGcd()      { return yawGcd;   }
    public float   getPitchGcd()    { return pitchGcd; }
    public boolean isCalibrated()   { return calibrated; }

    @Override
    public String suffix() {
        if (!enabled) return "";
        return calibrated
                ? String.format("GCD %.3f", yawGcd)
                : String.format("cal %d/15", calibCount);
    }

    // Euclidean GCD for positive floats — converges in <64 iterations for any pair we'd see
    private static float euclidGcd(float a, float b) {
        a = Math.abs(a);
        b = Math.abs(b);
        for (int i = 0; i < 64 && b > 0.00005f; i++) {
            float t = b;
            b = a % b;
            a = t;
        }
        return a;
    }
}
