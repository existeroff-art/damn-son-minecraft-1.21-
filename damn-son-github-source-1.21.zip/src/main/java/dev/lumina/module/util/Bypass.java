package dev.lumina.module.util;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/**
 * Anti-detection layer: rotation GCD fix + kick/disconnect interception.
 *
 * What servers actually check (Grim, Vulcan, Matrix):
 *
 *   1. GCD distribution  — every real mouse delta is a multiple of the
 *      player's sensitivity GCD. Non-multiples = instant flag.
 *      → Fixed by the Euclidean GCD sampler below.
 *
 *   2. Rotation speed    — humans top out around 90–120°/sec (1.5–2°/tick at
 *      20TPS). Consistently hitting 10+°/tick fires heuristics immediately.
 *      → Fixed by Legit Mode + Rot Cap.
 *
 *   3. Pattern regularity — zero-variance correction deltas = bot.
 *      → Fixed by Natural Tremor (Gaussian noise on every snap output).
 *
 *   4. Correction consistency — perfect frame-by-frame coverage is a signal.
 *      → Fixed by Anti-Consistency (random skip chance).
 *
 *   5. Kick/ban packets  — server sends DisconnectS2CPacket on flag.
 *      → Block Kick swallows the packet before the client processes it.
 *        The server thinks you left; your client stays in the world.
 *        Does NOT work against TCP-level connection drops.
 *
 * Usage:
 *   Enable Bypass before AimAssist. Move your mouse normally for ~15 ticks
 *   so the GCD sampler can calibrate (suffix shows "cal X/15" then "GCD X.XXX").
 *   Enable Block Kick to silently eat server kick packets.
 */
public class Bypass extends Mod {

    // ── Settings ──────────────────────────────────────────────────────────────

    /**
     * Block Kick: intercepts DisconnectS2CPacket before the client processes it.
     * Server-side the player appears to have left (flag resets on their end).
     * Client-side you stay in the world — no kick screen, no reconnect needed.
     *
     * Limitation: if the server closes the socket (TCP drop) instead of sending
     * the packet, this does nothing. That's a network-level drop, not interceptable
     * in client code. On most anti-cheat implementations the packet comes first.
     */
    private final Setting.Bool blockKick = add(new Setting.Bool(
            "Block Kick",
            "Swallow server kick/disconnect packets — stay in-game on anti-cheat flag",
            true));

    /**
     * Legit Mode: hard-clamps every injected rotation to Rot Cap °/tick.
     * At 20TPS, 3°/tick = 60°/sec — well within achievable human range.
     */
    private final Setting.Bool legitMode = add(new Setting.Bool(
            "Legit Mode",
            "Hard-cap rotation speed to human-achievable range",
            true));

    /**
     * Rot Cap (°/tick): only visible when Legit Mode is on.
     * 3.0 = comfortable legit (60°/sec at 20TPS).
     * 5.0 = fast legit (100°/sec, still in human range).
     * 8.0 = borderline — high-sens players can hit this on flicks.
     */
    private final Setting.Num rotCap = add(new Setting.Num(
            "Rot Cap", "Max °/tick in Legit Mode",
            3.0, 0.5, 10.0, 0.5));

    /**
     * Natural Tremor: adds ±noise to every snap output.
     * Breaks pattern detectors that watch for zero-variance correction deltas.
     */
    private final Setting.Bool naturalTremor = add(new Setting.Bool(
            "Natural Tremor",
            "Add micro-noise to snapped rotations — breaks pattern analysis",
            true));

    private final Setting.Num tremorScale = add(new Setting.Num(
            "Tremor Scale", "Tremor amplitude (fraction of GCD)",
            0.18, 0.05, 0.50, 0.01));

    /**
     * Anti-Consistency: randomly skips ~1 in 8 correction ticks.
     * Perfect frame-by-frame aim correction is itself a bot signal.
     */
    private final Setting.Bool antiConsistency = add(new Setting.Bool(
            "Anti-Consistency",
            "Randomly skip ~12% of correction ticks to avoid bot regularity",
            true));

    private final Setting.Num skipChance = add(new Setting.Num(
            "Skip Chance", "% chance to skip a snap per tick",
            12.0, 1.0, 40.0, 1.0));

    // ── GCD sampler state ─────────────────────────────────────────────────────

    private float yawGcd   = 0.070f;
    private float pitchGcd = 0.070f;

    private boolean calibrated = false;
    private int     calibCount = 0;

    private float lastYaw        = Float.NaN;
    private float lastPitch      = Float.NaN;
    private float prevYawDelta   = Float.NaN;
    private float prevPitchDelta = Float.NaN;

    private final Random rng = new Random();

    // ── Constructor ───────────────────────────────────────────────────────────

    public Bypass() {
        super("Bypass", "GCD + kick-block anti-detection layer", Category.UTIL);
        rotCap.visible      = () -> legitMode.value;
        tremorScale.visible = () -> naturalTremor.value;
        skipChance.visible  = () -> antiConsistency.value;
    }

    @Override
    public void onEnable() {
        lastYaw = lastPitch = Float.NaN;
        prevYawDelta = prevPitchDelta = Float.NaN;
        calibrated = false;
        calibCount = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        float yaw   = mc.player.getYaw();
        float pitch = mc.player.getPitch();

        if (!Float.isNaN(lastYaw)) {
            float dy = Math.abs(MathHelper.wrapDegrees(yaw   - lastYaw));
            float dp = Math.abs(pitch - lastPitch);

            if (dy > 0.003f && !Float.isNaN(prevYawDelta) && prevYawDelta > 0.003f) {
                float g = euclidGcd(dy, prevYawDelta);
                if (g > 0.002f && g < 3.0f) {
                    yawGcd = yawGcd * 0.88f + g * 0.12f;
                    calibCount++;
                    if (calibCount >= 15) calibrated = true;
                }
            }
            if (dp > 0.003f && !Float.isNaN(prevPitchDelta) && prevPitchDelta > 0.003f) {
                float g = euclidGcd(dp, prevPitchDelta);
                if (g > 0.002f && g < 3.0f) {
                    pitchGcd = pitchGcd * 0.88f + g * 0.12f;
                }
            }

            if (dy > 0.003f) prevYawDelta   = dy;
            if (dp > 0.003f) prevPitchDelta = dp;
        }

        lastYaw   = yaw;
        lastPitch = pitch;
    }

    // ── Public snap API ───────────────────────────────────────────────────────

    public float snapYaw(float delta) {
        if (antiConsistency.value && rng.nextDouble() * 100.0 < skipChance.value)
            return 0f;

        float snapped = snapToGcd(delta, yawGcd);

        if (naturalTremor.value) {
            snapped += (float)(rng.nextGaussian() * yawGcd * tremorScale.value);
        }

        if (legitMode.value) {
            snapped = MathHelper.clamp(snapped, -(float)rotCap.value, (float)rotCap.value);
        }

        return snapped;
    }

    public float snapPitch(float delta) {
        if (antiConsistency.value && rng.nextDouble() * 100.0 < skipChance.value)
            return 0f;

        float snapped = snapToGcd(delta, pitchGcd);

        if (naturalTremor.value) {
            snapped += (float)(rng.nextGaussian() * pitchGcd * tremorScale.value * 0.6f);
        }

        if (legitMode.value) {
            snapped = MathHelper.clamp(snapped, -(float)rotCap.value, (float)rotCap.value);
        }

        return snapped;
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public float   getYawGcd()           { return yawGcd;             }
    public float   getPitchGcd()         { return pitchGcd;           }
    public boolean isCalibrated()        { return calibrated;         }
    /** Called by KickBypassMixin — true when Bypass is on AND Block Kick is on. */
    public boolean isBlockKickEnabled()  { return blockKick.value;    }
    /** Convenience accessor for the mixin (enabled field is already public via Mod). */
    public boolean isEnabled()           { return enabled;            }

    @Override
    public String suffix() {
        if (!enabled) return "";
        String cal  = calibrated
                ? String.format("GCD %.3f", yawGcd)
                : String.format("cal %d/15", calibCount);
        String mode = legitMode.value ? " legit" : "";
        String kick = blockKick.value ? " [K]"   : "";
        return cal + mode + kick;
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private static float snapToGcd(float delta, float gcd) {
        if (gcd < 0.001f) return delta;
        float snapped = Math.round(delta / gcd) * gcd;
        if (snapped == 0f && Math.abs(delta) > gcd * 0.25f)
            snapped = Math.signum(delta) * gcd;
        return snapped;
    }

    private static float euclidGcd(float a, float b) {
        a = Math.abs(a);
        b = Math.abs(b);
        for (int i = 0; i < 64 && b > 0.00005f; i++) {
            float t = b;
            b = a % b;
            a = t;
        }
        return a;
    }
}
