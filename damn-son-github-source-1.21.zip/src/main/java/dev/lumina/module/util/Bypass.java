package dev.lumina.module.util;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;

/**
 * Bypass — reduces server-side detection fingerprinting.
 *
 * SpoofBrand   : sends "vanilla" brand (via BypassBrandMixin), hiding Fabric.
 * HideChannels : suppresses fabric channel-registration C2S packets via mixin.
 * ActionJitter : randomizes exact attack tick by ±1-2 ticks → looks human to Grim/NCP.
 * SmoothRotate : caps max rotation per tick so AimAssist never produces impossible angles.
 *
 * For minmen.club (NCP/Grim) and anticheat-test.com:
 *   - SpoofBrand + HideChannels kills the client fingerprint.
 *   - ActionJitter prevents pattern detection on combat timing.
 *   - SmoothRotate max is enforced by AimAssist Speed setting; this adds a hard cap.
 */
public class Bypass extends Mod {
    public  final Setting.Bool spoofBrand    = add(new Setting.Bool("Spoof Brand",    "Send 'vanilla' brand instead of 'fabric'",   true));
    public  final Setting.Bool hideChannels  = add(new Setting.Bool("Hide Channels",  "Suppress Fabric channel registration",        true));
    public  final Setting.Bool actionJitter  = add(new Setting.Bool("Action Jitter",  "Randomize attack timing ±1 tick (vs Grim)",  true));
    public  final Setting.Num  jitterMax     = add(new Setting.Num( "Jitter Ticks",   "Max random tick offset for attacks",         2, 1, 5, 1));
    public  final Setting.Bool smoothRotate  = add(new Setting.Bool("Smooth Rotate",  "Cap rotation speed (vs Watchdog/Vulcan)",    true));
    public  final Setting.Num  rotateMax     = add(new Setting.Num( "Max Rot/tick",   "Max degrees rotated per tick",              45, 5,180, 5));

    private int jitterTimer = 0;

    public Bypass() {
        super("Bypass", "Prevents server detection of your client", Category.UTIL);
        jitterMax.visible    = () -> actionJitter.value;
        rotateMax.visible    = () -> smoothRotate.value;
    }

    /**
     * Called by TriggerBot / PvpMacros before they attack to get the jitter delay.
     * Returns 0 or a small random tick count to offset the attack.
     */
    public int jitterDelay() {
        if (!enabled || !actionJitter.value) return 0;
        return (int)(Math.random() * (jitterMax.value + 1));
    }

    /**
     * Called by AimAssist to clamp a rotation delta if SmoothRotate is enabled.
     */
    public float clampRotation(float delta) {
        if (!enabled || !smoothRotate.value) return delta;
        float cap = (float)rotateMax.value;
        return Math.max(-cap, Math.min(cap, delta));
    }
}
