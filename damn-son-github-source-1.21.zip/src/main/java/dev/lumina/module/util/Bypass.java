package dev.lumina.module.util;

import dev.lumina.LuminaClient;
import dev.lumina.module.Category;
import dev.lumina.module.Mod;

/**
 * Retained for configuration/UI compatibility. This module deliberately does not spoof client
 * identity, hide Fabric channels, manipulate packet timing, or claim to defeat server anti-cheat.
 */
public class Bypass extends Mod {
    public Bypass() {
        super("Bypass", "Compatibility status only; no anti-cheat evasion is implemented", Category.UTIL);
    }

    @Override public String suffix() { return enabled ? "No stealth" : ""; }

    @Override public void onEnable() {
        LuminaClient.LOGGER.warn("Bypass is a compatibility placeholder; server anti-cheat evasion is not implemented.");
    }
}
