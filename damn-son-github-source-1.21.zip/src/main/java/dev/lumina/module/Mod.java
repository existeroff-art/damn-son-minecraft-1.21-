package dev.lumina.module;

import dev.lumina.LuminaClient;
import dev.lumina.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayList;
import java.util.List;

public abstract class Mod {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final Category category;

    public boolean enabled;
    public boolean toggleable = true;
    public boolean hudHidden;
    public boolean persistEnabled;
    public boolean keyDown;
    public int key = -1;

    public float guiAnim;
    public float hudAnim;

    public final List<Setting> settings = new ArrayList<>();

    protected Mod(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (enabled == v) return;
        enabled = v;
        try {
            if (v) onEnable(); else onDisable();
        } catch (Throwable t) {
            LuminaClient.LOGGER.error("Module {} failed during toggle", name, t);
        }
        // Satisfying toggle sound — high pling on, low pling off
        playToggleSound(v);
    }

    private void playToggleSound(boolean on) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.getSoundManager() == null) return;
            // BLOCK_NOTE_BLOCK_PLING is RegistryEntry<SoundEvent> in 1.21 — .value() gets the SoundEvent
            float pitch = on ? 1.4f : 0.75f;
            client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), pitch, 0.65f)
            );
        } catch (Throwable ignored) {
            // Sound system not ready yet (e.g. early init) — safe to skip
        }
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}

    /** Small grey text shown after the name in the module list. */
    public String suffix() { return ""; }
}
