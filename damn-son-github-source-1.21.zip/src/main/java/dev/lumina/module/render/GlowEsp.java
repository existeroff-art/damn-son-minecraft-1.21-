package dev.lumina.module.render;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Client-side vanilla glow outlines, without clearing glow state on unrelated entities. */
public class GlowEsp extends Mod {
    private final Setting.Bool players = add(new Setting.Bool("Players", "Highlight players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Highlight hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Highlight animals", false));
    private final Map<LivingEntity, Boolean> originalGlow = new IdentityHashMap<>();

    public GlowEsp() { super("ESP", "Client-side outlines for selected entities", Category.RENDER); }
    @Override public String suffix() { return "Glow"; }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        Set<LivingEntity> present = Collections.newSetFromMap(new IdentityHashMap<>());
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            present.add(living);
            boolean wanted = Targets.valid(living, players.value, mobs.value, animals.value);
            if (wanted) {
                originalGlow.putIfAbsent(living, living.isGlowing());
                if (!living.isGlowing()) living.setGlowing(true);
            } else {
                restore(living);
            }
        }
        Iterator<Map.Entry<LivingEntity, Boolean>> it = originalGlow.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<LivingEntity, Boolean> entry = it.next();
            if (!present.contains(entry.getKey())) {
                LivingEntity entity = entry.getKey();
                if (entity.getWorld() == mc.world) entity.setGlowing(entry.getValue());
                it.remove();
            }
        }
    }

    private void restore(LivingEntity entity) {
        Boolean previous = originalGlow.remove(entity);
        if (previous != null) entity.setGlowing(previous);
    }

    @Override
    public void onDisable() {
        for (Map.Entry<LivingEntity, Boolean> entry : originalGlow.entrySet()) {
            entry.getKey().setGlowing(entry.getValue());
        }
        originalGlow.clear();
    }
}
