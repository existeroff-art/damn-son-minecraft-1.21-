package dev.lumina.module.render;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;

/** Client-side entity outline selection; EntityGlowMixin supplies the outline flag at render time. */
public class GlowEsp extends Mod {
    public static GlowEsp INSTANCE;
    private final Setting.Bool players = add(new Setting.Bool("Players", "Highlight players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Highlight hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Highlight animals", false));

    public GlowEsp() {
        super("ESP", "Client-side outlines for selected entities", Category.RENDER);
        INSTANCE = this;
    }
    @Override public String suffix() { return "Glow"; }

    /** Called from the client-only isGlowing mixin, avoiding server metadata overwriting a local flag. */
    public boolean shouldHighlight(LivingEntity entity) {
        return enabled && entity != null && Targets.valid(entity, players.value, mobs.value, animals.value);
    }
}
