package dev.lumina.module;

import dev.lumina.module.combat.*;
import dev.lumina.module.movement.*;
import dev.lumina.module.player.*;
import dev.lumina.module.render.*;
import dev.lumina.module.util.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Mod> all = new ArrayList<>();
    public final ThemeModule theme;
    public final HudModule hud;

    public ModuleManager() {
        // combat
        add(new Aura());
        add(new TriggerBot());
        add(new AutoTotem());
        add(new AutoGApple());
        // movement
        add(new Sprint());
        add(new Speed());
        add(new Fly());
        add(new NoFall());
        add(new NoJumpDelay());
        add(new GuiMove());
        // render
        hud = add(new HudModule());
        add(new Fullbright());
        add(new GlowEsp());
        // player
        add(new AutoTool());
        add(new FastPlace());
        // util
        theme = add(new ThemeModule());
        add(new AutoRespawn());
    }

    private <T extends Mod> T add(T m) {
        all.add(m);
        return m;
    }

    public List<Mod> in(Category c) {
        List<Mod> out = new ArrayList<>();
        for (Mod m : all) if (m.category == c) out.add(m);
        return out;
    }
}
