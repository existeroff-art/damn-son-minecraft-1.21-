package dev.lumina.module;

import dev.lumina.module.combat.AimAssist;
import dev.lumina.module.combat.AutoPot;
import dev.lumina.module.combat.TriggerBot;
import dev.lumina.module.render.GlowEsp;
import dev.lumina.module.render.HudModule;
import dev.lumina.module.util.Bypass;
import dev.lumina.module.util.ThemeModule;

import java.util.ArrayList;
import java.util.List;

/** Registers only the modules requested by the user. Theme/HUD objects support the existing UI
 * but are deliberately not registered as visible/toggleable feature modules. */
public class ModuleManager {
    public final List<Mod> all = new ArrayList<>();
    public final ThemeModule theme;
    public final HudModule hud;
    public final AutoPot autoPot;
    public final Bypass bypass;

    public ModuleManager() {
        // Internal UI support; not exposed in the module list.
        theme = new ThemeModule();
        hud = new HudModule();

        add(new AimAssist());
        add(new TriggerBot());
        autoPot = add(new AutoPot());
        add(new GlowEsp());
        bypass = add(new Bypass());
    }

    private <T extends Mod> T add(T module) {
        all.add(module);
        return module;
    }

    public List<Mod> in(Category category) {
        List<Mod> result = new ArrayList<>();
        for (Mod module : all) if (module.category == category) result.add(module);
        return result;
    }
}
