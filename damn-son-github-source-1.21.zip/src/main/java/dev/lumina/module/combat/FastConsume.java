package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.mixin.LivingEntityAccessor;
import dev.lumina.setting.Setting;
import net.minecraft.item.*;
import net.minecraft.util.Hand;

/**
 * FastConsume — fast-gapple + consumable optimizer.
 *
 * Implements the behaviour of fast-gapple and consumableoptimizer mods:
 *  - Reduces remaining item-use ticks each tick by (Speed - 1) extra ticks.
 *    A golden apple normally takes 32 ticks to eat; Speed=4 makes it take ~8 ticks.
 *
 * Works for all food items (golden apples, enchanted golden apples, regular food, potions).
 * If the LivingEntityAccessor fails to compile due to field name mismatch,
 * change "itemUseTimeLeft" in LivingEntityAccessor.java to the correct Yarn 1.21 field name.
 */
public class FastConsume extends Mod {
    private final Setting.Num  speed   = add(new Setting.Num("Speed",    "Extra ticks consumed per tick", 3, 2, 8, 1));
    private final Setting.Bool gapple  = add(new Setting.Bool("GApple",  "Fast-eat golden/enchanted apples", true));
    private final Setting.Bool food    = add(new Setting.Bool("Food",    "Fast-eat regular food",         true));
    private final Setting.Bool potions = add(new Setting.Bool("Potions", "Fast-drink potions",            true));

    public FastConsume() {
        super("FastConsume", "Fast gapple & consumable optimizer", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || !mc.player.isUsingItem()) return;

        ItemStack active = mc.player.getActiveItem();
        if (active.isEmpty()) return;

        if (!shouldFast(active)) return;

        LivingEntityAccessor acc = (LivingEntityAccessor)(Object) mc.player;
        int left = acc.lumina$getItemUseTimeLeft();
        if (left <= 1) return;

        // Consume extra ticks — reduces eat time proportionally to Speed setting
        int extra = (int) speed.value - 1;
        acc.lumina$setItemUseTimeLeft(Math.max(1, left - extra));
    }

    private boolean shouldFast(ItemStack stack) {
        Item item = stack.getItem();
        if (gapple.value && (item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE)) return true;
        if (potions.value && (item == Items.POTION || item == Items.MILK_BUCKET)) return true;
        if (food.value) {
            // All other food items via food component check
            return stack.get(net.minecraft.component.DataComponentTypes.FOOD) != null;
        }
        return false;
    }
}
