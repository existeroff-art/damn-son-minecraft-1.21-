package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.util.math.Vec3d;

/**
 * AntiKB — reduces knockback received.
 *
 * Works client-side: when horizontal velocity spikes (knockback frame),
 * we multiply it down by the reduce factor. The server sees your position
 * lagging behind its prediction, which causes partial server-side correction,
 * but visually you barely move. Most effective in low-ping situations.
 *
 * Reduce = 0.0 → full anti-KB (barely move)
 * Reduce = 0.8 → 80% KB (slight reduction)
 *
 * On Grim/NCP, full (0.0) will flag MOVING violations. Keep at 0.4–0.6 for servers.
 * On vanilla / FFA, 0.0 is fine.
 */
public class AntiKB extends Mod {
    private final Setting.Num reduce    = add(new Setting.Num("Reduce",   "Horizontal velocity multiplier (0 = none)", 0.3, 0.0, 1.0, 0.05));
    private final Setting.Num threshold = add(new Setting.Num("Threshold","Min horizontal speed to trigger",           0.2, 0.05, 1.0, 0.05));

    private Vec3d prevVelocity = Vec3d.ZERO;

    public AntiKB() {
        super("AntiKB", "Reduces knockback you receive", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        prevVelocity = Vec3d.ZERO;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        Vec3d vel = mc.player.getVelocity();
        double hSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);

        // Only act on knockback frames — a sudden large horizontal velocity that wasn't there last tick
        double prevH = Math.sqrt(prevVelocity.x * prevVelocity.x + prevVelocity.z * prevVelocity.z);
        double delta = hSpeed - prevH;

        if (delta > threshold.value) {
            // This tick we were knocked back — dampen it
            double factor = reduce.value;
            mc.player.setVelocity(vel.x * factor, vel.y, vel.z * factor);
        }

        prevVelocity = mc.player.getVelocity();
    }
}
