package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;

/**
 * One-shot pearl-catch combo: after the player throws an ender pearl, wait briefly,
 * then use a hotbar wind charge at the same aim angle. The player remains in control
 * of aiming; this does not guarantee a projectile collision on every server/version.
 */
public class PearlCatch extends Mod {
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between pearl and wind charge", 1, 1, 6, 1));
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Return to the original slot after use", true));

    private enum Phase { IDLE, WAITING, USING_CHARGE }
    private Phase phase = Phase.IDLE;
    private int watchPearlSlot = -1;
    private int lastPearlCount = -1;
    private int originalSlot = -1;
    private int windSlot = -1;
    private int initialWindCount;
    private int timer;
    private int useTicks;
    private boolean savedUsePressed;

    public PearlCatch() {
        super("Pearl Catch", "Uses a wind charge shortly after a pearl throw", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (phase == Phase.IDLE) {
            detectPearlThrow();
            return;
        }
        if (phase == Phase.WAITING) {
            if (--timer > 0) return;
            windSlot = findWindCharge();
            if (windSlot < 0) { reset(false); return; }
            ItemStack charge = mc.player.getInventory().getStack(windSlot);
            initialWindCount = charge.getCount();
            mc.player.getInventory().selectedSlot = windSlot;
            savedUsePressed = mc.options.useKey.isPressed();
            mc.options.useKey.setPressed(true);
            useTicks = 0;
            phase = Phase.USING_CHARGE;
            return;
        }
        if (phase == Phase.USING_CHARGE) {
            useTicks++;
            mc.options.useKey.setPressed(true);
            ItemStack current = mc.player.getInventory().getStack(windSlot);
            boolean used = !current.isOf(Items.WIND_CHARGE) || current.getCount() < initialWindCount;
            if (used || useTicks >= 3) {
                mc.options.useKey.setPressed(savedUsePressed);
                if (restore.value && originalSlot >= 0 && originalSlot <= 8) {
                    mc.player.getInventory().selectedSlot = originalSlot;
                }
                reset(false);
            }
        }
    }

    private void detectPearlThrow() {
        if (watchPearlSlot >= 0 && lastPearlCount > 0) {
            ItemStack watched = mc.player.getInventory().getStack(watchPearlSlot);
            if (!watched.isOf(Items.ENDER_PEARL) || watched.getCount() < lastPearlCount) {
                originalSlot = watchPearlSlot;
                watchPearlSlot = -1;
                lastPearlCount = -1;
                if (findWindCharge() < 0) { reset(false); return; }
                timer = (int) delay.value;
                phase = Phase.WAITING;
                return;
            }
            if (mc.player.getInventory().selectedSlot != watchPearlSlot) {
                watchPearlSlot = -1;
                lastPearlCount = -1;
                return;
            }
            lastPearlCount = watched.getCount();
            return;
        }

        int selected = mc.player.getInventory().selectedSlot;
        ItemStack current = mc.player.getInventory().getStack(selected);
        if (current.isOf(Items.ENDER_PEARL)) {
            watchPearlSlot = selected;
            lastPearlCount = current.getCount();
        } else {
            watchPearlSlot = -1;
            lastPearlCount = -1;
        }
    }

    private int findWindCharge() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.WIND_CHARGE)) return i;
        }
        return -1;
    }

    private void reset(boolean releaseUse) {
        if (releaseUse && mc.player != null) mc.options.useKey.setPressed(false);
        phase = Phase.IDLE;
        watchPearlSlot = -1;
        lastPearlCount = -1;
        originalSlot = -1;
        windSlot = -1;
        initialWindCount = 0;
        timer = 0;
        useTicks = 0;
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            if (phase == Phase.USING_CHARGE) mc.options.useKey.setPressed(savedUsePressed);
            if (phase != Phase.IDLE && restore.value && originalSlot >= 0 && originalSlot <= 8) {
                mc.player.getInventory().selectedSlot = originalSlot;
            }
        }
        reset(false);
    }
}
