package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Detects a local pearl throw, waits for the projectile to exist, and fires one wind-charge follow-up. */
public class PearlCatch extends Mod {
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between pearl throw and wind charge", 2, 0, 8, 1));
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Return to the previous hotbar slot after use", true));
    private final Setting.Bool predict = add(new Setting.Bool("Track Pearl", "Aim the charge toward the predicted pearl path", true));
    private final Setting.Num lead = add(new Setting.Num("Prediction", "Additional prediction ticks", 0.0, -2.0, 4.0, 0.25));
    private final Setting.Num spawnWait = add(new Setting.Num("Spawn Wait", "Maximum extra ticks to wait for the pearl entity", 8, 0, 12, 1));

    private enum Phase { IDLE, WAITING, FIRE_CHARGE, WAIT_RESULT }
    private Phase phase = Phase.IDLE;
    private int watchPearlSlot = -1;
    private int lastPearlCount = -1;
    private int originalSlot = -1;
    private int windSlot = -1;
    private int initialWindCount;
    private int timer;
    private int entityWaitTicks;
    private float watchedYaw;
    private float watchedPitch;
    private Vec3d watchedOrigin;
    private float throwYaw;
    private float throwPitch;
    private Vec3d throwOrigin;
    private float savedYaw;
    private float savedPitch;
    private boolean rotationSaved;
    private boolean rotationLockHeld;

    public PearlCatch() {
        super("Pearl Catch", "Tracks your thrown pearl and times a wind-charge follow-up", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            reset(true);
            return;
        }
        if (mc.currentScreen != null) return;

        switch (phase) {
            case IDLE -> detectPearlThrow();
            case WAITING -> {
                if (timer > 0) { timer--; return; }
                windSlot = findWindCharge();
                if (windSlot < 0) { reset(false); return; }

                EnderPearlEntity pearl = predict.value ? findTrackedPearl() : null;
                if (predict.value && pearl == null && entityWaitTicks < (int) spawnWait.value) {
                    // The inventory count can update before the client creates the projectile entity.
                    // Wait a few ticks instead of immediately aiming at an unrelated fallback point.
                    entityWaitTicks++;
                    timer = 0;
                    return;
                }

                initialWindCount = mc.player.getInventory().getStack(windSlot).getCount();
                if (originalSlot < 0 || originalSlot > 8) originalSlot = mc.player.getInventory().selectedSlot;
                savedYaw = mc.player.getYaw();
                savedPitch = mc.player.getPitch();
                rotationSaved = true;
                AimAssist.acquireRotationLock();
                rotationLockHeld = true;
                mc.player.getInventory().selectedSlot = windSlot;
                if (predict.value && pearl != null) aimAtPredictedPearl(pearl);
                else aimAlongThrowDirection();
                phase = Phase.FIRE_CHARGE;
            }
            case FIRE_CHARGE -> {
                // The catch rotation remains active for a full client tick before this use packet.
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                restoreRotation();
                timer = 5;
                phase = Phase.WAIT_RESULT;
            }
            case WAIT_RESULT -> {
                timer--;
                var stack = mc.player.getInventory().getStack(windSlot);
                boolean consumed = stack.getCount() < initialWindCount || !stack.isOf(Items.WIND_CHARGE);
                if (consumed || timer <= 0) {
                    if (restore.value && mc.player.getInventory().selectedSlot == windSlot
                            && originalSlot >= 0 && originalSlot <= 8) {
                        mc.player.getInventory().selectedSlot = originalSlot;
                    }
                    reset(false);
                }
            }
        }
    }

    private void detectPearlThrow() {
        if (watchPearlSlot >= 0 && lastPearlCount > 0) {
            var watched = mc.player.getInventory().getStack(watchPearlSlot);
            if (!watched.isOf(Items.ENDER_PEARL) || watched.getCount() < lastPearlCount) {
                // Use the direction/origin recorded while the pearl was selected, not whatever
                // the camera happens to be looking at after the throw.
                throwYaw = watchedYaw;
                throwPitch = watchedPitch;
                throwOrigin = watchedOrigin;
                originalSlot = watchPearlSlot;
                watchPearlSlot = -1;
                lastPearlCount = -1;
                if (findWindCharge() < 0) { reset(false); return; }
                timer = (int) delay.value;
                entityWaitTicks = 0;
                phase = Phase.WAITING;
                return;
            }
            if (mc.player.getInventory().selectedSlot != watchPearlSlot) {
                watchPearlSlot = -1;
                lastPearlCount = -1;
                return;
            }
            lastPearlCount = watched.getCount();
            watchedYaw = mc.player.getYaw();
            watchedPitch = mc.player.getPitch();
            watchedOrigin = mc.player.getEyePos();
            return;
        }

        int selected = mc.player.getInventory().selectedSlot;
        var current = mc.player.getInventory().getStack(selected);
        if (current.isOf(Items.ENDER_PEARL)) {
            watchPearlSlot = selected;
            lastPearlCount = current.getCount();
            watchedYaw = mc.player.getYaw();
            watchedPitch = mc.player.getPitch();
            watchedOrigin = mc.player.getEyePos();
        } else {
            watchPearlSlot = -1;
            lastPearlCount = -1;
        }
    }

    private EnderPearlEntity findTrackedPearl() {
        var pearls = mc.world.getEntitiesByClass(EnderPearlEntity.class,
                mc.player.getBoundingBox().expand(96.0), p -> p.isAlive());
        EnderPearlEntity owned = pearls.stream()
                .filter(p -> p.getOwner() == mc.player)
                .min((a, b) -> Double.compare(a.squaredDistanceTo(mc.player), b.squaredDistanceTo(mc.player)))
                .orElse(null);
        if (owned != null) return owned;

        // On some servers the client owner reference arrives a tick after the entity itself.
        // Only accept an owner-less projectile if it is close to the recorded launch origin and
        // its velocity agrees with the direction of the pearl we just threw.
        if (throwOrigin == null) return null;
        Vec3d expectedDirection = lookVector(throwYaw, throwPitch);
        return pearls.stream()
                .filter(p -> p.getOwner() == null
                        && p.getPos().distanceTo(throwOrigin) < 8.0
                        && p.getVelocity().lengthSquared() > 0.001
                        && p.getVelocity().normalize().dotProduct(expectedDirection) > 0.65)
                .min((a, b) -> Double.compare(a.squaredDistanceTo(mc.player), b.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private void aimAtPredictedPearl(EnderPearlEntity pearl) {
        Vec3d targetPoint = predictIntersectionPoint(pearl);
        lookAt(targetPoint);
    }

    private void lookAt(Vec3d targetPoint) {
        Vec3d diff = targetPoint.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        mc.player.setYaw(yaw);
        mc.player.setPitch(MathHelper.clamp(pitch, -89.0f, 89.0f));
    }

    /** Approximate the pearl arc and choose the point with the closest travel-time match. */
    private Vec3d predictIntersectionPoint(EnderPearlEntity pearl) {
        Vec3d pos = pearl.getPos();
        Vec3d velocity = pearl.getVelocity();
        Vec3d eye = mc.player.getEyePos();
        double bestError = Double.MAX_VALUE;
        Vec3d best = pos;
        for (int ticks = 1; ticks <= 14; ticks++) {
            pos = pos.add(velocity);
            velocity = velocity.multiply(0.99, 0.99, 0.99).add(0.0, -0.03, 0.0);
            double chargeTicks = eye.distanceTo(pos) / 1.5;
            double error = Math.abs(ticks - (chargeTicks + lead.value));
            if (error < bestError) {
                bestError = error;
                best = pos;
            }
        }
        return best;
    }

    private void aimAlongThrowDirection() {
        Vec3d origin = throwOrigin == null ? mc.player.getEyePos() : throwOrigin;
        lookAt(origin.add(lookVector(throwYaw, throwPitch).multiply(8.0)));
    }

    private Vec3d lookVector(float yawDegrees, float pitchDegrees) {
        double yaw = Math.toRadians(yawDegrees);
        double pitch = Math.toRadians(pitchDegrees);
        return new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch),
                Math.cos(yaw) * Math.cos(pitch));
    }

    private int findWindCharge() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.WIND_CHARGE)) return i;
        }
        return -1;
    }

    private void restoreRotation() {
        if (!rotationSaved || mc.player == null) return;
        mc.player.setYaw(savedYaw);
        mc.player.setPitch(savedPitch);
        rotationSaved = false;
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
    }

    private void reset(boolean restoreState) {
        if (restoreState && mc.player != null) {
            restoreRotation();
            if (restore.value && originalSlot >= 0 && originalSlot <= 8
                    && (windSlot < 0 || mc.player.getInventory().selectedSlot == windSlot)) {
                mc.player.getInventory().selectedSlot = originalSlot;
            }
        }
        phase = Phase.IDLE;
        watchPearlSlot = -1;
        lastPearlCount = -1;
        originalSlot = -1;
        windSlot = -1;
        initialWindCount = 0;
        timer = 0;
        entityWaitTicks = 0;
        throwOrigin = null;
        rotationSaved = false;
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
    }

    @Override public void onDisable() { reset(true); }
}
