package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;

import java.util.List;

/**
 * CrystalMacro — auto crystal PVP.
 *
 * Each burst:
 *  1. Find nearest valid player target.
 *  2. Find a placement block adjacent to/under target (obsidian or bedrock).
 *  3. Switch to End Crystal in hotbar, right-click the block to place the crystal.
 *  4. Attack the placed crystal to explode it.
 *  5. Swap back to saved slot. Repeat after cooldown.
 *
 * PlaceDelay: ticks between placing and exploding (let physics register the crystal).
 * BurstDelay: ticks between full burst cycles.
 */
public class CrystalMacro extends Mod {
    private final Setting.Num placeRange  = add(new Setting.Num("Place Range", "Max distance to place crystal",  4.0, 1.0, 6.0, 0.5));
    private final Setting.Num explRange   = add(new Setting.Num("Expl Range",  "Max distance to explode crystal", 4.5, 1.0, 6.0, 0.5));
    private final Setting.Num placeDelay  = add(new Setting.Num("Place Delay", "Ticks between place and explode",  2, 1, 10, 1));
    private final Setting.Num burstDelay  = add(new Setting.Num("Burst Delay", "Ticks between burst cycles",       5, 1, 20, 1));
    private final Setting.Bool antiSelf   = add(new Setting.Bool("Anti-Self",  "Don't explode crystals close to you", true));
    private final Setting.Num selfRange   = add(new Setting.Num("Self Range",  "Min crystal-to-self distance",    2.0, 0.5, 4.0, 0.5));

    private int phaseTimer = 0;
    private int savedSlot  = -1;
    private boolean placed = false;
    private BlockPos lastPlacePos = null;

    public CrystalMacro() {
        super("CrystalMacro", "Auto crystal PVP — place and explode", Category.COMBAT);
        selfRange.visible = () -> antiSelf.value;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        placed = false;
        phaseTimer = 0;
        lastPlacePos = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        phaseTimer--;
        if (phaseTimer > 0) return;

        if (!placed) {
            // Phase 1: find target + place crystal
            LivingEntity target = findTarget();
            if (target == null) return;

            int crystalSlot = findInHotbar(Items.END_CRYSTAL);
            if (crystalSlot < 0) return;

            BlockPos placePos = findPlacePos(target);
            if (placePos == null) return;

            savedSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = crystalSlot;

            // Right-click top face of the placement block
            Vec3d hitVec = Vec3d.ofCenter(placePos).add(0, 0.5, 0);
            BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, placePos, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);

            lastPlacePos = placePos.up(); // crystal spawns one block above the placed block
            placed = true;
            phaseTimer = (int) placeDelay.value;
        } else {
            // Phase 2: explode the placed crystal
            EndCrystalEntity crystal = findNearestCrystal(lastPlacePos);
            if (crystal != null) {
                // Safety check — don't explode if it'll hit us
                if (antiSelf.value && mc.player.distanceTo(crystal) < selfRange.value) {
                    placed = false;
                    restoreSlot();
                    phaseTimer = (int) burstDelay.value;
                    return;
                }
                mc.interactionManager.attackEntity(mc.player, crystal);
                mc.player.swingHand(Hand.MAIN_HAND);
            }

            placed = false;
            restoreSlot();
            phaseTimer = (int) burstDelay.value;
            lastPlacePos = null;
        }
    }

    private LivingEntity findTarget() {
        double maxR = placeRange.value + 1;
        LivingEntity best = null; double bestDist = maxR;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(maxR),
                le -> Targets.valid(le, true, false, false))) {
            double d = Targets.distance(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }

    private BlockPos findPlacePos(LivingEntity target) {
        // Check the block directly below the target (they stand on it)
        BlockPos below = target.getBlockPos().down();
        Block b = mc.world.getBlockState(below).getBlock();
        if ((b == Blocks.OBSIDIAN || b == Blocks.BEDROCK) &&
            mc.player.getPos().distanceTo(Vec3d.ofCenter(below.up())) <= placeRange.value) {
            return below;
        }
        // Try adjacent blocks around target
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockPos adj = target.getBlockPos().down().offset(dir);
            Block ab = mc.world.getBlockState(adj).getBlock();
            if ((ab == Blocks.OBSIDIAN || ab == Blocks.BEDROCK) &&
                mc.world.getBlockState(adj.up()).isAir() &&
                mc.player.getPos().distanceTo(Vec3d.ofCenter(adj.up())) <= placeRange.value) {
                return adj;
            }
        }
        return null;
    }

    private EndCrystalEntity findNearestCrystal(BlockPos expected) {
        Vec3d center = expected != null ? Vec3d.ofCenter(expected) : mc.player.getPos();
        double maxR = explRange.value;
        List<EndCrystalEntity> crystals = mc.world.getEntitiesByClass(
            EndCrystalEntity.class,
            mc.player.getBoundingBox().expand(maxR + 1),
            e -> !e.isRemoved()
        );
        EndCrystalEntity best = null; double bestDist = maxR + 2;
        for (EndCrystalEntity c : crystals) {
            double d = c.getPos().distanceTo(center);
            if (d < bestDist) { bestDist = d; best = c; }
        }
        return best;
    }

    private int findInHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private void restoreSlot() {
        if (savedSlot >= 0 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
        }
    }
}
