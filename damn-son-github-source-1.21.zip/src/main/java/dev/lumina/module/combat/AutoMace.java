package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/** Target-aware mace swap: selects a mace only while descending toward a valid target. */
public class AutoMace extends Mod {
    private final Setting.Num fallTrigger = add(new Setting.Num("Fall Trigger", "Minimum falling distance", 0.8, 0.2, 5.0, 0.2));
    private final Setting.Num range = add(new Setting.Num("Range", "Target range", 4.5, 2.0, 6.0, 0.5));
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Restore the previous slot on landing", true));
    private int savedSlot = -1;
    private int maceSlot = -1;

    public AutoMace() {
        super("Auto Mace", "Swaps to mace while falling toward a target", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (savedSlot >= 0) {
            if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()) restoreAndReset();
            return;
        }
        if (mc.player.isOnGround() || mc.player.getVelocity().y >= -0.03 || mc.player.fallDistance < fallTrigger.value) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity target)) return;
        if (!Targets.valid(target, true, false, false) || Targets.distance(target) > range.value) return;

        int slot = findMace();
        if (slot < 0 || slot == mc.player.getInventory().selectedSlot) return;
        savedSlot = mc.player.getInventory().selectedSlot;
        maceSlot = slot;
        mc.player.getInventory().selectedSlot = slot;
    }

    @Override
    public void onDisable() { restoreAndReset(); }

    private void restoreAndReset() {
        if (savedSlot >= 0 && mc.player != null && restore.value
                && mc.player.getInventory().selectedSlot == maceSlot) {
            mc.player.getInventory().selectedSlot = savedSlot;
        }
        savedSlot = -1;
        maceSlot = -1;
    }

    private int findMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        }
        return -1;
    }
}
