package dev.lumina.module.combat;

import dev.lumina.LuminaClient;
import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Automatic non-elytra mace sequence. It uses normal item-use and attack calls,
 * prefers a vanilla axe shield-disable hit when the target is actively blocking,
 * then uses a downward wind-charge boost and attacks during the fall.
 */
public class AutoMace extends Mod {
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum target acquisition distance", 4.2, 2.0, 6.0, 0.2));
    private final Setting.Num fallTrigger = add(new Setting.Num("Fall Trigger", "Minimum fall distance before the mace hit", 1.7, 1.5, 5.0, 0.1));
    private final Setting.Bool autoLaunch = add(new Setting.Bool("Auto Launch", "Use a wind charge to start a slam when grounded", true));
    private final Setting.Bool stunShield = add(new Setting.Bool("Stun Slam", "Hit an actively blocking player with an axe before the slam", true));
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Restore the original hotbar slot after the sequence", true));

    private enum Phase { IDLE, PREPARE_CHARGE, FIRE_CHARGE, WAIT_ASCENT, DESCEND, RECOVERY }
    private Phase phase = Phase.IDLE;
    private LivingEntity target;
    private int originalSlot = -1;
    private int moduleSlot = -1;
    private int timer;
    private int cooldown;
    private int recoveryTicks;
    private float savedPitch;
    private boolean pitchSaved;
    private boolean attacked;
    private boolean sawLaunch;
    private boolean rotationLockHeld;

    public AutoMace() {
        super("Auto Mace", "Auto wind-charge slam with optional axe shield stun", Category.COMBAT);
    }

    @Override public void onEnable() {
        clearSequence(false);
        if (LuminaClient.modules != null) {
            for (var module : LuminaClient.modules.all) {
                if (module instanceof MaceSwap && module.enabled) module.setEnabled(false);
            }
        }
    }
    @Override public void onDisable() { clearSequence(true); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            clearSequence(false);
            return;
        }
        if (mc.currentScreen != null) return;
        if (cooldown > 0) cooldown--;

        if (phase == Phase.IDLE) {
            if (mc.player.isFallFlying()) return; // This module intentionally targets non-elytra mace PvP.
            LivingEntity candidate = findTarget();
            if (candidate == null) return;

            if (!mc.player.isOnGround() && mc.player.getVelocity().y < -0.03
                    && mc.player.fallDistance >= fallTrigger.value - 0.2) {
                beginSequence(candidate);
                performShieldStun(candidate);
                int mace = findMace();
                if (mace >= 0) {
                    selectModuleSlot(mace);
                    phase = Phase.DESCEND;
                } else {
                    clearSequence(true);
                }
                return;
            }

            if (mc.player.isOnGround() && cooldown == 0 && autoLaunch.value && findWindCharge() >= 0) {
                beginSequence(candidate);
                AimAssist.acquireRotationLock();
                rotationLockHeld = true;
                performShieldStun(candidate);
                phase = Phase.PREPARE_CHARGE;
            }
            return;
        }

        // Keep the same target through the whole combo. Switching targets mid-launch makes
        // the slam appear erratic and commonly sends the hit to someone other than the stun target.
        if (phase != Phase.RECOVERY && (target == null || !target.isAlive() || target.getWorld() != mc.world)) {
            clearSequence(true);
            cooldown = 8;
            return;
        }

        switch (phase) {
            case PREPARE_CHARGE -> {
                if (timer > 0) { timer--; return; }
                int charge = findWindCharge();
                if (charge < 0) { clearSequence(true); cooldown = 12; return; }
                selectModuleSlot(charge);
                if (!pitchSaved) {
                    savedPitch = mc.player.getPitch();
                    pitchSaved = true;
                }
                mc.player.setPitch(90.0f);
                phase = Phase.FIRE_CHARGE;
                timer = 1;
            }
            case FIRE_CHARGE -> {
                if (timer > 0) { timer--; return; }
                // The downward look has existed for a full client tick, so the server receives it before item use.
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.setPitch(savedPitch);
                int mace = findMace();
                if (mace < 0) { clearSequence(true); cooldown = 12; return; }
                selectModuleSlot(mace);
                phase = Phase.WAIT_ASCENT;
                timer = 70;
                sawLaunch = false;
                // Keep AimAssist/Aura from competing with the automatic sequence until it lands.
            }
            case WAIT_ASCENT -> {
                // The charge needs a few ticks to reach the floor and launch us; do not abort while still grounded.
                if (!mc.player.isOnGround() && mc.player.getVelocity().y > 0.05) sawLaunch = true;
                if (sawLaunch && mc.player.getVelocity().y < -0.03 && mc.player.fallDistance >= 0.5f) {
                    phase = Phase.DESCEND;
                    return;
                }
                if (--timer <= 0) {
                    if (sawLaunch && !mc.player.isOnGround() && mc.player.getVelocity().y < 0.0) {
                        phase = Phase.DESCEND;
                    } else {
                        clearSequence(true);
                        cooldown = 12;
                    }
                }
            }
            case DESCEND -> {
                if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()) {
                    clearSequence(true);
                    cooldown = 18;
                    return;
                }
                int mace = findMace();
                if (mace >= 0 && mc.player.getInventory().selectedSlot != mace) selectModuleSlot(mace);
                if (!attacked && mc.player.getVelocity().y < -0.03
                        && mc.player.fallDistance >= fallTrigger.value
                        && target != null && isTargetValid(target)
                        && Targets.distance(target) <= Math.min(3.0, range.value)
                        && mc.player.getAttackCooldownProgress(0.5f) >= 0.80f
                        && mace >= 0 && mc.player.getInventory().selectedSlot == mace) {
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                    attacked = true;
                    phase = Phase.RECOVERY;
                    recoveryTicks = 0;
                }
            }
            case RECOVERY -> {
                recoveryTicks++;
                if (mc.player.isOnGround() || recoveryTicks > 24) {
                    clearSequence(true);
                    cooldown = 18;
                }
            }
            case IDLE -> { }
        }
    }

    private void beginSequence(LivingEntity candidate) {
        target = candidate;
        originalSlot = mc.player.getInventory().selectedSlot;
        moduleSlot = originalSlot;
        savedPitch = mc.player.getPitch();
        pitchSaved = false;
        attacked = false;
        sawLaunch = false;
        timer = 0;
    }

    private void performShieldStun(LivingEntity candidate) {
        if (!stunShield.value || !(candidate instanceof PlayerEntity playerTarget)
                || !playerTarget.isBlocking()
                || mc.player.getAttackCooldownProgress(0.5f) < 0.90f
                || Targets.distance(candidate) > 3.0) return;
        int axe = findAxe();
        if (axe < 0) return;
        // Select the axe before sending the entity-attack packet so the server evaluates the
        // hit with the correct item; then the combo can switch to wind charge/mace immediately.
        selectModuleSlot(axe);
        mc.interactionManager.attackEntity(mc.player, candidate);
        mc.player.swingHand(Hand.MAIN_HAND);
        timer = 2;
    }

    private boolean isTargetValid(LivingEntity e) {
        return e != null && e.getWorld() == mc.world && e.isAlive()
                && Targets.valid(e, true, false, false) && Targets.distance(e) <= range.value + 1.25;
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestDistance = range.value;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 1.0),
                entity -> Targets.valid(entity, true, false, false))) {
            double distance = Targets.distance(e);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = e;
            }
        }
        return best;
    }

    private int findMace() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        return -1;
    }

    private int findWindCharge() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(Items.WIND_CHARGE)) return i;
        return -1;
    }

    private int findAxe() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() instanceof AxeItem) return i;
        }
        return -1;
    }

    private void selectModuleSlot(int slot) {
        if (slot < 0 || slot > 8 || mc.player == null) return;
        mc.player.getInventory().selectedSlot = slot;
        moduleSlot = slot;
    }

    private void releaseRotationLock() {
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
    }

    private void clearSequence(boolean restorePlayerState) {
        if (mc.player != null) {
            if (restorePlayerState && pitchSaved) mc.player.setPitch(savedPitch);
            if (restorePlayerState && restore.value && originalSlot >= 0 && originalSlot <= 8
                    && mc.player.getInventory().selectedSlot == moduleSlot) {
                mc.player.getInventory().selectedSlot = originalSlot;
            }
        }
        target = null;
        phase = Phase.IDLE;
        originalSlot = -1;
        moduleSlot = -1;
        timer = 0;
        recoveryTicks = 0;
        pitchSaved = false;
        attacked = false;
        sawLaunch = false;
        releaseRotationLock();
    }
}
