package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

/**
 * AnchorMacro — safe respawn-anchor burst macro.
 *
 * Works in the Overworld or The End (respawn anchors EXPLODE in those dimensions).
 * Does NOT explode in the Nether (anchors set spawn there).
 *
 * Cycle per burst:
 *  1. Switch to respawn anchor, place at target's feet (solid block required beneath).
 *  2. Switch to glowstone, place on top of anchor (charges it — max 4 charges per cycle).
 *  3. Switch back to anchor, right-click to detonate.
 *  4. Cooldown.
 *
 * Each charge-detonate cycle damages nearby entities.
 * "Charges" setting controls how many glowstone stacks before detonating (1–4).
 */
public class AnchorMacro extends Mod {
    private final Setting.Mode trigger = add(new Setting.Mode("Trigger", "Manual anchors or automatic target placement", "Manual Place", "Auto Target"));
    private final Setting.Num  range      = add(new Setting.Num("Range",    "Maximum interaction distance", 3.0, 1.0, 5.0, 0.5));
    private final Setting.Num  charges    = add(new Setting.Num("Charges",  "Glowstone charges before det", 1, 1, 4, 1));
    private final Setting.Num  stepDelay  = add(new Setting.Num("Step Delay","Ticks between each step", 1, 1, 10, 1));
    private final Setting.Num  burstDelay = add(new Setting.Num("Burst Delay","Ticks between full cycles", 10, 5, 60, 1));

    private enum Phase { IDLE, PLACE_ANCHOR, CHARGE, DETONATE }
    private Phase phase     = Phase.IDLE;
    private int   timer     = 0;
    private int   savedSlot = -1;
    private int   chargesDone = 0;
    private BlockPos anchorPos = null;

    private enum ManualPhase { WAITING, DETONATE }
    private ManualPhase manualPhase = ManualPhase.WAITING;
    private BlockPos manualAnchorPos = null;
    private BlockPos lastManualAnchor = null;
    private int manualTimer = 0;
    private int manualSavedSlot = -1;

    public AnchorMacro() {
        super("AnchorMacro", "Place & detonate respawn anchors on targets", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        restoreSlot();
        restoreManualSlot();
        phase = Phase.IDLE;
        chargesDone = 0;
        anchorPos = null;
        manualPhase = ManualPhase.WAITING;
        manualAnchorPos = null;
        lastManualAnchor = null;
        manualTimer = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        // In the Nether, respawn anchors set spawn instead of exploding.
        if (mc.world.getRegistryKey() == World.NETHER) return;

        if (trigger.is("Manual Place")) {
            tickManualPlace();
            return;
        }
        tickAutoTarget();
    }

    private void tickAutoTarget() {
        timer--;
        if (timer > 0) return;

        switch (phase) {
            case IDLE -> {
                LivingEntity target = findTarget();
                if (target == null) return;
                anchorPos = findPlacePos(target);
                if (anchorPos == null) return;

                int anchorSlot = findInHotbar(Items.RESPAWN_ANCHOR);
                if (anchorSlot < 0) return;

                savedSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = anchorSlot;
                phase = Phase.PLACE_ANCHOR;
                chargesDone = 0;
                timer = 1;
            }
            case PLACE_ANCHOR -> {
                // Place anchor on a solid block at target feet
                BlockPos below = anchorPos.down();
                Vec3d hitVec = Vec3d.ofCenter(below).add(0, 0.5, 0);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(hitVec, Direction.UP, below, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                phase = Phase.CHARGE;
                timer = (int) stepDelay.value;
                // Switch to glowstone for charging
                int gsSlot = findInHotbar(Items.GLOWSTONE);
                if (gsSlot >= 0) mc.player.getInventory().selectedSlot = gsSlot;
            }
            case CHARGE -> {
                // Right-click the anchor to charge it (place glowstone on it)
                if (!mc.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
                    // Anchor not placed or already gone — abort
                    phase = Phase.IDLE;
                    restoreSlot();
                    timer = (int) burstDelay.value;
                    return;
                }
                int gsSlot = findInHotbar(Items.GLOWSTONE);
                if (gsSlot < 0) {
                    // No glowstone, just detonate now
                    switchToAnchor();
                    phase = Phase.DETONATE;
                    timer = (int) stepDelay.value;
                    return;
                }
                mc.player.getInventory().selectedSlot = gsSlot;
                Vec3d hit = Vec3d.ofCenter(anchorPos);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(hit, Direction.UP, anchorPos, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                chargesDone++;
                if (chargesDone >= (int) charges.value) {
                    switchToAnchor();
                    phase = Phase.DETONATE;
                    timer = (int) stepDelay.value;
                } else {
                    timer = (int) stepDelay.value;
                }
            }
            case DETONATE -> {
                // Right-click the charged anchor to detonate it
                if (mc.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
                    Vec3d hit = Vec3d.ofCenter(anchorPos);
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new BlockHitResult(hit, Direction.UP, anchorPos, false));
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
                restoreSlot();
                phase = Phase.IDLE;
                anchorPos = null;
                chargesDone = 0;
                timer = (int) burstDelay.value;
            }
        }
    }


    /** Watches the block under the crosshair after a player manually places an anchor. */
    private void tickManualPlace() {
        if (manualPhase == ManualPhase.WAITING) {
            if (manualTimer > 0) { manualTimer--; return; }
            if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                BlockPos candidate = hit.getBlockPos();
                if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(candidate)) <= range.value + 0.75
                        && mc.world.getBlockState(candidate).isOf(Blocks.RESPAWN_ANCHOR)) {
                    int chargesNow = mc.world.getBlockState(candidate).get(RespawnAnchorBlock.CHARGES);
                    int glowstoneSlot = findInHotbar(Items.GLOWSTONE);
                    if (chargesNow == 0 && glowstoneSlot >= 0 && !candidate.equals(lastManualAnchor)) {
                        manualAnchorPos = candidate.toImmutable();
                        lastManualAnchor = manualAnchorPos;
                        manualSavedSlot = mc.player.getInventory().selectedSlot;
                        mc.player.getInventory().selectedSlot = glowstoneSlot;
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                new BlockHitResult(Vec3d.ofCenter(manualAnchorPos), Direction.UP, manualAnchorPos, false));
                        mc.player.swingHand(Hand.MAIN_HAND);
                        manualPhase = ManualPhase.DETONATE;
                        manualTimer = Math.max(1, (int) stepDelay.value);
                        return;
                    }
                    // Do not accidentally re-trigger a charged anchor the module didn't place.
                    if (chargesNow > 0) lastManualAnchor = candidate.toImmutable();
                } else if (lastManualAnchor != null
                        && !mc.world.getBlockState(lastManualAnchor).isOf(Blocks.RESPAWN_ANCHOR)) {
                    lastManualAnchor = null;
                }
            } else if (lastManualAnchor != null
                    && !mc.world.getBlockState(lastManualAnchor).isOf(Blocks.RESPAWN_ANCHOR)) {
                lastManualAnchor = null;
            }
            return;
        }

        if (--manualTimer > 0) return;
        if (manualAnchorPos != null && mc.world.getBlockState(manualAnchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
            int anchorSlot = findInHotbar(Items.RESPAWN_ANCHOR);
            if (anchorSlot >= 0) {
                mc.player.getInventory().selectedSlot = anchorSlot;
                // Interaction packets are ordered after the glowstone charge packet.
                // On allowed dimensions this detonates as soon as the server processes it.
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new BlockHitResult(Vec3d.ofCenter(manualAnchorPos), Direction.UP, manualAnchorPos, false));
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
        restoreManualSlot();
        manualAnchorPos = null;
        manualPhase = ManualPhase.WAITING;
        manualTimer = (int) burstDelay.value;
    }

    private void restoreManualSlot() {
        if (manualSavedSlot >= 0 && mc.player != null) {
            mc.player.getInventory().selectedSlot = manualSavedSlot;
            manualSavedSlot = -1;
        }
    }

    private void switchToAnchor() {
        int s = findInHotbar(Items.RESPAWN_ANCHOR);
        if (s >= 0) mc.player.getInventory().selectedSlot = s;
    }

    private LivingEntity findTarget() {
        double maxR = range.value;
        LivingEntity best = null; double bestDist = maxR;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(maxR + 1),
                le -> Targets.valid(le, true, false, false))) {
            double d = Targets.distance(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }

    private BlockPos findPlacePos(LivingEntity target) {
        // Place the anchor at the target's standing position (feet level)
        BlockPos feet = target.getBlockPos();
        // Check if the position is free (air) and has solid block beneath
        BlockPos below = feet.down();
        if (mc.world.getBlockState(feet).isAir() &&
            mc.world.getBlockState(below).isSolidBlock(mc.world, below) &&
            mc.player.getPos().distanceTo(Vec3d.ofCenter(feet)) <= range.value) {
            return feet;
        }
        return null;
    }

    private int findInHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private void restoreSlot() {
        if (savedSlot >= 0 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
        }
    }
}
