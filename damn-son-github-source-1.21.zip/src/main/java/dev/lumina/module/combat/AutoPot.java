package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import java.util.function.Predicate;

/** Healing/strength potion helper with single-shot splash use and exact-content deferred hotbar refill. */
public class AutoPot extends Mod {
    private final Setting.Num healthThr = add(new Setting.Num("Health", "Use healing pot at or below this HP", 10, 1, 20, 1));
    private final Setting.Bool strength = add(new Setting.Bool("Strength", "Use strength potion when effect is absent", false));
    private final Setting.Bool refill = add(new Setting.Bool("Auto Refill", "Refill the consumed hotbar slot from inventory", true));
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between uses", 5, 1, 40, 1));

    private enum Action { IDLE, DRINKING, THROWING }
    private enum Purpose { HEALING, STRENGTH }

    private Action action = Action.IDLE;
    private Purpose purpose = Purpose.HEALING;
    private int actionSlot = -1;
    private int restoreSlot = -1;
    private int actionTicks;
    private int cooldown;
    private int initialCount;
    private Item initialItem;
    private PotionContentsComponent initialContents;
    private float savedPitch;
    private boolean savedUsePressed;
    private boolean sawUsingItem;
    private boolean throwRequested;
    private boolean drinkRequested;
    private boolean rotationLockHeld;

    // Inventory clicks are server-confirmed asynchronously, so refill is deferred and verified.
    private int pendingRefillSlot = -1;
    private Purpose pendingRefillPurpose = Purpose.HEALING;
    private Item pendingRefillItem;
    private PotionContentsComponent pendingRefillContents;
    private int refillDelayTicks;
    private int refillRetries;

    public AutoPot() {
        super("AutoPot", "Uses healing pots at low HP and refills their hotbar slots", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        if (action != Action.IDLE) finishAction(false);
        clearPendingRefill();
    }

    /** Called by the client lifecycle when leaving a world before module ticks can run again. */
    public void onWorldLost() {
        resetActionWithoutPlayer();
        clearPendingRefill();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            // Do not carry stale action state across a world change/disconnect.
            resetActionWithoutPlayer();
            clearPendingRefill();
            return;
        }
        if (action != Action.IDLE) {
            if (mc.currentScreen == null) tickAction();
            return;
        }
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;

        if (pendingRefillSlot >= 0 && refill.value) {
            processPendingRefill();
            if (pendingRefillSlot >= 0 || refillDelayTicks > 0) return;
        } else if (!refill.value) {
            clearPendingRefill();
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        int hotbarSlot = findWantedHotbar(hp);
        if (hotbarSlot < 0 && refill.value) {
            int inventorySlot = findWantedInventory(hp);
            if (inventorySlot >= 0) {
                // SWAP's button is the destination hotbar index (0..8); inventory slots are 9..35.
                swapInventoryIntoHotbar(inventorySlot, mc.player.getInventory().selectedSlot);
                cooldown = 1;
                return;
            }
        }
        if (hotbarSlot >= 0) startUse(hotbarSlot);
    }

    private void startUse(int slot) {
        ItemStack stack = mc.player.getInventory().getStack(slot);
        if (!isPotionItem(stack)) return;

        action = isThrowable(stack) ? Action.THROWING : Action.DRINKING;
        purpose = isStrengthPotion(stack) ? Purpose.STRENGTH : Purpose.HEALING;
        actionSlot = slot;
        restoreSlot = mc.player.getInventory().selectedSlot;
        savedPitch = mc.player.getPitch();
        savedUsePressed = mc.options.useKey.isPressed();
        initialCount = stack.getCount();
        initialItem = stack.getItem();
        initialContents = stack.get(DataComponentTypes.POTION_CONTENTS);
        actionTicks = 0;
        sawUsingItem = false;
        throwRequested = false;
        drinkRequested = false;
        mc.player.getInventory().selectedSlot = slot;

        if (action == Action.THROWING) {
            mc.player.setPitch(85.0f);
            AimAssist.acquireRotationLock();
            rotationLockHeld = true;
        } else {
            mc.options.useKey.setPressed(true);
        }
    }

    private void tickAction() {
        if (actionSlot < 0 || actionSlot > 8 || mc.player.getInventory().selectedSlot != actionSlot) {
            finishAction(false);
            return;
        }
        actionTicks++;
        ItemStack current = mc.player.getInventory().getStack(actionSlot);
        boolean consumed = current.getItem() != initialItem || current.getCount() < initialCount;

        if (action == Action.THROWING) {
            if (!throwRequested) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                throwRequested = true;
                actionTicks = 0;
                return;
            }
            if (consumed) finishAction(true);
            else if (actionTicks >= 8) finishAction(false);
            return;
        }

        if (!drinkRequested) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            drinkRequested = true;
            mc.options.useKey.setPressed(true);
            return;
        }
        mc.options.useKey.setPressed(true);
        if (mc.player.isUsingItem()) sawUsingItem = true;
        if ((sawUsingItem && !mc.player.isUsingItem()) || consumed) finishAction(consumed);
        else if (actionTicks > 45) finishAction(false);
    }

    private void finishAction(boolean consumed) {
        if (mc.player != null) {
            mc.options.useKey.setPressed(savedUsePressed);
            if (action == Action.THROWING) mc.player.setPitch(savedPitch);
            if (restoreSlot >= 0 && restoreSlot <= 8
                    && mc.player.getInventory().selectedSlot == actionSlot) {
                mc.player.getInventory().selectedSlot = restoreSlot;
            }
            if (consumed && refill.value && actionSlot >= 0 && actionSlot <= 8
                    && initialItem != null && initialContents != null) {
                pendingRefillSlot = actionSlot;
                pendingRefillPurpose = purpose;
                pendingRefillItem = initialItem;
                pendingRefillContents = initialContents;
                refillDelayTicks = 2;
                refillRetries = 0;
            }
        }
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
        resetActionState();
        cooldown = (int) delay.value;
    }

    private void resetActionWithoutPlayer() {
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
        resetActionState();
    }

    private void resetActionState() {
        action = Action.IDLE;
        actionSlot = -1;
        restoreSlot = -1;
        initialItem = null;
        initialContents = null;
        initialCount = 0;
        actionTicks = 0;
        sawUsingItem = false;
        throwRequested = false;
        drinkRequested = false;
    }

    private void processPendingRefill() {
        if (pendingRefillSlot < 0 || pendingRefillSlot > 8
                || pendingRefillItem == null || pendingRefillContents == null) {
            clearPendingRefill();
            return;
        }
        if (refillDelayTicks > 0) {
            refillDelayTicks--;
            return;
        }

        ItemStack destination = mc.player.getInventory().getStack(pendingRefillSlot);
        if (isExactRefillMatch(destination, pendingRefillPurpose, pendingRefillItem, pendingRefillContents)) {
            clearPendingRefill();
            cooldown = Math.max(cooldown, 1);
            return;
        }

        int source = findPurposeInventory(pendingRefillPurpose, pendingRefillItem,
                pendingRefillContents, pendingRefillSlot);
        if (source >= 0) {
            swapInventoryIntoHotbar(source, pendingRefillSlot);
            refillDelayTicks = 2;
            refillRetries++;
        } else {
            refillDelayTicks = 1;
            refillRetries++;
        }
        if (refillRetries >= 8) clearPendingRefill();
    }

    private void clearPendingRefill() {
        pendingRefillSlot = -1;
        pendingRefillItem = null;
        pendingRefillContents = null;
        refillDelayTicks = 0;
        refillRetries = 0;
    }

    private int findWantedHotbar(float hp) {
        // Healing takes priority when needed; throwable pots are preferred over drinking pots.
        if (hp <= healthThr.value) {
            int slot = findInHotbar(stack -> isHealingPotion(stack) && isThrowable(stack));
            if (slot >= 0) return slot;
            slot = findInHotbar(this::isHealingPotion);
            if (slot >= 0) return slot;
        }
        if (strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            int slot = findInHotbar(stack -> isStrengthPotion(stack) && isThrowable(stack));
            if (slot >= 0) return slot;
            return findInHotbar(this::isStrengthPotion);
        }
        return -1;
    }

    private int findInHotbar(Predicate<ItemStack> predicate) {
        for (int i = 0; i < 9; i++) {
            if (predicate.test(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private int findWantedInventory(float hp) {
        ScreenHandler handler = mc.player.playerScreenHandler;
        if (hp <= healthThr.value) {
            int slot = findInInventory(handler, stack -> isHealingPotion(stack) && isThrowable(stack));
            if (slot >= 0) return slot;
            slot = findInInventory(handler, this::isHealingPotion);
            if (slot >= 0) return slot;
        }
        if (strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            int slot = findInInventory(handler, stack -> isStrengthPotion(stack) && isThrowable(stack));
            if (slot >= 0) return slot;
            return findInInventory(handler, this::isStrengthPotion);
        }
        return -1;
    }

    private int findInInventory(ScreenHandler handler, Predicate<ItemStack> predicate) {
        for (int slot = 9; slot <= 35; slot++) {
            if (predicate.test(handler.getSlot(slot).getStack())) return slot;
        }
        return -1;
    }

    private int findPurposeInventory(Purpose wanted, Item requiredItem,
                                     PotionContentsComponent requiredContents, int excludedHotbarSlot) {
        ScreenHandler handler = mc.player.playerScreenHandler;
        for (int slot = 9; slot <= 35; slot++) {
            ItemStack stack = handler.getSlot(slot).getStack();
            if (isExactRefillMatch(stack, wanted, requiredItem, requiredContents)) return slot;
        }
        for (int slot = 0; slot < 9; slot++) {
            if (slot == excludedHotbarSlot) continue;
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (isExactRefillMatch(stack, wanted, requiredItem, requiredContents)) return slot;
        }
        return -1;
    }

    private boolean isExactRefillMatch(ItemStack stack, Purpose wanted, Item requiredItem,
                                       PotionContentsComponent requiredContents) {
        if (stack.isEmpty() || requiredItem == null || requiredContents == null
                || stack.getItem() != requiredItem || !isPotionItem(stack)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null || !contents.equals(requiredContents)) return false;
        if (wanted == Purpose.STRENGTH) return isStrengthPotion(stack);
        return isHealingPotion(stack);
    }

    private boolean isHealingPotion(ItemStack stack) {
        if (!isPotionItem(stack)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            var type = effect.getEffectType();
            if (type == StatusEffects.INSTANT_HEALTH || type == StatusEffects.REGENERATION) return true;
        }
        return false;
    }

    private boolean isStrengthPotion(ItemStack stack) {
        if (!isPotionItem(stack)) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            if (effect.getEffectType() == StatusEffects.STRENGTH) return true;
        }
        return false;
    }

    private boolean isThrowable(ItemStack stack) {
        return stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
    }

    private boolean isPotionItem(ItemStack stack) {
        return !stack.isEmpty() && (stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION)
                || stack.isOf(Items.LINGERING_POTION));
    }

    private void swapInventoryIntoHotbar(int inventorySlot, int hotbarSlot) {
        if (inventorySlot < 0 || inventorySlot > 35 || hotbarSlot < 0 || hotbarSlot > 8
                || inventorySlot == hotbarSlot || mc.player == null || mc.interactionManager == null) return;
        ScreenHandler handler = mc.player.playerScreenHandler;
        mc.interactionManager.clickSlot(handler.syncId, inventorySlot, hotbarSlot, SlotActionType.SWAP, mc.player);
    }
}
