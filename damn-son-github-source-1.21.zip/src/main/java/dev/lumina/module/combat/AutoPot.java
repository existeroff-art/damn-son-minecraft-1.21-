package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/** Healing/strength potion helper with single-shot splash use and deferred hotbar refill. */
public class AutoPot extends Mod {
    private final Setting.Num healthThr = add(new Setting.Num("Health", "Use healing pot at or below this HP", 10, 1, 20, 1));
    private final Setting.Bool strength = add(new Setting.Bool("Strength", "Use strength potion when effect is absent", false));
    private final Setting.Bool refill = add(new Setting.Bool("Auto Refill", "Refill the consumed hotbar slot from inventory", true));
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between uses", 5, 1, 40, 1));

    private enum Action { IDLE, DRINKING, THROWING }
    private enum Purpose { HEALING, STRENGTH }

    private Action action = Action.IDLE;
    private Purpose purpose = Purpose.HEALING;
    private int actionSlot = -1;
    private int restoreSlot = -1;
    private int actionTicks;
    private int cooldown;
    private int initialCount;
    private Item initialItem;
    private float savedPitch;
    private boolean savedUsePressed;
    private boolean sawUsingItem;
    private boolean throwRequested;
    private boolean drinkRequested;
    private boolean rotationLockHeld;

    // Refill is deferred until the server's inventory update has had time to arrive.
    private int pendingRefillSlot = -1;
    private Purpose pendingRefillPurpose = Purpose.HEALING;
    private Item pendingRefillItem;
    private int refillDelayTicks;
    private int refillRetries;

    public AutoPot() {
        super("AutoPot", "Uses healing pots at low HP and refills their hotbar slots", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        if (action != Action.IDLE) finishAction(false);
        pendingRefillSlot = -1;
        pendingRefillItem = null;
        refillDelayTicks = 0;
        refillRetries = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (action != Action.IDLE) {
            if (mc.currentScreen == null) tickAction();
            return;
        }
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;

        if (pendingRefillSlot >= 0 && refill.value) {
            processPendingRefill();
            if (pendingRefillSlot >= 0 || refillDelayTicks > 0) return;
        } else if (!refill.value) {
            clearPendingRefill();
        }

        if (cooldown > 0) { cooldown--; return; }

        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        int hotbarSlot = findWantedHotbar(hp);
        if (hotbarSlot < 0 && refill.value) {
            int inventorySlot = findWantedInventory(hp);
            if (inventorySlot >= 0) {
                // SWAP's button is a hotbar index (0..8), while slot is a player-screen slot (9..35).
                swapInventoryIntoHotbar(inventorySlot, mc.player.getInventory().selectedSlot);
                cooldown = 1;
                return;
            }
        }
        if (hotbarSlot >= 0) startUse(hotbarSlot);
    }

    private void startUse(int slot) {
        ItemStack stack = mc.player.getInventory().getStack(slot);
        if (stack.isEmpty()) return;
        action = (stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION))
                ? Action.THROWING : Action.DRINKING;
        purpose = isStrengthPotion(stack) ? Purpose.STRENGTH : Purpose.HEALING;
        actionSlot = slot;
        restoreSlot = mc.player.getInventory().selectedSlot;
        savedPitch = mc.player.getPitch();
        savedUsePressed = mc.options.useKey.isPressed();
        initialCount = stack.getCount();
        initialItem = stack.getItem();
        actionTicks = 0;
        sawUsingItem = false;
        throwRequested = false;
        drinkRequested = false;
        mc.player.getInventory().selectedSlot = slot;

        if (action == Action.THROWING) {
            // Hold this angle through a complete client tick before issuing the use interaction.
            mc.player.setPitch(85.0f);
            AimAssist.acquireRotationLock();
            rotationLockHeld = true;
        } else {
            mc.options.useKey.setPressed(true);
        }
    }

    private void tickAction() {
        if (actionSlot < 0 || actionSlot > 8 || mc.player.getInventory().selectedSlot != actionSlot) {
            // Stop if the player manually changes slots, instead of using whatever item moved
            // into the main hand and later refilling the wrong slot.
            finishAction(false);
            return;
        }
        actionTicks++;
        ItemStack current = mc.player.getInventory().getStack(actionSlot);
        boolean consumed = current.getItem() != initialItem || current.getCount() < initialCount;

        if (action == Action.THROWING) {
            if (!throwRequested) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                throwRequested = true;
                actionTicks = 0;
                return;
            }
            if (consumed) {
                finishAction(true);
            } else if (actionTicks >= 8) {
                // Do not swap a fresh potion out if the server rejected the use interaction.
                finishAction(false);
            }
            return;
        }

        if (!drinkRequested) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            drinkRequested = true;
            mc.options.useKey.setPressed(true);
            return;
        }
        mc.options.useKey.setPressed(true);
        if (mc.player.isUsingItem()) sawUsingItem = true;
        if ((sawUsingItem && !mc.player.isUsingItem()) || consumed) {
            finishAction(consumed);
        } else if (actionTicks > 45) {
            finishAction(false);
        }
    }

    private void finishAction(boolean consumed) {
        if (mc.player != null) {
            mc.options.useKey.setPressed(savedUsePressed);
            if (action == Action.THROWING) mc.player.setPitch(savedPitch);
            // Restore only if this module still owns the selected slot; don't undo the user's manual switch.
            if (restoreSlot >= 0 && restoreSlot <= 8
                    && mc.player.getInventory().selectedSlot == actionSlot) {
                mc.player.getInventory().selectedSlot = restoreSlot;
            }
            if (consumed && refill.value && actionSlot >= 0 && actionSlot <= 8) {
                pendingRefillSlot = actionSlot;
                pendingRefillPurpose = purpose;
                // Preserve the exact potion item kind (splash vs drinkable) so refill
                // cannot silently replace a fast splash pot with a slow drinking potion.
                pendingRefillItem = initialItem;
                refillDelayTicks = 2;
                refillRetries = 0;
            }
        }
        if (rotationLockHeld) {
            AimAssist.releaseRotationLock();
            rotationLockHeld = false;
        }
        action = Action.IDLE;
        actionSlot = -1;
        restoreSlot = -1;
        initialItem = null;
        initialCount = 0;
        actionTicks = 0;
        sawUsingItem = false;
        throwRequested = false;
        drinkRequested = false;
        cooldown = (int) delay.value;
    }

    private void processPendingRefill() {
        if (pendingRefillSlot < 0 || pendingRefillSlot > 8 || pendingRefillItem == null) {
            clearPendingRefill();
            return;
        }
        if (refillDelayTicks > 0) {
            refillDelayTicks--;
            return;
        }

        ItemStack destination = mc.player.getInventory().getStack(pendingRefillSlot);
        if (isPurposeMatch(destination, pendingRefillPurpose, pendingRefillItem)) {
            clearPendingRefill();
            cooldown = Math.max(cooldown, 1);
            return;
        }

        int source = findPurposeInventory(pendingRefillPurpose, pendingRefillItem, pendingRefillSlot);
        if (source >= 0) {
            swapInventoryIntoHotbar(source, pendingRefillSlot);
            // Confirm the authoritative/client-predicted slot change on a later tick. Some
            // servers send the inventory update after the click packet rather than inline.
            refillDelayTicks = 2;
            refillRetries++;
        } else {
            refillRetries++;
            refillDelayTicks = 1;
        }

        if (refillRetries >= 8) clearPendingRefill();
    }

    private void clearPendingRefill() {
        pendingRefillSlot = -1;
        pendingRefillItem = null;
        refillDelayTicks = 0;
        refillRetries = 0;
    }

    private int findWantedHotbar(float hp) {
        // Prefer throwable healing pots, then drinking pots, then strength if enabled.
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isWanted(s, hp) && (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION))) return i;
        }
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isWanted(s, hp)) return i;
        }
        return -1;
    }

    private int findWantedInventory(float hp) {
        ScreenHandler handler = mc.player.playerScreenHandler;
        for (int slot = 9; slot <= 35; slot++) {
            if (isWanted(handler.getSlot(slot).getStack(), hp)) return slot;
        }
        return -1;
    }

    private int findPurposeInventory(Purpose wanted, Item requiredItem, int excludedHotbarSlot) {
        if (requiredItem == null) return -1;
        ScreenHandler handler = mc.player.playerScreenHandler;
        // Prefer the main inventory, then another hotbar slot. This also allows refill
        // when the remaining matching potion was already arranged on the hotbar.
        for (int slot = 9; slot <= 35; slot++) {
            ItemStack stack = handler.getSlot(slot).getStack();
            if (stack.getItem() == requiredItem && isPurposeMatch(stack, wanted, requiredItem)) return slot;
        }
        for (int slot = 0; slot < 9; slot++) {
            if (slot == excludedHotbarSlot) continue;
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() == requiredItem && isPurposeMatch(stack, wanted, requiredItem)) return slot;
        }
        return -1;
    }

    private boolean isWanted(ItemStack stack, float hp) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item != Items.POTION && item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            var type = effect.getEffectType();
            if ((type == StatusEffects.INSTANT_HEALTH || type == StatusEffects.REGENERATION) && hp <= healthThr.value) return true;
            if (type == StatusEffects.STRENGTH && strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) return true;
        }
        return false;
    }

    private boolean isStrengthPotion(ItemStack stack) {
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) if (effect.getEffectType() == StatusEffects.STRENGTH) return true;
        return false;
    }

    private boolean isPurposeMatch(ItemStack stack, Purpose wanted, Item requiredItem) {
        if (stack.isEmpty() || requiredItem == null || stack.getItem() != requiredItem) return false;
        Item item = stack.getItem();
        if (item != Items.POTION && item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            var type = effect.getEffectType();
            if (wanted == Purpose.HEALING && (type == StatusEffects.INSTANT_HEALTH || type == StatusEffects.REGENERATION)) return true;
            if (wanted == Purpose.STRENGTH && type == StatusEffects.STRENGTH) return true;
        }
        return false;
    }

    private void swapInventoryIntoHotbar(int inventorySlot, int hotbarSlot) {
        if (inventorySlot < 0 || inventorySlot > 35 || hotbarSlot < 0 || hotbarSlot > 8
                || inventorySlot == hotbarSlot || mc.player == null || mc.interactionManager == null) return;
        ScreenHandler handler = mc.player.playerScreenHandler;
        mc.interactionManager.clickSlot(handler.syncId, inventorySlot, hotbarSlot, SlotActionType.SWAP, mc.player);
    }
}
