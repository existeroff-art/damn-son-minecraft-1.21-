package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Auto potion helper for Minecraft 1.21.
 * Drinkable potions are held until their use completes. Splash/lingering potions are
 * thrown with a temporary downward pitch so healing potions land at the player's feet.
 * Refill swaps a matching potion from the main inventory into the consumed hotbar slot.
 */
public class AutoPot extends Mod {
    private final Setting.Num healthThr = add(new Setting.Num("Health", "Use healing pot at or below this HP", 10, 1, 20, 1));
    private final Setting.Bool strength = add(new Setting.Bool("Strength", "Use strength potion when effect is absent", false));
    private final Setting.Bool refill = add(new Setting.Bool("Auto Refill", "Refill the used hotbar slot from inventory", true));
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between uses", 5, 1, 40, 1));

    private enum Action { IDLE, DRINKING, THROWING }
    private enum Purpose { HEALING, STRENGTH }

    private Action action = Action.IDLE;
    private Purpose purpose = Purpose.HEALING;
    private int actionSlot = -1;
    private int restoreSlot = -1;
    private int actionTicks;
    private int cooldown;
    private int initialCount;
    private Item initialItem;
    private float savedPitch;
    private boolean savedUsePressed;
    private boolean sawUsingItem;

    public AutoPot() {
        super("AutoPot", "Uses healing pots at low HP; throws splash pots downward", Category.COMBAT);
    }

    @Override public void onDisable() { if (action != Action.IDLE) finishAction(false); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (action != Action.IDLE) {
            tickAction();
            return;
        }
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;
        if (cooldown > 0) { cooldown--; return; }

        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        int hotbarSlot = findWantedHotbar(hp);
        if (hotbarSlot < 0 && refill.value) {
            int inventorySlot = findWantedInventory(hp);
            if (inventorySlot >= 0) {
                int targetSlot = mc.player.getInventory().selectedSlot;
                swapInventoryIntoHotbar(inventorySlot, targetSlot);
                return; // The swapped potion is selected and will be used next tick.
            }
        }
        if (hotbarSlot >= 0) startUse(hotbarSlot, hp);
    }

    private void startUse(int slot, float hp) {
        ItemStack stack = mc.player.getInventory().getStack(slot);
        if (stack.isEmpty()) return;
        Purpose p = isStrengthPotion(stack) ? Purpose.STRENGTH : Purpose.HEALING;
        Item item = stack.getItem();

        action = (item == Items.SPLASH_POTION || item == Items.LINGERING_POTION)
                ? Action.THROWING : Action.DRINKING;
        purpose = p;
        actionSlot = slot;
        restoreSlot = mc.player.getInventory().selectedSlot;
        savedPitch = mc.player.getPitch();
        savedUsePressed = mc.options.useKey.isPressed();
        initialCount = stack.getCount();
        initialItem = item;
        actionTicks = 0;
        sawUsingItem = false;
        mc.player.getInventory().selectedSlot = slot;

        if (action == Action.THROWING) {
            // Use a steep, temporary pitch; the next client tick sends the throw at the feet.
            mc.player.setPitch(85.0f);
        }
        mc.options.useKey.setPressed(true);
    }

    private void tickAction() {
        actionTicks++;
        mc.options.useKey.setPressed(true);
        ItemStack current = mc.player.getInventory().getStack(actionSlot);
        boolean consumed = current.getItem() != initialItem || current.getCount() < initialCount;

        if (action == Action.THROWING) {
            if (consumed || actionTicks >= 3) finishAction(consumed);
            return;
        }

        if (mc.player.isUsingItem()) sawUsingItem = true;
        if ((sawUsingItem && !mc.player.isUsingItem()) || consumed || actionTicks > 45) {
            finishAction(consumed);
        }
    }

    private void finishAction(boolean consumed) {
        if (mc.player != null) {
            mc.options.useKey.setPressed(savedUsePressed);
            if (action == Action.THROWING) mc.player.setPitch(savedPitch);
            if (restoreSlot >= 0 && restoreSlot <= 8) mc.player.getInventory().selectedSlot = restoreSlot;
            if (consumed && refill.value && actionSlot >= 0 && mc.interactionManager != null) {
                refillHotbarSlot(actionSlot, purpose);
            }
        }
        action = Action.IDLE;
        actionSlot = -1;
        restoreSlot = -1;
        initialItem = null;
        initialCount = 0;
        actionTicks = 0;
        sawUsingItem = false;
        cooldown = (int) delay.value;
    }

    private int findWantedHotbar(float hp) {
        // Prefer splash healing potions, then regular drinkable potions, then strength.
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isWanted(s, hp) && (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION))) return i;
        }
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isWanted(s, hp)) return i;
        }
        return -1;
    }

    private int findWantedInventory(float hp) {
        ScreenHandler handler = mc.player.playerScreenHandler;
        for (int slot = 9; slot <= 35; slot++) {
            if (isWanted(handler.getSlot(slot).getStack(), hp)) return slot;
        }
        return -1;
    }

    private boolean isWanted(ItemStack stack, float hp) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item != Items.POTION && item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            var type = effect.getEffectType();
            if ((type == StatusEffects.INSTANT_HEALTH || type == StatusEffects.REGENERATION) && hp <= healthThr.value) return true;
            if (type == StatusEffects.STRENGTH && strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) return true;
        }
        return false;
    }

    private boolean isStrengthPotion(ItemStack stack) {
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            if (effect.getEffectType() == StatusEffects.STRENGTH) return true;
        }
        return false;
    }

    private boolean isPurposeMatch(ItemStack stack, Purpose wanted) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item != Items.POTION && item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (var effect : contents.getEffects()) {
            var type = effect.getEffectType();
            if (wanted == Purpose.HEALING && (type == StatusEffects.INSTANT_HEALTH || type == StatusEffects.REGENERATION)) return true;
            if (wanted == Purpose.STRENGTH && type == StatusEffects.STRENGTH) return true;
        }
        return false;
    }

    private void swapInventoryIntoHotbar(int inventorySlot, int hotbarSlot) {
        ScreenHandler h = mc.player.playerScreenHandler;
        mc.interactionManager.clickSlot(h.syncId, inventorySlot, hotbarSlot, SlotActionType.SWAP, mc.player);
        cooldown = 1;
    }

    private void refillHotbarSlot(int hotbarSlot, Purpose wanted) {
        ScreenHandler h = mc.player.playerScreenHandler;
        for (int slot = 9; slot <= 35; slot++) {
            if (isPurposeMatch(h.getSlot(slot).getStack(), wanted)) {
                mc.interactionManager.clickSlot(h.syncId, slot, hotbarSlot, SlotActionType.SWAP, mc.player);
                return;
            }
        }
    }
}
