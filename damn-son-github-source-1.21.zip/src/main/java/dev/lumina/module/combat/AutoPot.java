package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.*;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import java.util.List;

/**
 * AutoPot — auto-drinks potions when HP is low.
 *
 * Priority order:
 *   1. Offhand potion: if offhand has a health/regen/strength potion, use it (right-click).
 *   2. Hotbar potion:  switch to potion slot, use, switch back.
 *
 * AutoRefill: when offhand potion is gone, swap a new one from your inventory.
 */
public class AutoPot extends Mod {
    private final Setting.Num  healthThr = add(new Setting.Num("Health",    "Use pot at or below this HP",   10, 1, 20, 1));
    private final Setting.Bool strength  = add(new Setting.Bool("Strength", "Also throw strength potions",   false));
    private final Setting.Bool refill    = add(new Setting.Bool("Auto Refill","Move potion from inv to offhand", true));
    private final Setting.Num  delay     = add(new Setting.Num("Delay",     "Ticks between pot uses",         5, 1, 40, 1));

    private int cooldown = 0;
    private int savedSlot = -1;
    private int drinkTicks = 0;

    public AutoPot() {
        super("AutoPot", "Auto drinks potions when low", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        finishDrink();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;

        // Currently drinking — hold use until done
        if (savedSlot >= 0) {
            drinkTicks++;
            mc.options.useKey.setPressed(true);
            if (drinkTicks > 40 || !mc.player.isUsingItem()) finishDrink();
            return;
        }

        if (cooldown > 0) { cooldown--; return; }

        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (hp > healthThr.value && !strength.value) return;

        // 1. Try offhand
        ItemStack off = mc.player.getOffHandStack();
        if (isPotionWeWant(off, hp)) {
            drinkFrom(Hand.OFF_HAND, -1);
            return;
        }

        // 2. Try hotbar
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isPotionWeWant(s, hp)) {
                savedSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                drinkTicks = 0;
                mc.options.useKey.setPressed(true);
                return;
            }
        }

        // 3. Auto-refill offhand from inventory
        if (refill.value && (off.isEmpty() || off.getItem() == Items.AIR)) {
            tryRefillOffhand();
        }
    }

    private boolean isPotionWeWant(ItemStack s, float hp) {
        if (s.isEmpty()) return false;
        if (s.getItem() != Items.POTION && s.getItem() != Items.SPLASH_POTION
                && s.getItem() != Items.LINGERING_POTION) return false;
        var effects = PotionUtil.getPotionEffects(s);
        for (var eff : effects) {
            if (eff.getEffectType() == StatusEffects.INSTANT_HEALTH && hp <= healthThr.value) return true;
            if (eff.getEffectType() == StatusEffects.REGENERATION    && hp <= healthThr.value) return true;
            if (eff.getEffectType() == StatusEffects.STRENGTH         && strength.value)        return true;
        }
        return false;
    }

    private void drinkFrom(Hand hand, int hotbarSlot) {
        savedSlot = hotbarSlot; // -1 means offhand, no slot swap needed
        drinkTicks = 0;
        mc.options.useKey.setPressed(true);
    }

    private void finishDrink() {
        mc.options.useKey.setPressed(false);
        if (savedSlot > 0 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
        }
        savedSlot = -1;
        drinkTicks = 0;
        cooldown = (int) delay.value;
    }

    private void tryRefillOffhand() {
        if (mc.interactionManager == null) return;
        ScreenHandler h = mc.player.playerScreenHandler;
        // offhand slot in playerScreenHandler is slot index 45
        for (int i = 9; i <= 44; i++) {
            ItemStack s = h.getSlot(i).getStack();
            if (s.getItem() == Items.POTION || s.getItem() == Items.SPLASH_POTION) {
                // Swap to offhand (slot 40 = offhand in inventory screen)
                mc.interactionManager.clickSlot(h.syncId, i, 40, SlotActionType.SWAP, mc.player);
                cooldown = 10;
                return;
            }
        }
    }
}
