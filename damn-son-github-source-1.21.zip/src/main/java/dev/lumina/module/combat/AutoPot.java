package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import java.util.function.Predicate;
import java.util.function.ToIntFunction;

/**
 * Full PvP potion helper — healing, strength, speed, fire resistance, golden apples.
 *
 * Priority order (highest first):
 *   1. Healing   — whenever HP ≤ healthThr
 *   2. Fire res  — whenever player is on fire (if fireRes setting enabled)
 *   3. Strength  — whenever Strength effect is absent (if strength setting enabled)
 *   4. Speed     — whenever Speed effect is absent (if speed setting enabled)
 *   5. Golden apple — whenever HP ≤ gappleHp (if gapple setting enabled)
 *
 * Within each type, splash/lingering pots are preferred over drinkables,
 * and higher amplifier (II) is preferred over lower (I).
 *
 * Auto Refill moves a matching pot from inventory back into the consumed hotbar
 * slot — same-type, same-item, same-contents match. Works for all pot types
 * including golden apples.
 */
public class AutoPot extends Mod {

    // ── Settings ──
    private final Setting.Num  healthThr  = add(new Setting.Num ("Health",       "Use healing pot at or below this HP",        10,  1, 20, 1));
    private final Setting.Bool strength   = add(new Setting.Bool("Strength",     "Use strength potion when effect is absent",  false));
    private final Setting.Bool speed      = add(new Setting.Bool("Speed",        "Use speed potion when effect is absent",     false));
    private final Setting.Bool fireRes    = add(new Setting.Bool("Fire Resist",  "Use fire resistance when on fire",           true));
    private final Setting.Bool gapple     = add(new Setting.Bool("Golden Apple", "Eat golden apple at critical HP",            false));
    private final Setting.Num  gappleHp   = add(new Setting.Num ("Gap HP",       "Eat golden apple at or below this HP",       8,   1, 20, 1));
    private final Setting.Bool refill     = add(new Setting.Bool("Auto Refill",  "Refill consumed hotbar slot from inventory", true));
    private final Setting.Num  delay      = add(new Setting.Num ("Delay",        "Ticks between uses",                         5,   1, 40, 1));
    private final Setting.Num  throwPitch = add(new Setting.Num ("Throw Pitch",  "Downward pitch for splash pot throw (°)",    80,  45, 90, 1));

    // ── Action state machine ──
    private enum Action  { IDLE, DRINKING, THROWING }
    private enum Purpose { HEALING, STRENGTH, SPEED, FIRE_RES, GAPPLE }

    private Action  action     = Action.IDLE;
    private Purpose purpose    = Purpose.HEALING;
    private int     actionSlot = -1;
    private int     restoreSlot = -1;
    private int     actionTicks;
    private int     cooldown;
    private int     initialCount;
    private Item    initialItem;
    private PotionContentsComponent initialContents;
    private float   savedPitch;
    private boolean savedUsePressed;
    private boolean sawUsingItem;
    private boolean throwRequested;
    private boolean drinkRequested;
    private boolean rotationLockHeld;

    // ── Deferred refill state ──
    private int     pendingRefillSlot    = -1;
    private Purpose pendingRefillPurpose = Purpose.HEALING;
    private Item    pendingRefillItem;
    private PotionContentsComponent pendingRefillContents;
    private int     refillDelayTicks;
    private int     refillRetries;

    public AutoPot() {
        super("AutoPot", "Full PvP pot helper — heal, strength, speed, fire res, gaps", Category.COMBAT);
        // Golden apple HP only shows when gapple is on
        gappleHp.visible = () -> gapple.value;
    }

    // ── Suffix: shows active effects briefly ──
    @Override
    public String suffix() {
        if (!enabled || mc.player == null) return "";
        StringBuilder sb = new StringBuilder();
        if (mc.player.hasStatusEffect(StatusEffects.STRENGTH))      sb.append("STR ");
        if (mc.player.hasStatusEffect(StatusEffects.SPEED))         sb.append("SPD ");
        if (mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) sb.append("FR ");
        if (mc.player.hasStatusEffect(StatusEffects.ABSORPTION))    sb.append("ABS ");
        return sb.toString().trim();
    }

    @Override public void onDisable() {
        if (action != Action.IDLE) finishAction(false);
        clearPendingRefill();
    }

    public void onWorldLost() {
        resetActionWithoutPlayer();
        clearPendingRefill();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            resetActionWithoutPlayer();
            clearPendingRefill();
            return;
        }
        if (action != Action.IDLE) {
            if (mc.currentScreen == null) tickAction();
            return;
        }
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;

        if (pendingRefillSlot >= 0 && refill.value) {
            processPendingRefill();
            if (pendingRefillSlot >= 0 || refillDelayTicks > 0) return;
        } else if (!refill.value) {
            clearPendingRefill();
        }

        if (cooldown > 0) { cooldown--; return; }

        // ── Decide what to use ──
        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();

        // 1. Healing
        int slot = findBestHotbar(hp);
        if (slot < 0 && refill.value) {
            int invSlot = findBestInventory(hp);
            if (invSlot >= 0) {
                swapInventoryIntoHotbar(invSlot, mc.player.getInventory().selectedSlot);
                cooldown = 1;
                return;
            }
        }
        if (slot >= 0) { startUse(slot); return; }
    }

    // ── Priority-ordered hotbar scan ──
    private int findBestHotbar(float hp) {
        int slot;

        // 1. Healing — splash II > splash I > drink II > drink I
        if (hp <= healthThr.value) {
            slot = findInHotbar(s -> isHealingPotion(s) && isThrowable(s), this::healQuality);
            if (slot >= 0) return slot;
            slot = findInHotbar(this::isHealingPotion, this::healQuality);
            if (slot >= 0) return slot;
        }

        // 2. Fire resistance — on fire only
        if (fireRes.value && mc.player.isOnFire() && !mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) {
            slot = findInHotbar(s -> isFireResPotion(s) && isThrowable(s), s -> 1);
            if (slot >= 0) return slot;
            slot = findInHotbar(this::isFireResPotion, s -> 1);
            if (slot >= 0) return slot;
        }

        // 3. Strength
        if (strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            slot = findInHotbar(s -> isStrengthPotion(s) && isThrowable(s), this::amplifierQuality);
            if (slot >= 0) return slot;
            slot = findInHotbar(this::isStrengthPotion, this::amplifierQuality);
            if (slot >= 0) return slot;
        }

        // 4. Speed
        if (speed.value && !mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            slot = findInHotbar(s -> isSpeedPotion(s) && isThrowable(s), this::amplifierQuality);
            if (slot >= 0) return slot;
            slot = findInHotbar(this::isSpeedPotion, this::amplifierQuality);
            if (slot >= 0) return slot;
        }

        // 5. Golden apple
        if (gapple.value && hp <= gappleHp.value) {
            slot = findInHotbar(this::isGoldenApple, s -> isEnchantedApple(s) ? 2 : 1);
            if (slot >= 0) return slot;
        }

        return -1;
    }

    // ── Same priority order for inventory ──
    private int findBestInventory(float hp) {
        ScreenHandler h = mc.player.playerScreenHandler;
        int slot;

        if (hp <= healthThr.value) {
            slot = findInInventory(h, s -> isHealingPotion(s) && isThrowable(s), this::healQuality);
            if (slot >= 0) return slot;
            slot = findInInventory(h, this::isHealingPotion, this::healQuality);
            if (slot >= 0) return slot;
        }
        if (fireRes.value && mc.player.isOnFire() && !mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) {
            slot = findInInventory(h, s -> isFireResPotion(s) && isThrowable(s), s -> 1);
            if (slot >= 0) return slot;
            slot = findInInventory(h, this::isFireResPotion, s -> 1);
            if (slot >= 0) return slot;
        }
        if (strength.value && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            slot = findInInventory(h, s -> isStrengthPotion(s) && isThrowable(s), this::amplifierQuality);
            if (slot >= 0) return slot;
            slot = findInInventory(h, this::isStrengthPotion, this::amplifierQuality);
            if (slot >= 0) return slot;
        }
        if (speed.value && !mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            slot = findInInventory(h, s -> isSpeedPotion(s) && isThrowable(s), this::amplifierQuality);
            if (slot >= 0) return slot;
            slot = findInInventory(h, this::isSpeedPotion, this::amplifierQuality);
            if (slot >= 0) return slot;
        }
        if (gapple.value && hp <= gappleHp.value) {
            slot = findInInventory(h, this::isGoldenApple, s -> isEnchantedApple(s) ? 2 : 1);
            if (slot >= 0) return slot;
        }
        return -1;
    }

    // ── Quality scorers for best-in-slot ──
    private int healQuality(ItemStack s) {
        // Splash > drink, II > I
        int score = isThrowable(s) ? 2 : 0;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c != null) for (var e : c.getEffects()) {
            if (e.getEffectType() == StatusEffects.INSTANT_HEALTH) score += (e.getAmplifier() + 1) * 10;
            if (e.getEffectType() == StatusEffects.REGENERATION)   score += (e.getAmplifier() + 1) * 3;
        }
        return score;
    }

    private int amplifierQuality(ItemStack s) {
        int score = isThrowable(s) ? 10 : 0;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c != null) for (var e : c.getEffects()) score += e.getAmplifier() + 1;
        return score;
    }

    // ── Hotbar scan: pick highest-quality matching slot ──
    private int findInHotbar(Predicate<ItemStack> pred, ToIntFunction<ItemStack> quality) {
        int bestSlot = -1, bestQ = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (pred.test(s)) {
                int q = quality.applyAsInt(s);
                if (q > bestQ) { bestQ = q; bestSlot = i; }
            }
        }
        return bestSlot;
    }

    private int findInInventory(ScreenHandler handler, Predicate<ItemStack> pred, ToIntFunction<ItemStack> quality) {
        int bestSlot = -1, bestQ = -1;
        for (int slot = 9; slot <= 35; slot++) {
            ItemStack s = handler.getSlot(slot).getStack();
            if (pred.test(s)) {
                int q = quality.applyAsInt(s);
                if (q > bestQ) { bestQ = q; bestSlot = slot; }
            }
        }
        return bestSlot;
    }

    // ── startUse / tickAction / finishAction — unchanged logic, just uses throwPitch setting ──
    private void startUse(int slot) {
        ItemStack stack = mc.player.getInventory().getStack(slot);
        if (!isUsable(stack)) return;

        boolean throwable = isThrowable(stack);
        action     = throwable ? Action.THROWING : Action.DRINKING;
        purpose    = purposeOf(stack);
        actionSlot = slot;
        restoreSlot = mc.player.getInventory().selectedSlot;
        savedPitch  = mc.player.getPitch();
        savedUsePressed = mc.options.useKey.isPressed();
        initialCount    = stack.getCount();
        initialItem     = stack.getItem();
        initialContents = stack.get(DataComponentTypes.POTION_CONTENTS); // null for apples — that's fine
        actionTicks  = 0;
        sawUsingItem = false;
        throwRequested = false;
        drinkRequested = false;

        mc.player.getInventory().selectedSlot = slot;
        if (throwable) {
            mc.player.setPitch((float) throwPitch.value);
            AimAssist.acquireRotationLock();
            rotationLockHeld = true;
        } else {
            mc.options.useKey.setPressed(true);
        }
    }

    private void tickAction() {
        if (actionSlot < 0 || actionSlot > 8 || mc.player.getInventory().selectedSlot != actionSlot) {
            finishAction(false); return;
        }
        actionTicks++;
        ItemStack current = mc.player.getInventory().getStack(actionSlot);
        boolean consumed = current.getItem() != initialItem || current.getCount() < initialCount;

        if (action == Action.THROWING) {
            if (!throwRequested) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                throwRequested = true;
                actionTicks = 0;
                return;
            }
            if (consumed) finishAction(true);
            else if (actionTicks >= 8) finishAction(false);
            return;
        }

        // Drinking / eating
        if (!drinkRequested) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            drinkRequested = true;
            mc.options.useKey.setPressed(true);
            return;
        }
        mc.options.useKey.setPressed(true);
        if (mc.player.isUsingItem()) sawUsingItem = true;
        if ((sawUsingItem && !mc.player.isUsingItem()) || consumed) finishAction(consumed);
        else if (actionTicks > 50) finishAction(false);
    }

    private void finishAction(boolean consumed) {
        if (mc.player != null) {
            mc.options.useKey.setPressed(savedUsePressed);
            if (action == Action.THROWING) mc.player.setPitch(savedPitch);
            if (restoreSlot >= 0 && restoreSlot <= 8
                    && mc.player.getInventory().selectedSlot == actionSlot) {
                mc.player.getInventory().selectedSlot = restoreSlot;
            }
            if (consumed && refill.value && actionSlot >= 0 && actionSlot <= 8 && initialItem != null) {
                pendingRefillSlot     = actionSlot;
                pendingRefillPurpose  = purpose;
                pendingRefillItem     = initialItem;
                pendingRefillContents = initialContents; // null for apples
                refillDelayTicks      = 2;
                refillRetries         = 0;
            }
        }
        if (rotationLockHeld) { AimAssist.releaseRotationLock(); rotationLockHeld = false; }
        resetActionState();
        cooldown = (int) delay.value;
    }

    private void resetActionWithoutPlayer() {
        if (rotationLockHeld) { AimAssist.releaseRotationLock(); rotationLockHeld = false; }
        resetActionState();
    }

    private void resetActionState() {
        action = Action.IDLE; actionSlot = -1; restoreSlot = -1;
        initialItem = null; initialContents = null; initialCount = 0;
        actionTicks = 0; sawUsingItem = false;
        throwRequested = false; drinkRequested = false;
    }

    // ── Refill ──
    private void processPendingRefill() {
        if (pendingRefillSlot < 0 || pendingRefillSlot > 8 || pendingRefillItem == null) {
            clearPendingRefill(); return;
        }
        if (refillDelayTicks > 0) { refillDelayTicks--; return; }

        ItemStack dest = mc.player.getInventory().getStack(pendingRefillSlot);
        if (isRefillMatch(dest, pendingRefillPurpose, pendingRefillItem, pendingRefillContents)) {
            clearPendingRefill();
            cooldown = Math.max(cooldown, 1);
            return;
        }

        int source = findRefillSource(pendingRefillPurpose, pendingRefillItem,
                pendingRefillContents, pendingRefillSlot);
        if (source >= 0) {
            swapInventoryIntoHotbar(source, pendingRefillSlot);
            refillDelayTicks = 2;
        } else {
            refillDelayTicks = 1;
        }
        refillRetries++;
        if (refillRetries >= 10) clearPendingRefill();
    }

    private void clearPendingRefill() {
        pendingRefillSlot = -1; pendingRefillItem = null; pendingRefillContents = null;
        refillDelayTicks = 0; refillRetries = 0;
    }

    private int findRefillSource(Purpose wanted, Item reqItem, PotionContentsComponent reqContents, int excl) {
        ScreenHandler h = mc.player.playerScreenHandler;
        for (int slot = 9; slot <= 35; slot++) {
            if (isRefillMatch(h.getSlot(slot).getStack(), wanted, reqItem, reqContents)) return slot;
        }
        for (int slot = 0; slot < 9; slot++) {
            if (slot == excl) continue;
            if (isRefillMatch(mc.player.getInventory().getStack(slot), wanted, reqItem, reqContents)) return slot;
        }
        return -1;
    }

    /**
     * Refill match: same item + same potion contents (or same golden apple item).
     * This means a Healing II splash refills with another Healing II splash, not a Healing I.
     */
    private boolean isRefillMatch(ItemStack s, Purpose wanted, Item reqItem, PotionContentsComponent reqContents) {
        if (s.isEmpty() || reqItem == null) return false;
        if (s.getItem() != reqItem) return false;
        // Golden apples don't have POTION_CONTENTS
        if (wanted == Purpose.GAPPLE) return s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
        if (reqContents == null) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null || !c.equals(reqContents)) return false;
        return purposeOf(s) == wanted;
    }

    // ── Helpers ──
    private Purpose purposeOf(ItemStack s) {
        if (isGoldenApple(s))   return Purpose.GAPPLE;
        if (isHealingPotion(s)) return Purpose.HEALING;
        if (isStrengthPotion(s)) return Purpose.STRENGTH;
        if (isSpeedPotion(s))   return Purpose.SPEED;
        if (isFireResPotion(s)) return Purpose.FIRE_RES;
        return Purpose.HEALING;
    }

    private boolean isHealingPotion(ItemStack s) {
        if (!isPotionItem(s)) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (var e : c.getEffects())
            if (e.getEffectType() == StatusEffects.INSTANT_HEALTH
                    || e.getEffectType() == StatusEffects.REGENERATION) return true;
        return false;
    }

    private boolean isStrengthPotion(ItemStack s) {
        if (!isPotionItem(s)) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (var e : c.getEffects())
            if (e.getEffectType() == StatusEffects.STRENGTH) return true;
        return false;
    }

    private boolean isSpeedPotion(ItemStack s) {
        if (!isPotionItem(s)) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (var e : c.getEffects())
            if (e.getEffectType() == StatusEffects.SPEED) return true;
        return false;
    }

    private boolean isFireResPotion(ItemStack s) {
        if (!isPotionItem(s)) return false;
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (var e : c.getEffects())
            if (e.getEffectType() == StatusEffects.FIRE_RESISTANCE) return true;
        return false;
    }

    private boolean isGoldenApple(ItemStack s) {
        return !s.isEmpty() && (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE));
    }

    private boolean isEnchantedApple(ItemStack s) {
        return !s.isEmpty() && s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private boolean isThrowable(ItemStack s) {
        return s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION);
    }

    private boolean isPotionItem(ItemStack s) {
        return !s.isEmpty() && (s.isOf(Items.POTION) || s.isOf(Items.SPLASH_POTION)
                || s.isOf(Items.LINGERING_POTION));
    }

    // Usable = potion or golden apple
    private boolean isUsable(ItemStack s) {
        return isPotionItem(s) || isGoldenApple(s);
    }

    private void swapInventoryIntoHotbar(int inventorySlot, int hotbarSlot) {
        if (inventorySlot < 0 || inventorySlot > 35 || hotbarSlot < 0 || hotbarSlot > 8
                || mc.player == null || mc.interactionManager == null) return;
        ScreenHandler h = mc.player.playerScreenHandler;
        mc.interactionManager.clickSlot(h.syncId, inventorySlot, hotbarSlot, SlotActionType.SWAP, mc.player);
    }
}
