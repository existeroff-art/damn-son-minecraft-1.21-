package dev.lumina.module.combat;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Random;

/**
 * TriggerBot with humanised reaction delay.
 *
 * Bypass reasoning:
 *   A bot that fires the instant the crosshair lands has a reaction time of 0 ms —
 *   impossible for a human. Checkers like Grim and Vulcan track the gap between
 *   target acquisition and the first attack; anything under ~60 ms on a consistent
 *   basis is suspicious.
 *
 *   This implementation schedules the attack a random [DelayMin, DelayMax] ms after
 *   the crosshair first hits the target, then re-arms a shorter jitter delay for
 *   consecutive hits so the inter-attack timing also looks natural.
 *
 *   Keep DelayMin ≥ 55 ms and DelayMax ≤ 180 ms for a realistic reaction window.
 */
public class TriggerBot extends Mod {

    private final Setting.Num  cooldown   = add(new Setting.Num ("Cooldown",     "Min attack charge required",       0.90, 0.50, 1.0,  0.01));
    private final Setting.Num  delayMin   = add(new Setting.Num ("Delay Min",    "Min reaction delay (ms)",          60,   0,    300,  5));
    private final Setting.Num  delayMax   = add(new Setting.Num ("Delay Max",    "Max reaction delay (ms)",          130,  0,    500,  5));
    private final Setting.Bool players    = add(new Setting.Bool("Players",      "Target players",                   true));
    private final Setting.Bool mobs       = add(new Setting.Bool("Mobs",         "Target hostile mobs",              true));
    private final Setting.Bool animals    = add(new Setting.Bool("Animals",      "Target passive animals",           false));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only",  "Only while holding a weapon",      true));
    private final Setting.Bool pauseEat   = add(new Setting.Bool("Pause Eating", "Don't trigger while eating/using", true));
    private final Setting.Bool onlyCrits  = add(new Setting.Bool("Only Crits",   "Only on critical hits",            false));
    private final Setting.Bool smart      = add(new Setting.Bool("Smart Crits",  "Hit on ground when possible",      true));

    // Pending attack state
    private long         pendingFireAt = -1;  // System.currentTimeMillis() target
    private LivingEntity pendingTarget = null;

    private final Random rng = new Random();

    public TriggerBot() {
        super("TriggerBot", "Auto-click with humanised reaction delay", Category.COMBAT);
        smart.visible = () -> onlyCrits.value;
    }

    @Override
    public void onDisable() {
        pendingFireAt = -1;
        pendingTarget = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (pauseEat.value  && mc.player.isUsingItem())  { pendingFireAt = -1; return; }
        if (weaponOnly.value && !holdingWeapon())         { pendingFireAt = -1; return; }

        // ── Target check ──
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult ehr)
                || !(ehr.getEntity() instanceof LivingEntity le)
                || !Targets.valid(le, players.value, mobs.value, animals.value)) {
            pendingFireAt = -1;
            pendingTarget = null;
            return;
        }

        // ── New target — arm a randomised reaction delay ──
        if (le != pendingTarget) {
            pendingTarget = le;
            long delay = (long)(delayMin.value + rng.nextDouble() * Math.max(0, delayMax.value - delayMin.value));
            pendingFireAt = System.currentTimeMillis() + delay;
        }

        // ── Wait for reaction time to expire ──
        if (pendingFireAt < 0 || System.currentTimeMillis() < pendingFireAt) return;

        // ── Cooldown and crit checks ──
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        if (!Targets.critOk(onlyCrits.value, smart.value)) return;

        // ── Fire ──
        mc.interactionManager.attackEntity(mc.player, le);
        mc.player.swingHand(Hand.MAIN_HAND);

        // Re-arm a short inter-attack jitter so consecutive CPS also looks natural
        long rearm = (long)(delayMin.value * 0.35 + rng.nextDouble() * delayMin.value * 0.45);
        pendingFireAt = System.currentTimeMillis() + rearm;
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem  || item instanceof AxeItem
            || item instanceof TridentItem || item instanceof BowItem
            || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
