package dev.lumina.module.combat;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TriggerBot extends Mod {
    private final Setting.Num  cooldown   = add(new Setting.Num( "Cooldown",    "Min attack charge required",     0.95, 0.5, 1.0, 0.01));
    private final Setting.Bool players    = add(new Setting.Bool("Players",     "Target players",                 true));
    private final Setting.Bool mobs       = add(new Setting.Bool("Mobs",        "Target hostile mobs",            true));
    private final Setting.Bool animals    = add(new Setting.Bool("Animals",     "Target passive animals",         false));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only", "Only fire when holding a weapon",true));
    private final Setting.Bool pauseEat   = add(new Setting.Bool("Pause Eating","Stop triggering while eating",   true));
    private final Setting.Bool onlyCrits  = add(new Setting.Bool("Only Crits",  "Only on critical hits",          false));
    private final Setting.Bool smart      = add(new Setting.Bool("Smart Crits", "Hit on ground when possible",    true));

    public TriggerBot() {
        super("TriggerBot", "Hits whatever your crosshair is on", Category.COMBAT);
        smart.visible = () -> onlyCrits.value;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;

        // KEY FIX: don't trigger while eating, drinking, charging bow, or using any item
        if (pauseEat.value && mc.player.isUsingItem()) return;

        if (weaponOnly.value && !holdingWeapon()) return;

        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult ehr)) return;
        if (!(ehr.getEntity() instanceof LivingEntity le)) return;
        if (!Targets.valid(le, players.value, mobs.value, animals.value)) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        if (!Targets.critOk(onlyCrits.value, smart.value)) return;

        mc.interactionManager.attackEntity(mc.player, le);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem
            || item instanceof AxeItem
            || item instanceof TridentItem
            || item instanceof BowItem
            || item instanceof CrossbowItem
            || item instanceof MaceItem;
    }
}
