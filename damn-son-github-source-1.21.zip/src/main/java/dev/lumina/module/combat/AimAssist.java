package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Mod {
    private final Setting.Num  range    = add(new Setting.Num("Range",       "Max target distance",            4.0, 1.0,  8.0, 0.1));
    // speed is now a smooth-factor: 1 = very slow, 20 = nearly instant.
    // Old configs stored deg/tick; new values behave differently — reset if it feels off.
    private final Setting.Num  speed    = add(new Setting.Num("Speed",       "Smoothing factor (1–20)",        6.0, 1.0, 20.0, 0.5));
    private final Setting.Num  fov      = add(new Setting.Num("FOV",         "Max angle to lock onto",        90.0,10.0,180.0, 5.0));
    private final Setting.Bool players  = add(new Setting.Bool("Players",    "Target players",                 true));
    private final Setting.Bool mobs     = add(new Setting.Bool("Mobs",       "Target hostile mobs",            true));
    private final Setting.Bool animals  = add(new Setting.Bool("Animals",    "Target passive animals",         false));
    private final Setting.Bool weapOnly = add(new Setting.Bool("Weapon Only","Only when holding a weapon",     true));
    private final Setting.Bool pauseEat = add(new Setting.Bool("Pause Eating","Stop tracking while eating",    true));

    // Target lock — prevents stutter from rapidly flipping between targets
    private LivingEntity locked = null;

    public AimAssist() {
        super("AimAssist", "Smoothly rotates toward nearest entity", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        locked = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (weapOnly.value && !holdingWeapon()) { locked = null; return; }
        if (pauseEat.value && mc.player.isUsingItem()) { locked = null; return; }

        // Validate lock — clear if dead or out of range
        if (locked != null && (!locked.isAlive() || Targets.distance(locked) > range.value + 1.5)) {
            locked = null;
        }

        LivingEntity candidate = findBest();

        if (locked == null) {
            locked = candidate;
        } else if (candidate != null && candidate != locked) {
            // Only switch to a new target if it's SIGNIFICANTLY closer in angle (avoids jitter)
            float curAngle   = angleTo(locked);
            float candAngle  = angleTo(candidate);
            if (candAngle < curAngle * 0.55f) locked = candidate;
        }

        if (locked == null) return;

        Vec3d eye    = mc.player.getEyePos();
        Vec3d center = locked.getBoundingBox().getCenter();
        Vec3d diff   = center.subtract(eye);

        double h2d        = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float  targetYaw  = (float)(Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float  targetPitch= (float)-Math.toDegrees(Math.atan2(diff.y, h2d));

        float curYaw   = mc.player.getYaw();
        float curPitch = mc.player.getPitch();

        float dYaw   = MathHelper.wrapDegrees(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        // Exponential smooth lerp — eliminates the stutter caused by linear step clamping.
        // factor = how much of the remaining delta we close each tick (0..1).
        // speed=1 → factor≈0.048 (very smooth), speed=20 → factor≈0.632 (snappy).
        float factor = (float)(1.0 - Math.exp(-speed.value * 0.05));
        factor = Math.min(factor, 0.95f);

        mc.player.setYaw(curYaw + dYaw * factor);
        mc.player.setPitch(MathHelper.clamp(curPitch + dPitch * factor, -90f, 90f));
    }

    /** Angle (degrees) from current view direction to entity center. */
    private float angleTo(LivingEntity e) {
        Vec3d eye  = mc.player.getEyePos();
        Vec3d diff = e.getBoundingBox().getCenter().subtract(eye);
        double h   = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float tYaw   = (float)(Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float tPitch = (float)-Math.toDegrees(Math.atan2(diff.y, h));
        float dYaw   = Math.abs(MathHelper.wrapDegrees(tYaw - mc.player.getYaw()));
        float dPitch = Math.abs(tPitch - mc.player.getPitch());
        return (float)Math.sqrt(dYaw * dYaw + dPitch * dPitch);
    }

    private LivingEntity findBest() {
        float maxFov = (float)fov.value;
        LivingEntity best = null;
        float bestAngle = maxFov;

        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 1),
                le -> Targets.valid(le, players.value, mobs.value, animals.value))) {
            if (Targets.distance(e) > range.value) continue;
            float a = angleTo(e);
            if (a < bestAngle) { bestAngle = a; best = e; }
        }
        return best;
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem
            || item instanceof AxeItem
            || item instanceof TridentItem
            || item instanceof BowItem
            || item instanceof CrossbowItem
            || item instanceof MaceItem;
    }
}
