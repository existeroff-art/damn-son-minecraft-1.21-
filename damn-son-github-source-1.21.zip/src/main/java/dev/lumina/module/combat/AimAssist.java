package dev.lumina.module.combat;

import dev.lumina.LuminaClient;
import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Legit / Blatant aim assist with GCD bypass.
 *
 * ── Legit Mode ──────────────────────────────────────────────────────────────
 *   Low speed (3–5), small FOV, smooth ease-in-out, momentum blending.
 *   Reads as a skilled player tracking naturally, not a bot.
 *
 * ── Blatant Mode ────────────────────────────────────────────────────────────
 *   Hard snap to target with stutter — exactly what you see in good blatant
 *   aim videos. Fast but not instant; target locks in with slight micro-delays
 *   between correction pulses so it looks like high-sens hand movement, not
 *   a perfect lock. Specifically:
 *
 *     - No momentum blending (snaps don't ease in, they arrive immediately)
 *     - Stutter tick: every N ticks a correction is skipped entirely, so the
 *       crosshair "stutters" past the target before snapping back — looks like
 *       overcorrection from a fast-flick player
 *     - Speed cranked (default 14.0, up to 30.0) — correction per tick is large
 *     - Smooth OFF in blatant: no lerp on target point filtering either
 *     - GCD fix still runs so rotation log looks real
 *
 *   Stutter Freq controls how often a correction tick is skipped (every N ticks).
 *   1 = no stutter (pure snap), 3–5 = visible stutter like the video.
 */
public class AimAssist extends Mod {

    // ── Rotation-lock API ─────────────────────────────────────────────────────
    private static int rotationLockCount;
    public static void acquireRotationLock() { rotationLockCount++; }
    public static void releaseRotationLock() { if (rotationLockCount > 0) rotationLockCount--; }
    public static void clearRotationLocks()  { rotationLockCount = 0; }
    public static boolean isRotationLocked() { return rotationLockCount > 0; }

    // ── Mode ──────────────────────────────────────────────────────────────────
    private final Setting.Mode mode = add(new Setting.Mode(
            "Mode", "Aim style", "Legit", "Blatant"));

    // ── Shared settings ───────────────────────────────────────────────────────
    private final Setting.Num  range      = add(new Setting.Num ("Range",       "Max target distance",                   4.0,  1.0,  8.0,   0.1));
    private final Setting.Num  fov        = add(new Setting.Num ("FOV",         "Target acquisition angle",              65.0, 10.0, 180.0, 5.0));
    private final Setting.Bool predict    = add(new Setting.Bool("Predict",     "Lead target based on velocity",         true));
    private final Setting.Bool gcdFix     = add(new Setting.Bool("GCD Fix",     "Snap rotations to sensitivity GCD",     true));
    private final Setting.Bool focus      = add(new Setting.Bool("Focus",       "Stick to current target",               true));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only", "Only while holding a weapon",           true));
    private final Setting.Mode aimPoint   = add(new Setting.Mode("Aim Point",   "Vertical aim point", "Head", "Chest", "Body"));
    private final Setting.Mode targetMode = add(new Setting.Mode("Target Mode", "Entity types", "Players", "Players + Mobs", "Mobs"));

    // ── Legit-only settings ───────────────────────────────────────────────────
    private final Setting.Num  speed      = add(new Setting.Num ("Speed",       "Aim response strength",                 3.5,  1.0,  20.0, 0.5));
    private final Setting.Num  maxSpeed   = add(new Setting.Num ("Max Speed",   "Max yaw/pitch change per tick (°)",     4.0,  1.0,  30.0, 0.5));
    private final Setting.Num  jitter     = add(new Setting.Num ("Jitter",      "Micro-noise amplitude",                 0.06, 0.0,  0.25, 0.01));
    private final Setting.Bool smooth     = add(new Setting.Bool("Smooth",      "Ease-in-out curve instead of linear",   true));

    // ── Blatant-only settings ─────────────────────────────────────────────────
    private final Setting.Num  blatantSpeed  = add(new Setting.Num ("Blatant Speed",
            "Correction per tick in Blatant mode (°)", 14.0, 5.0, 30.0, 0.5));
    /** Stutter Freq N: skip a correction every N ticks. 1 = no stutter, 3–5 = visible. */
    private final Setting.Num  stutterFreq   = add(new Setting.Num ("Stutter Freq",
            "Skip a correction tick every N ticks (1 = off)", 4.0, 1.0, 10.0, 1.0));

    // ── State ─────────────────────────────────────────────────────────────────
    private LivingEntity locked;
    private Vec3d        filteredPoint;
    private Vec3d        lastEntityPos;
    private float        yawMomentum;
    private float        pitchMomentum;
    private int          lostSightTicks;
    private int          tickCounter;       // blatant stutter counter
    private final Random rng = new Random();

    public AimAssist() {
        super("AimAssist", "Legit / Blatant aim with GCD bypass", Category.COMBAT);

        // Show legit-only settings only when mode == Legit
        speed.visible    = () -> mode.is("Legit");
        maxSpeed.visible = () -> mode.is("Legit");
        jitter.visible   = () -> mode.is("Legit");
        smooth.visible   = () -> mode.is("Legit");

        // Show blatant-only settings only when mode == Blatant
        blatantSpeed.visible = () -> mode.is("Blatant");
        stutterFreq.visible  = () -> mode.is("Blatant");
    }

    @Override public void onEnable()  { reset(); }
    @Override public void onDisable() { reset(); }

    public LivingEntity lockedTarget() { return locked; }

    private void reset() {
        locked         = null;
        filteredPoint  = null;
        lastEntityPos  = null;
        yawMomentum    = 0f;
        pitchMomentum  = 0f;
        lostSightTicks = 0;
        tickCounter    = 0;
    }

    @Override
    public void onTick() {
        if (rotationLockCount > 0) { yawMomentum = pitchMomentum = 0f; return; }
        if (mc.player == null || mc.world == null || mc.currentScreen != null) { reset(); return; }
        if (weaponOnly.value && !holdingWeapon()) { stopMotion(); return; }
        if (mc.player.isUsingItem())               { stopMotion(); return; }

        boolean players = targetMode.is("Players") || targetMode.is("Players + Mobs");
        boolean mobs    = targetMode.is("Mobs")    || targetMode.is("Players + Mobs");

        // ── Target selection ──────────────────────────────────────────────────
        if (!isLockValid(locked, players, mobs)) {
            locked = null; filteredPoint = null; lastEntityPos = null;
            if (focus.value) locked = findBest(players, mobs);
        }
        if (!focus.value) locked = findBest(players, mobs);
        if (locked == null) { stopMotion(); filteredPoint = null; return; }

        // ── Line-of-sight grace period ────────────────────────────────────────
        if (!mc.player.canSee(locked)) {
            lostSightTicks++;
            stopMotion();
            if (lostSightTicks > 4) { locked = null; filteredPoint = null; lostSightTicks = 0; }
            return;
        }
        lostSightTicks = 0;

        // ── Velocity prediction ───────────────────────────────────────────────
        Vec3d currentPos      = locked.getPos();
        Vec3d predictedOffset = Vec3d.ZERO;
        if (predict.value && lastEntityPos != null) {
            Vec3d vel = currentPos.subtract(lastEntityPos);
            predictedOffset = vel.multiply(1.5);
        }
        lastEntityPos = currentPos;

        // ── Target point filtering ────────────────────────────────────────────
        Vec3d desiredPoint = pointFor(locked).add(predictedOffset);
        if (filteredPoint == null) {
            filteredPoint = desiredPoint;
        } else {
            // Legit: smooth lerp. Blatant: hard snap (alpha = 1.0)
            double alpha  = mode.is("Blatant") ? 1.0 : (smooth.value ? 0.28 : 1.0);
            filteredPoint = filteredPoint.lerp(desiredPoint, alpha);
        }

        // ── Compute angle deltas ──────────────────────────────────────────────
        Vec3d  eye        = mc.player.getEyePos();
        Vec3d  delta      = filteredPoint.subtract(eye);
        double horiz      = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float  targetYaw  = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float  targetPitch= (float)-Math.toDegrees(Math.atan2(delta.y, horiz));
        float  yawDelta   = MathHelper.wrapDegrees(targetYaw   - mc.player.getYaw());
        float  pitchDelta = targetPitch - mc.player.getPitch();

        // ── Branch by mode ────────────────────────────────────────────────────
        float finalYaw, finalPitch;

        if (mode.is("Blatant")) {
            finalYaw   = blatantTick(yawDelta,   true);
            finalPitch = blatantTick(pitchDelta,  false);
        } else {
            finalYaw   = legitTick(yawDelta,   pitchDelta);
            finalPitch = legitPitch(pitchDelta, yawDelta);
        }

        // ── GCD snapping ──────────────────────────────────────────────────────
        if (gcdFix.value
                && LuminaClient.modules != null
                && LuminaClient.modules.bypass.enabled) {
            finalYaw   = LuminaClient.modules.bypass.snapYaw(finalYaw);
            finalPitch = LuminaClient.modules.bypass.snapPitch(finalPitch);
        }

        // ── Apply ─────────────────────────────────────────────────────────────
        mc.player.setYaw(mc.player.getYaw() + finalYaw);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + finalPitch, -90f, 90f));
    }

    // ── Blatant correction ────────────────────────────────────────────────────
    /**
     * Hard-snap the full delta, clamped to blatantSpeed.
     * Every stutterFreq ticks, skip the correction entirely — this produces
     * the visible "stutter" where the crosshair momentarily overshoots/lags
     * before snapping back, which reads as high-sens human aim, not a lock.
     */
    private float blatantTick(float delta, boolean isYaw) {
        tickCounter++;

        int freq = (int) Math.max(1, stutterFreq.value);
        if (freq > 1 && tickCounter % freq == 0) {
            // Stutter tick: return zero — correction skipped this tick
            return 0f;
        }

        float cap = (float) blatantSpeed.value;
        return MathHelper.clamp(delta, -cap, cap);
    }

    // ── Legit yaw correction ──────────────────────────────────────────────────
    private float legitTick(float yawDelta, float pitchDelta) {
        float angularErr = (float) Math.hypot(yawDelta, pitchDelta);
        float eased      = smooth.value ? easeInOut(MathHelper.clamp(angularErr / 45f, 0f, 1f)) : 1f;
        float response   = MathHelper.clamp((float)(speed.value / 26.0) * eased, 0.05f, 0.60f);

        float step = MathHelper.clamp(yawDelta * response, -(float)maxSpeed.value, (float)maxSpeed.value);

        yawMomentum = smooth.value
                ? (yawMomentum * 0.22f + step * 0.78f)
                : step;

        if (Math.abs(yawDelta) < 0.04f) yawMomentum = 0f;

        float jAmp = (float) jitter.value;
        if (jAmp > 0f) yawMomentum += (float)(rng.nextGaussian() * jAmp);

        return yawMomentum;
    }

    // ── Legit pitch correction ────────────────────────────────────────────────
    private float legitPitch(float pitchDelta, float yawDelta) {
        float angularErr = (float) Math.hypot(yawDelta, pitchDelta);
        float eased      = smooth.value ? easeInOut(MathHelper.clamp(angularErr / 45f, 0f, 1f)) : 1f;
        float response   = MathHelper.clamp((float)(speed.value / 26.0) * eased, 0.05f, 0.60f);

        float step = MathHelper.clamp(pitchDelta * response, -(float)maxSpeed.value, (float)maxSpeed.value);

        pitchMomentum = smooth.value
                ? (pitchMomentum * 0.22f + step * 0.78f)
                : step;

        if (Math.abs(pitchDelta) < 0.04f) pitchMomentum = 0f;

        float jAmp = (float) jitter.value;
        if (jAmp > 0f) pitchMomentum += (float)(rng.nextGaussian() * jAmp * 0.55f);

        return pitchMomentum;
    }

    // ── Ease in-out (cubic Hermite): slow → fast → slow ──────────────────────
    private static float easeInOut(float t) {
        return t * t * (3f - 2f * t);
    }

    private void stopMotion() { yawMomentum = 0f; pitchMomentum = 0f; }

    private boolean isLockValid(LivingEntity entity, boolean players, boolean mobs) {
        if (entity == null || !entity.isAlive() || entity.getWorld() != mc.world) return false;
        if (!Targets.valid(entity, players, mobs, false)) return false;
        return Targets.distance(entity) <= range.value + 0.5;
    }

    private LivingEntity findBest(boolean players, boolean mobs) {
        LivingEntity best      = null;
        float        bestAngle = (float) fov.value;
        for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 0.5),
                candidate -> Targets.valid(candidate, players, mobs, false))) {
            if (Targets.distance(entity) > range.value || !mc.player.canSee(entity)) continue;
            float angle = angleTo(entity);
            if (angle < bestAngle) { bestAngle = angle; best = entity; }
        }
        return best;
    }

    private Vec3d pointFor(LivingEntity entity) {
        return switch (aimPoint.get()) {
            case "Head"  -> new Vec3d(entity.getX(), entity.getEyeY() - 0.06,              entity.getZ());
            case "Chest" -> new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.62, entity.getZ());
            default      -> new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.50, entity.getZ());
        };
    }

    private float angleTo(LivingEntity entity) {
        Vec3d  delta = pointFor(entity).subtract(mc.player.getEyePos());
        double horiz = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float  yaw   = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float  pitch = (float)-Math.toDegrees(Math.atan2(delta.y, horiz));
        return (float) Math.hypot(
                Math.abs(MathHelper.wrapDegrees(yaw   - mc.player.getYaw())),
                Math.abs(pitch - mc.player.getPitch()));
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem
            || item instanceof TridentItem || item instanceof BowItem
            || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
