package dev.lumina.module.combat;

import dev.lumina.LuminaClient;
import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Blatant + smooth aim controller with GCD bypass.
 *
 * What "blatant + smooth" means here:
 *   Blatant — aggressive defaults (range 5.5, speed 14, FOV 180). It tracks
 *             hard and fast; the aim visibly snaps toward targets.
 *   Smooth  — eased response curve + velocity prediction so the motion looks
 *             intentional rather than mechanical.
 *   Bypass  — every rotation delta is snapped to the player's sensitivity GCD
 *             (via the Bypass module) so changelogs look identical to real mouse
 *             input. Grim and Vulcan both check rotation delta distribution;
 *             non-GCD deltas are the most common flag for combat heuristics.
 *
 * GCD Fix only applies when the Bypass module is enabled. Move your mouse
 * normally for ~20 ticks after enabling Bypass so it can calibrate.
 */
public class AimAssist extends Mod {

    // ── Rotation-lock API (used by AutoPot and any future module that owns the camera) ──
    private static int rotationLockCount;
    public static void acquireRotationLock()  { rotationLockCount++; }
    public static void releaseRotationLock()  { if (rotationLockCount > 0) rotationLockCount--; }
    public static void clearRotationLocks()   { rotationLockCount = 0; }
    public static boolean isRotationLocked()  { return rotationLockCount > 0; }

    // ── Settings — blatant defaults ──
    private final Setting.Num  range      = add(new Setting.Num ("Range",      "Max target distance",                5.5,  1.0,  8.0, 0.1));
    private final Setting.Num  speed      = add(new Setting.Num ("Speed",      "Aim response strength",              14.0, 1.0,  20.0, 0.5));
    private final Setting.Num  maxSpeed   = add(new Setting.Num ("Max Speed",  "Max yaw/pitch change per tick (°)",  22.0, 1.0,  30.0, 1.0));
    private final Setting.Num  fov        = add(new Setting.Num ("FOV",        "Target acquisition angle",           180.0,10.0, 180.0, 5.0));
    private final Setting.Num  jitter     = add(new Setting.Num ("Jitter",     "Micro-noise amplitude (humanises pattern)", 0.03, 0.0, 0.20, 0.01));
    private final Setting.Bool smooth     = add(new Setting.Bool("Smooth",     "Ease-in-out curve instead of linear",  true));
    private final Setting.Bool predict    = add(new Setting.Bool("Predict",    "Lead target based on velocity",         true));
    private final Setting.Bool gcdFix     = add(new Setting.Bool("GCD Fix",   "Snap rotations to sensitivity GCD (requires Bypass)", true));
    private final Setting.Bool focus      = add(new Setting.Bool("Focus",      "Stick to current target",               true));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only","Only while holding a weapon",           true));
    private final Setting.Mode aimPoint   = add(new Setting.Mode("Aim Point",  "Vertical aim point", "Head", "Chest", "Body"));
    private final Setting.Mode targetMode = add(new Setting.Mode("Target Mode","Entity types", "Players", "Players + Mobs", "Mobs"));

    // ── State ──
    private LivingEntity locked;
    private Vec3d        filteredPoint;
    private Vec3d        lastEntityPos;
    private float        yawMomentum;
    private float        pitchMomentum;
    private int          lostSightTicks;
    private final Random rng = new Random();

    public AimAssist() {
        super("AimAssist", "Blatant + smooth aim with GCD bypass", Category.COMBAT);
    }

    @Override public void onEnable()  { reset(); }
    @Override public void onDisable() { reset(); }

    public LivingEntity lockedTarget() { return locked; }

    private void reset() {
        locked        = null;
        filteredPoint = null;
        lastEntityPos = null;
        yawMomentum   = 0f;
        pitchMomentum = 0f;
        lostSightTicks = 0;
    }

    @Override
    public void onTick() {
        if (rotationLockCount > 0) { yawMomentum = pitchMomentum = 0f; return; }
        if (mc.player == null || mc.world == null || mc.currentScreen != null) { reset(); return; }
        if (weaponOnly.value && !holdingWeapon()) { stopMotion(); return; }
        if (mc.player.isUsingItem())               { stopMotion(); return; }

        boolean players = targetMode.is("Players") || targetMode.is("Players + Mobs");
        boolean mobs    = targetMode.is("Mobs")    || targetMode.is("Players + Mobs");

        // ── Target selection ──
        if (!isLockValid(locked, players, mobs)) {
            locked = null; filteredPoint = null; lastEntityPos = null;
            if (focus.value) locked = findBest(players, mobs);
        }
        if (!focus.value) locked = findBest(players, mobs);
        if (locked == null) { stopMotion(); filteredPoint = null; return; }

        // ── Line-of-sight grace period ──
        if (!mc.player.canSee(locked)) {
            lostSightTicks++;
            stopMotion();
            if (lostSightTicks > 4) { locked = null; filteredPoint = null; lostSightTicks = 0; }
            return;
        }
        lostSightTicks = 0;

        // ── Velocity prediction — lead the target ~1.8 ticks ahead ──
        Vec3d currentPos       = locked.getPos();
        Vec3d predictedOffset  = Vec3d.ZERO;
        if (predict.value && lastEntityPos != null) {
            Vec3d vel = currentPos.subtract(lastEntityPos);
            predictedOffset = vel.multiply(1.8);
        }
        lastEntityPos = currentPos;

        // ── Filter target point (reduces jitter from target motion) ──
        Vec3d desiredPoint = pointFor(locked).add(predictedOffset);
        if (filteredPoint == null) {
            filteredPoint = desiredPoint;
        } else {
            double alpha  = smooth.value ? 0.36 : 1.0;
            filteredPoint = filteredPoint.lerp(desiredPoint, alpha);
        }

        // ── Compute angle deltas ──
        Vec3d eye        = mc.player.getEyePos();
        Vec3d delta      = filteredPoint.subtract(eye);
        double horiz     = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw  = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch= (float)-Math.toDegrees(Math.atan2(delta.y, horiz));
        float yawDelta   = MathHelper.wrapDegrees(targetYaw   - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        // ── Ease-in-out response: slow when close (smooth finish), fast mid-range ──
        float angularErr  = (float)Math.hypot(yawDelta, pitchDelta);
        float eased       = smooth.value ? easeInOut(MathHelper.clamp(angularErr / 45f, 0f, 1f)) : 1f;
        float response    = MathHelper.clamp((float)(speed.value / 26.0) * eased, 0.08f, 0.76f);

        float yawStep    = MathHelper.clamp(yawDelta   * response, -(float)maxSpeed.value, (float)maxSpeed.value);
        float pitchStep  = MathHelper.clamp(pitchDelta * response, -(float)maxSpeed.value, (float)maxSpeed.value);

        // ── Momentum smoothing ──
        if (smooth.value) {
            yawMomentum   = yawMomentum   * 0.13f + yawStep   * 0.87f;
            pitchMomentum = pitchMomentum * 0.13f + pitchStep * 0.87f;
        } else {
            yawMomentum   = yawStep;
            pitchMomentum = pitchStep;
        }

        // Dead-zone — kill micro-stutter when already on target
        if (Math.abs(yawDelta)   < 0.05f) yawMomentum   = 0f;
        if (Math.abs(pitchDelta) < 0.05f) pitchMomentum = 0f;

        // ── Micro-jitter — breaks pattern recognisers that watch for pixel-perfect tracking ──
        float jAmp = (float)jitter.value;
        if (jAmp > 0f) {
            yawMomentum   += (float)(rng.nextGaussian() * jAmp);
            pitchMomentum += (float)(rng.nextGaussian() * jAmp * 0.55f);
        }

        // ── GCD snapping — align to sensitivity grid so deltas look like real mouse input ──
        float finalYaw   = yawMomentum;
        float finalPitch = pitchMomentum;
        if (gcdFix.value
                && LuminaClient.modules != null
                && LuminaClient.modules.bypass.enabled) {
            finalYaw   = LuminaClient.modules.bypass.snapYaw(finalYaw);
            finalPitch = LuminaClient.modules.bypass.snapPitch(finalPitch);
        }

        // ── Apply ──
        mc.player.setYaw(mc.player.getYaw() + finalYaw);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + finalPitch, -90f, 90f));
    }

    // ── Ease in-out (cubic Hermite): slow → fast → slow ──
    private static float easeInOut(float t) {
        return t * t * (3f - 2f * t);
    }

    private void stopMotion() { yawMomentum = 0f; pitchMomentum = 0f; }

    private boolean isLockValid(LivingEntity entity, boolean players, boolean mobs) {
        if (entity == null || !entity.isAlive() || entity.getWorld() != mc.world) return false;
        if (!Targets.valid(entity, players, mobs, false)) return false;
        return Targets.distance(entity) <= range.value + 0.5;
    }

    private LivingEntity findBest(boolean players, boolean mobs) {
        LivingEntity best      = null;
        float        bestAngle = (float)fov.value;
        for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 0.5),
                candidate -> Targets.valid(candidate, players, mobs, false))) {
            if (Targets.distance(entity) > range.value || !mc.player.canSee(entity)) continue;
            float angle = angleTo(entity);
            if (angle < bestAngle) { bestAngle = angle; best = entity; }
        }
        return best;
    }

    private Vec3d pointFor(LivingEntity entity) {
        return switch (aimPoint.get()) {
            case "Head"  -> new Vec3d(entity.getX(), entity.getEyeY() - 0.06,             entity.getZ());
            case "Chest" -> new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.62, entity.getZ());
            default      -> new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.50, entity.getZ());
        };
    }

    private float angleTo(LivingEntity entity) {
        Vec3d delta  = pointFor(entity).subtract(mc.player.getEyePos());
        double horiz = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw    = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch  = (float)-Math.toDegrees(Math.atan2(delta.y, horiz));
        return (float)Math.hypot(Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw())),
                                 Math.abs(pitch - mc.player.getPitch()));
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem
            || item instanceof TridentItem || item instanceof BowItem
            || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
