package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Single-owner, sticky aim controller. Defaults mirror the visible settings in the supplied clip. */
public class AimAssist extends Mod {
    private static int rotationLockCount;

    public static void acquireRotationLock() { rotationLockCount++; }
    public static void releaseRotationLock() { if (rotationLockCount > 0) rotationLockCount--; }
    public static void clearRotationLocks() { rotationLockCount = 0; }
    public static boolean isRotationLocked() { return rotationLockCount > 0; }

    private final Setting.Num range = add(new Setting.Num("Range", "Maximum target distance", 4.5, 1.0, 8.0, 0.1));
    private final Setting.Num speed = add(new Setting.Num("Speed", "Aim response", 10.0, 1.0, 20.0, 0.5));
    private final Setting.Num maxSpeed = add(new Setting.Num("Max Speed", "Maximum yaw/pitch change per tick", 15.0, 1.0, 30.0, 1.0));
    private final Setting.Num fov = add(new Setting.Num("FOV", "Target acquisition angle", 175.0, 10.0, 180.0, 5.0));
    private final Setting.Bool smooth = add(new Setting.Bool("Smooth Rotation", "Use damped movement rather than abrupt angle jumps", true));
    private final Setting.Bool focus = add(new Setting.Bool("Focus Mode", "Keep the current target until it becomes invalid", true));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only", "Only adjust aim while holding a weapon", true));
    private final Setting.Mode aimPoint = add(new Setting.Mode("Aim Point", "Vertical target point", "Head", "Chest"));
    private final Setting.Mode targetMode = add(new Setting.Mode("Target Mode", "Eligible entity types", "Players", "Players + Mobs", "Mobs"));

    private LivingEntity locked;
    private Vec3d filteredPoint;
    private float yawMomentum;
    private float pitchMomentum;
    private int lostSightTicks;

    public AimAssist() {
        super("AimAssist", "Sticky target aim with damped camera updates", Category.COMBAT);
    }

    @Override public void onEnable() { reset(); }
    @Override public void onDisable() { reset(); }

    public LivingEntity lockedTarget() { return locked; }

    private void reset() {
        locked = null;
        filteredPoint = null;
        yawMomentum = 0.0f;
        pitchMomentum = 0.0f;
        lostSightTicks = 0;
    }

    @Override
    public void onTick() {
        if (rotationLockCount > 0) {
            yawMomentum = pitchMomentum = 0.0f;
            return;
        }
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            reset();
            return;
        }
        if (weaponOnly.value && !holdingWeapon()) {
            stopMotion();
            return;
        }
        if (mc.player.isUsingItem()) {
            stopMotion();
            return;
        }

        boolean players = targetMode.is("Players") || targetMode.is("Players + Mobs");
        boolean mobs = targetMode.is("Mobs") || targetMode.is("Players + Mobs");

        if (!isLockValid(locked, players, mobs)) {
            locked = null;
            filteredPoint = null;
            if (focus.value) locked = findBest(players, mobs);
        }
        if (!focus.value) locked = findBest(players, mobs);
        if (locked == null) {
            stopMotion();
            filteredPoint = null;
            return;
        }

        // If sight is briefly lost, pause rotation instead of jumping to another nearby target.
        if (!mc.player.canSee(locked)) {
            lostSightTicks++;
            stopMotion();
            if (lostSightTicks > 4) {
                locked = null;
                filteredPoint = null;
                lostSightTicks = 0;
            }
            return;
        }
        lostSightTicks = 0;

        Vec3d desiredPoint = pointFor(locked);
        if (filteredPoint == null) filteredPoint = desiredPoint;
        else {
            // Filtering target coordinates, rather than camera input, reduces target-motion jitter.
            double pointAlpha = smooth.value ? 0.42 : 1.0;
            filteredPoint = filteredPoint.lerp(desiredPoint, pointAlpha);
        }

        Vec3d delta = filteredPoint.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        float response = smooth.value
                ? MathHelper.clamp((float) (speed.value / 26.0), 0.12f, 0.62f)
                : 1.0f;
        float yawStep = MathHelper.clamp(yawDelta * response, (float)-maxSpeed.value, (float)maxSpeed.value);
        float pitchStep = MathHelper.clamp(pitchDelta * response, (float)-maxSpeed.value, (float)maxSpeed.value);

        // Small deterministic damping only; no randomized timing/rotation intended to disguise automation.
        if (smooth.value) {
            yawMomentum = yawMomentum * 0.18f + yawStep * 0.82f;
            pitchMomentum = pitchMomentum * 0.18f + pitchStep * 0.82f;
        } else {
            yawMomentum = yawStep;
            pitchMomentum = pitchStep;
        }
        if (Math.abs(yawDelta) < 0.06f) yawMomentum = 0.0f;
        if (Math.abs(pitchDelta) < 0.06f) pitchMomentum = 0.0f;

        mc.player.setYaw(mc.player.getYaw() + yawMomentum);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchMomentum, -90.0f, 90.0f));
    }

    private void stopMotion() {
        yawMomentum = 0.0f;
        pitchMomentum = 0.0f;
    }

    private boolean isLockValid(LivingEntity entity, boolean players, boolean mobs) {
        if (entity == null || !entity.isAlive() || entity.getWorld() != mc.world) return false;
        if (!Targets.valid(entity, players, mobs, false)) return false;
        return Targets.distance(entity) <= range.value + 0.5;
    }

    private LivingEntity findBest(boolean players, boolean mobs) {
        LivingEntity best = null;
        float bestAngle = (float) fov.value;
        for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 0.5),
                candidate -> Targets.valid(candidate, players, mobs, false))) {
            if (Targets.distance(entity) > range.value || !mc.player.canSee(entity)) continue;
            float angle = angleTo(entity);
            if (angle < bestAngle) {
                bestAngle = angle;
                best = entity;
            }
        }
        return best;
    }

    private Vec3d pointFor(LivingEntity entity) {
        if (aimPoint.is("Head")) return new Vec3d(entity.getX(), entity.getEyeY() - 0.08, entity.getZ());
        return new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.62, entity.getZ());
    }

    private float angleTo(LivingEntity entity) {
        Vec3d delta = pointFor(entity).subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yawDelta = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
        float pitchDelta = Math.abs(pitch - mc.player.getPitch());
        return (float)Math.hypot(yawDelta, pitchDelta);
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem
                || item instanceof BowItem || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
