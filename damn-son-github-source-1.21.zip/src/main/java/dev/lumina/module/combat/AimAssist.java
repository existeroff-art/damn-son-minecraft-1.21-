package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Sticky aim assist with velocity lead and bounded, damped rotation updates. */
public class AimAssist extends Mod {
    /** Other combat sequences may temporarily own the camera rotation. */
    private static int rotationLockCount;

    public static void acquireRotationLock() { rotationLockCount++; }
    public static void releaseRotationLock() { if (rotationLockCount > 0) rotationLockCount--; }
    public static void clearRotationLocks() { rotationLockCount = 0; }
    public static boolean isRotationLocked() { return rotationLockCount > 0; }
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum target distance", 4.0, 1.0, 8.0, 0.1));
    private final Setting.Num speed = add(new Setting.Num("Speed", "Rotation response; lower is smoother", 3.0, 1.0, 15.0, 0.5));
    private final Setting.Num fov = add(new Setting.Num("FOV", "Maximum acquisition angle", 75.0, 10.0, 180.0, 5.0));
    private final Setting.Num prediction = add(new Setting.Num("Prediction", "Small target velocity lead in ticks", 0.25, 0.0, 1.5, 0.05));
    private final Setting.Bool players = add(new Setting.Bool("Players", "Target players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Target hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Target passive animals", false));
    private final Setting.Bool weapOnly = add(new Setting.Bool("Weapon Only", "Only when holding a weapon", true));
    private final Setting.Bool pauseEat = add(new Setting.Bool("Pause Eating", "Pause while using an item", true));
    private final Setting.Bool onlyAttack = add(new Setting.Bool("Only While Attacking", "Only adjust aim while attack input is held", false));

    private LivingEntity locked;
    private float yawVelocity;
    private float pitchVelocity;
    private Vec3d filteredAimPoint;

    public AimAssist() {
        super("AimAssist", "Smooth, sticky aim with target motion prediction", Category.COMBAT);
    }

    @Override public void onEnable() { resetTracking(); }
    @Override public void onDisable() { resetTracking(); }

    public LivingEntity lockedTarget() { return locked; }

    private void resetTracking() {
        locked = null;
        yawVelocity = 0.0f;
        pitchVelocity = 0.0f;
        filteredAimPoint = null;
    }

    @Override
    public void onTick() {
        if (rotationLockCount > 0) {
            yawVelocity = 0.0f;
            pitchVelocity = 0.0f;
            filteredAimPoint = null;
            return;
        }
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            resetTracking();
            return;
        }
        if (weapOnly.value && !holdingWeapon()) {
            yawVelocity = 0.0f; pitchVelocity = 0.0f; filteredAimPoint = null; return;
        }
        if (pauseEat.value && mc.player.isUsingItem()) {
            yawVelocity = 0.0f; pitchVelocity = 0.0f; filteredAimPoint = null; return;
        }
        if (onlyAttack.value && !mc.options.attackKey.isPressed()) {
            yawVelocity = 0.0f; pitchVelocity = 0.0f; filteredAimPoint = null; return;
        }

        if (!isLockValid(locked)) {
            LivingEntity candidate = findBest();
            if (candidate != locked) {
                yawVelocity = 0.0f;
                pitchVelocity = 0.0f;
                filteredAimPoint = null;
            }
            locked = candidate;
        }
        if (locked == null) {
            yawVelocity = 0.0f;
            pitchVelocity = 0.0f;
            filteredAimPoint = null;
            return;
        }

        // Keep prediction deliberately short: large knockback velocity changes can otherwise
        // make the target point jump back and forth and appear as camera stutter.
        double leadTicks = MathHelper.clamp(prediction.value, 0.0, 1.5);
        Vec3d lead = locked.getVelocity().multiply(leadTicks);
        double leadLength = lead.length();
        if (leadLength > 0.28) lead = lead.multiply(0.28 / leadLength);
        Vec3d predicted = locked.getPos().add(lead);
        Vec3d desiredPoint = new Vec3d(predicted.x, predicted.y + locked.getHeight() * 0.62, predicted.z);
        if (filteredAimPoint == null) {
            filteredAimPoint = desiredPoint;
        } else {
            Vec3d pointDelta = desiredPoint.subtract(filteredAimPoint);
            double pointDistance = pointDelta.length();
            if (pointDistance > 0.55) pointDelta = pointDelta.multiply(0.55 / pointDistance);
            // Low-pass the target point before calculating angles to absorb per-tick velocity spikes.
            filteredAimPoint = filteredAimPoint.add(pointDelta.multiply(0.62));
        }
        Vec3d diff = filteredAimPoint.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        if (Math.abs(yawDelta) < 0.08f) yawDelta = 0.0f;
        if (Math.abs(pitchDelta) < 0.08f) pitchDelta = 0.0f;

        // A damped proportional controller avoids oscillation around fast-moving targets.
        float alpha = (float) (1.0 - Math.exp(-Math.max(1.0, speed.value) * 0.035));
        alpha = MathHelper.clamp(alpha, 0.035f, 0.28f);
        float desiredYaw = yawDelta * alpha;
        float desiredPitch = pitchDelta * alpha;
        float maxYawStep = Math.min(4.2f, 1.2f + (float) speed.value * 0.62f);
        float maxPitchStep = Math.min(2.8f, 0.7f + (float) speed.value * 0.4f);
        desiredYaw = MathHelper.clamp(desiredYaw, -maxYawStep, maxYawStep);
        desiredPitch = MathHelper.clamp(desiredPitch, -maxPitchStep, maxPitchStep);

        // Keep very little momentum: large velocity carry-over causes overshoot when the
        // target changes direction or gets hit by knockback.
        yawVelocity = yawVelocity * 0.10f + desiredYaw * 0.90f;
        pitchVelocity = pitchVelocity * 0.10f + desiredPitch * 0.90f;
        if (Math.abs(yawDelta) < 0.15f) yawVelocity = 0.0f;
        if (Math.abs(pitchDelta) < 0.15f) pitchVelocity = 0.0f;

        mc.player.setYaw(mc.player.getYaw() + yawVelocity);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchVelocity, -90.0f, 90.0f));
    }

    private boolean isLockValid(LivingEntity e) {
        return e != null && e.isAlive() && e.getWorld() == mc.world
                && Targets.valid(e, players.value, mobs.value, animals.value)
                && Targets.distance(e) <= range.value + 1.25;
    }

    private LivingEntity findBest() {
        LivingEntity best = null;
        float bestAngle = (float) fov.value;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 1.0),
                le -> Targets.valid(le, players.value, mobs.value, animals.value))) {
            if (Targets.distance(e) > range.value) continue;
            float angle = angleTo(e);
            if (angle < bestAngle) {
                bestAngle = angle;
                best = e;
            }
        }
        return best;
    }

    private float angleTo(LivingEntity e) {
        Vec3d lead = e.getVelocity().multiply(MathHelper.clamp(prediction.value, 0.0, 1.5));
        double leadLength = lead.length();
        if (leadLength > 0.28) lead = lead.multiply(0.28 / leadLength);
        Vec3d predicted = e.getPos().add(lead);
        Vec3d point = new Vec3d(predicted.x, predicted.y + e.getHeight() * 0.62, predicted.z);
        Vec3d diff = point.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float dy = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
        float dp = Math.abs(pitch - mc.player.getPitch());
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem
                || item instanceof BowItem || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
