package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Sticky target lock with exponential rotation smoothing. */
public class AimAssist extends Mod {
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum target distance", 4.0, 1.0, 8.0, 0.1));
    private final Setting.Num speed = add(new Setting.Num("Speed", "Rotation smoothing; lower is smoother", 4.5, 1.0, 15.0, 0.5));
    private final Setting.Num fov = add(new Setting.Num("FOV", "Maximum acquisition angle", 75.0, 10.0, 180.0, 5.0));
    private final Setting.Bool players = add(new Setting.Bool("Players", "Target players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Target hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Target passive animals", false));
    private final Setting.Bool weapOnly = add(new Setting.Bool("Weapon Only", "Only when holding a weapon", true));
    private final Setting.Bool pauseEat = add(new Setting.Bool("Pause Eating", "Pause while using an item", true));

    private LivingEntity locked;

    public AimAssist() {
        super("AimAssist", "Smooth aim with a sticky target lock", Category.COMBAT);
    }

    @Override public void onEnable() { locked = null; }
    @Override public void onDisable() { locked = null; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (weapOnly.value && !holdingWeapon()) return;
        if (pauseEat.value && mc.player.isUsingItem()) return;

        if (!isLockValid(locked)) locked = findBest();
        if (locked == null) return;

        // Aim at a stable upper-torso point rather than the moving box center.
        var box = locked.getBoundingBox();
        Vec3d point = new Vec3d((box.minX + box.maxX) * 0.5,
                box.minY + locked.getHeight() * 0.62,
                (box.minZ + box.maxZ) * 0.5);
        Vec3d diff = point.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        if (Math.abs(yawDelta) < 0.025f) yawDelta = 0;
        if (Math.abs(pitchDelta) < 0.025f) pitchDelta = 0;

        // Exponential smoothing avoids the abrupt, frame-dependent stepping that caused jitter.
        float alpha = (float) (1.0 - Math.exp(-speed.value * 0.075));
        alpha = MathHelper.clamp(alpha, 0.04f, 0.78f);
        mc.player.setYaw(mc.player.getYaw() + yawDelta * alpha);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchDelta * alpha, -90f, 90f));
    }

    private boolean isLockValid(LivingEntity e) {
        return e != null && e.isAlive() && e.getWorld() == mc.world
                && Targets.valid(e, players.value, mobs.value, animals.value)
                && Targets.distance(e) <= range.value + 1.25;
    }

    private LivingEntity findBest() {
        LivingEntity best = null;
        float bestAngle = (float) fov.value;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.value + 1.0),
                le -> Targets.valid(le, players.value, mobs.value, animals.value))) {
            if (Targets.distance(e) > range.value) continue;
            float angle = angleTo(e);
            if (angle < bestAngle) {
                bestAngle = angle;
                best = e;
            }
        }
        return best;
    }

    private float angleTo(LivingEntity e) {
        var box = e.getBoundingBox();
        Vec3d point = new Vec3d((box.minX + box.maxX) * 0.5,
                box.minY + e.getHeight() * 0.62,
                (box.minZ + box.maxZ) * 0.5);
        Vec3d diff = point.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float dy = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
        float dp = Math.abs(pitch - mc.player.getPitch());
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem
                || item instanceof BowItem || item instanceof CrossbowItem || item instanceof MaceItem;
    }
}
