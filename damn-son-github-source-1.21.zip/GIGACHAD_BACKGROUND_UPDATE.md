# UI redesign (v0.6.6)

- Removed the old anime/GigaChad background and legacy logo assets from the screen.
- Added a compact dark interface with calm grid lines, teal/purple accents, custom flat button rendering, and hover/selected states.
- Added distinct note-block chime/bass sounds for module enable/disable and a softer UI click.
- Preserved Right Shift, category navigation, scroll controls, module keybind capture, settings, and config actions.
