# Aim and potion bug notes — v0.7.3

## Aim Assist stutter

The old path modified yaw/pitch from `ClientTickEvents.END_CLIENT_TICK`, so all camera corrections were applied at 20 TPS. At high configured strength, each tick could apply a large fraction of the remaining angle, which looked like stepped or snapping movement. The new path applies time-based exponential convergence from the render callback and aims at the entity's interpolated position. Target acquisition remains on the client tick and is throttled when no target exists; it does not rescan/sort the nearby entity list every frame.

This is a visual/response-time correction, not an anti-cheat bypass. No random rotation, packet spoofing, sensitivity spoofing, or anti-cheat-specific behavior was introduced.

## Auto Potion / Pot Refill

The previous implementation changed pitch/selected slot and immediately sent item use in the same END_CLIENT_TICK call, then restored them immediately. That ordering can mean the use packet reaches the server before the next movement update carrying the downward pitch and selected slot. The staged implementation keeps the temporary state through the following tick, performs the use, restores the view and selected slot, and restores borrowed inventory swaps only under the correct player inventory handler.

Pot Refill still observes emptied hotbar potion slots and replaces them with a matching splash-potion stack from the main inventory. Test on a local world because server-side slot validation and plugin behavior vary.
