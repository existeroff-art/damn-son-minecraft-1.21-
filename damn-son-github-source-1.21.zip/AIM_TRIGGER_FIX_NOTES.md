# Aim/weapon update notes — v0.7.4

- Removed Aim Assist writes from the HUD rendering callback to avoid modifying yaw/pitch after the world camera frame.
- Aim Assist uses client-tick steering with vanilla interpolation for camera presentation.
- Added selectable target point (Head / Chest / Body) with Head as the default.
- Added a weapons-only filter to prevent steering when the main hand is not a combat weapon.
- Added Auto Weapon slot choice for mace-fall, shield-block/axe, and default-sword cases, with guarded restore behavior.
- Aim candidate scoring now uses the selected target point.

This note describes source behavior, not an in-game smoothness guarantee. Validate the compiled JAR on the intended Minecraft/Fabric profile.


## v0.7.5 follow-up
The aim-point control is now a three-button selector (HEAD/CHEST/BODY), not a slider. Aim Assist uses a stronger high-strength response curve; strength 98–100 snaps to the selected point on each client tick. In-game smoothness still requires testing at the target Minecraft/Fabric version.
