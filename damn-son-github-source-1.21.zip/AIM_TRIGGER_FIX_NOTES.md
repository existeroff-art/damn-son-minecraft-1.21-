# Aim Assist / Trigger Bot update (v0.7.0)

- Aim Assist is now labelled clearly and uses continuous eased rotation with configurable range, FOV, and smoothing. The target is revalidated for removal, distance, and angle limits.
- Trigger Bot now exposes an adjustable 0–10 tick acquisition delay (default 2 ticks), saved in the config. Vanilla attack cooldown gates subsequent swings, avoiding the old additional long interval.
- Aura Criticals now wait until downward motion before attempting the strike.
- The compact UI exposes these values in a right-click settings panel.

A Gradle build and in-game test have not been completed in this environment. Check the GitHub Actions run before installing the generated JAR.
