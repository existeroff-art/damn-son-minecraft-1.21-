# Aim Assist / Trigger Bot update

Updated `src/main/java/com/damnson/client/UtilityModules.java`:

- Increased Aim Bot tracking response substantially. The default Smooth value (30) now applies roughly a 30% correction to the remaining angle each tick, instead of about 5%.
- Kept continuous interpolation and per-axis step caps so larger corrections ease in instead of becoming a single hard snap.
- Removed aim jitter; yaw and pitch remain stable.
- Aim point moved to the torso and uses a small movement lead for better tracking of strafing targets.
- Updated the module descriptions in `ModuleCatalog.java`.
- Trigger Bot logic is unchanged from the previous ZIP; no extra attack automation was added in this update.

**Verification:** ZIP contents and Java source structure were checked. A Gradle build and in-game test have not been run here, so build/runtime success is not claimed. Use the repository's GitHub Actions workflow to compile the project.
