# Aim/Trigger and UI notes — v0.7.9

- Aim target acquisition remains in the client tick. Aim correction now uses elapsed render-frame time and interpolated camera position to avoid the visible stepping caused by a fixed 20 Hz correction.
- Entity candidates are chosen in one pass instead of allocating/sorting a temporary candidate list.
- Trigger Bot's existing crosshair, configured-range, tick-delay, and vanilla attack-cooldown checks were retained; unrelated kill-effect handling was removed with the other retired feature code.
- Aim Assist settings use independent scrolling. The selected Aim Point and Weapons Only rows are hit-tested at their scrolled render positions.
- Slider file writes happen once on release, not each drag frame.

No settings were copied from the missing third clip; only two gameplay videos were attached in this turn. Build and live stutter behavior are not confirmed until a Gradle build and in-game test are run.
