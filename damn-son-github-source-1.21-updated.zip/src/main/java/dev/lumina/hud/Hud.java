package dev.lumina.hud;

import dev.lumina.LuminaClient;
import dev.lumina.module.Mod;
import dev.lumina.module.render.HudModule;
import dev.lumina.render.Render2D;
import dev.lumina.render.Theme;
import dev.lumina.util.Anim;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Hud {
    private static long last = System.nanoTime();
    private static final int GRAY = 0xFF9A9AA8;

    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;

        if (LuminaClient.modules == null || mc.player == null || mc.options.hudHidden) return;
        HudModule h = LuminaClient.modules.hud;

        List<Mod> list = new ArrayList<>();
        for (Mod m : LuminaClient.modules.all) {
            m.hudAnim = Anim.approach(m.hudAnim, m.enabled ? 1f : 0f, 12f, dt);
            if (!m.hudHidden && m.hudAnim > 0.01f) list.add(m);
        }
        if (!h.enabled) return;

        float scale = 0.9f;
        if (h.arrayList.value) {
            boolean suf = h.suffix.value;
            list.sort(Comparator.comparingDouble((Mod m) -> -(Render2D.width(m.name, scale)
                    + (suf && !m.suffix().isEmpty() ? Render2D.width(m.suffix(), scale) : 0))));

            float sw = mc.getWindow().getScaledWidth();
            float y = 5f;
            double time = System.currentTimeMillis() / 1000.0;
            int idx = 0;
            for (Mod m : list) {
                float a = Anim.easeOut(m.hudAnim);
                String s = suf ? m.suffix() : "";
                float nameW = Render2D.width(m.name, scale);
                float sufW = s.isEmpty() ? 0 : Render2D.width(s, scale) + 4;
                float bw = nameW + sufW + 12;
                float rowH = 13f;
                float x = sw - 5 - bw + (1f - a) * (bw + 10);
                int col = Render2D.lerp(Theme.a1(), Theme.a2(), (float) ((Math.sin(time * 1.5 + idx * 0.4) + 1) / 2));

                if (h.background.value) {
                    Render2D.fill(ctx, x, y, bw, rowH - 1, 4, Render2D.mulAlpha(0xD00B0B10, a));
                }
                Render2D.fill(ctx, x + bw - 3.5f, y + 2.5f, 2f, rowH - 6, 1f, Render2D.mulAlpha(col, a));
                int nameCol = Render2D.lerp(0xFFFFFFFF, col, 0.4f);
                Render2D.text(ctx, m.name, x + 5, y + 2.6f, Render2D.mulAlpha(nameCol, a), scale);
                if (!s.isEmpty()) Render2D.text(ctx, s, x + 5 + nameW + 4, y + 2.6f, Render2D.mulAlpha(GRAY, a), scale);

                y += rowH * a;
                idx++;
            }
        }

        if (h.watermark.value) {
            String name = "Lumina";
            String info = mc.getCurrentFps() + " fps";
            float nw = Render2D.width(name, 1f), iw = Render2D.width(info, 0.85f);
            float w = nw + iw + 26;
            Render2D.fill(ctx, 6, 6, w, 17, 8.5f, 0xD00B0B10);
            Render2D.rect(ctx, 6, 6, w, 17, 8.5f, Theme.a1(), Theme.a2(), Theme.a2(), Theme.a1(), 0f, 1f);
            Render2D.text(ctx, name, 14, 11, Theme.flow(0), 1f);
            Render2D.fill(ctx, 14 + nw + 5, 10, 1, 9, 0.5f, 0x40FFFFFF);
            Render2D.text(ctx, info, 14 + nw + 11, 11.5f, GRAY, 0.85f);
        }

        if (h.coords.value) {
            String c = String.format("XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            float cw = Render2D.width(c, 0.9f) + 14;
            float y = mc.getWindow().getScaledHeight() - 23;
            Render2D.fill(ctx, 6, y, cw, 17, 8.5f, 0xD00B0B10);
            Render2D.text(ctx, c, 13, y + 4.5f, 0xFFE8E8F0, 0.9f);
        }
        ctx.draw();
    }
}
