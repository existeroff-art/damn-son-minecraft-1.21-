package dev.lumina.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int lumina$getItemUseCooldown();

    @Accessor("itemUseCooldown")
    void lumina$setItemUseCooldown(int value);
}
