package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;
import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    public final String description;
    public BooleanSupplier visible = () -> true;
    public float anim;

    protected Setting(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public abstract JsonElement save();

    public abstract void load(JsonElement e);

    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, String description, boolean def) {
            super(name, description);
            this.value = def;
            this.anim = def ? 1f : 0f;
        }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e.isJsonPrimitive()) value = e.getAsBoolean();
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max, step;
        public float shown = -1f;

        public Num(String name, String description, double def, double min, double max, double step) {
            super(name, description);
            this.min = min;
            this.max = max;
            this.step = step;
            set(def);
        }

        public void set(double v) {
            v = Math.round(v / step) * step;
            v = Math.max(min, Math.min(max, v));
            value = Math.round(v * 10000.0) / 10000.0;
        }

        public float fraction() {
            return (float) ((value - min) / (max - min));
        }

        public String text() {
            int dec = step >= 1 ? 0 : (step >= 0.1 ? 1 : 2);
            return String.format(Locale.ROOT, "%." + dec + "f", value);
        }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e.isJsonPrimitive()) set(e.getAsDouble());
        }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;

        /** The first mode is the default. */
        public Mode(String name, String description, String... modes) {
            super(name, description);
            this.modes = modes;
        }

        public String get() { return modes[index]; }

        public boolean is(String m) { return modes[index].equalsIgnoreCase(m); }

        public void cycle(int dir) {
            index = (index + dir + modes.length) % modes.length;
        }

        @Override public JsonElement save() { return new JsonPrimitive(get()); }

        @Override public void load(JsonElement e) {
            if (!e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(s)) index = i;
        }
    }
}
