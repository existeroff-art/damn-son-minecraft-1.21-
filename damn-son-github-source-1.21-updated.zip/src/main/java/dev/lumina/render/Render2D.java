package dev.lumina.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/** Anti-aliased rounded rectangles, outlines, glows and scaled text on top of DrawContext. */
public final class Render2D {
    public static ShaderProgram program;

    private Render2D() {}

    // ---------- colors ----------
    public static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    public static int mulAlpha(int argb, float f) {
        int a = (int) (((argb >>> 24) & 255) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int rr = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int gg = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bb = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    // ---------- shapes ----------
    public static void rect(DrawContext ctx, float x, float y, float w, float h, float r,
                            int tl, int tr, int br, int bl, float soft, float outline) {
        if (program == null || w <= 0 || h <= 0) return;
        ctx.draw(); // flush queued text/fills so ordering stays correct

        float pad = Math.max(1.5f, soft * 2f + 1.5f);
        r = Math.min(r, Math.min(w, h) * 0.5f);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(() -> program);
        if (program.getUniform("Rect") != null) program.getUniform("Rect").set(x, y, w, h);
        if (program.getUniform("Params") != null) program.getUniform("Params").set(r, soft, outline, 0f);

        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        float x0 = x - pad, y0 = y - pad, x1 = x + w + pad, y1 = y + h + pad;
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        b.vertex(m, x0, y0, 0f).color(tl);
        b.vertex(m, x0, y1, 0f).color(bl);
        b.vertex(m, x1, y1, 0f).color(br);
        b.vertex(m, x1, y0, 0f).color(tr);
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    public static void fill(DrawContext c, float x, float y, float w, float h, float r, int col) {
        rect(c, x, y, w, h, r, col, col, col, col, 0f, 0f);
    }

    public static void hgrad(DrawContext c, float x, float y, float w, float h, float r, int left, int right) {
        rect(c, x, y, w, h, r, left, right, right, left, 0f, 0f);
    }

    public static void vgrad(DrawContext c, float x, float y, float w, float h, float r, int top, int bottom) {
        rect(c, x, y, w, h, r, top, top, bottom, bottom, 0f, 0f);
    }

    public static void outline(DrawContext c, float x, float y, float w, float h, float r, int col, float thick) {
        rect(c, x, y, w, h, r, col, col, col, col, 0f, thick);
    }

    public static void glow(DrawContext c, float x, float y, float w, float h, float r, int col, float soft) {
        rect(c, x, y, w, h, r, col, col, col, col, soft, 0f);
    }

    public static void circle(DrawContext c, float cx, float cy, float rad, int col) {
        fill(c, cx - rad, cy - rad, rad * 2, rad * 2, rad, col);
    }

    // ---------- text ----------
    public static void text(DrawContext ctx, String s, float x, float y, int color, float scale) {
        if (s == null || s.isEmpty() || ((color >>> 24) & 255) < 8) return;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(scale, scale, 1f);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, s, 0, 0, color, false);
        ms.pop();
    }

    public static void textCentered(DrawContext ctx, String s, float cx, float y, int color, float scale) {
        text(ctx, s, cx - width(s, scale) / 2f, y, color, scale);
    }

    public static float width(String s, float scale) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s) * scale;
    }

    public static String fit(String s, float scale, float maxWidth) {
        return MinecraftClient.getInstance().textRenderer.trimToWidth(s, Math.max(1, (int) (maxWidth / scale)));
    }
}
