package dev.lumina.util;

public final class Anim {
    private Anim() {}

    /** Frame-rate independent exponential approach. */
    public static float approach(float cur, float target, float speed, float dt) {
        float d = target - cur;
        if (Math.abs(d) < 0.0005f) return target;
        return cur + d * (1f - (float) Math.exp(-speed * dt));
    }

    public static float easeOut(float t) {
        float u = 1f - Math.max(0f, Math.min(1f, t));
        return 1f - u * u * u;
    }

    public static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
