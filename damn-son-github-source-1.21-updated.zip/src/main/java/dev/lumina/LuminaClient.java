package dev.lumina;

import dev.lumina.gui.ClickGui;
import dev.lumina.hud.Hud;
import dev.lumina.module.Mod;
import dev.lumina.module.ModuleManager;
import dev.lumina.module.util.Bypass;
import dev.lumina.render.Render2D;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.common.BrandCustomPayload;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LuminaClient implements ClientModInitializer {
    public static final String ID = "lumina";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    public static ModuleManager modules;
    public static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load(modules);

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lumina.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.lumina"));

        CoreShaderRegistrationCallback.EVENT.register(ctx ->
                ctx.register(Identifier.of(ID, "rounded"), VertexFormats.POSITION_COLOR, p -> Render2D.program = p));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.save(modules));

        // ── Bypass: spoof brand on every server join ──────────────────────────
        // Fabric sends "fabric" as the client brand automatically; when Bypass is
        // enabled we immediately send "vanilla" right after, overriding it.
        // Servers that fingerprint clients by brand will see a vanilla client.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            Bypass bp = modules.bypass;
            if (bp == null || !bp.enabled) return;

            if (bp.spoofBrand.value) {
                try {
                    ClientPlayNetworking.send(new BrandCustomPayload("vanilla"));
                    LOGGER.info("[Bypass] Brand spoofed → vanilla");
                } catch (Throwable t) {
                    LOGGER.warn("[Bypass] Brand spoof failed: {}", t.getMessage());
                }
            }

            // HideChannels: Fabric registers its own networking channels via
            // minecraft:register right after JOIN.  We can't easily cancel that
            // packet from here (it's sent by Fabric's own initializers before
            // our listener fires), but we log the attempt so the user knows.
            // A full implementation would require a mixin on
            // ClientPlayNetworkHandler#sendPacket — left as a TODO.
            if (bp.hideChannels.value) {
                LOGGER.info("[Bypass] HideChannels active (brand spoofed; channel packet suppression is TODO)");
            }
        });

        LOGGER.info("Lumina loaded");
    }

    private void tick(MinecraftClient mc) {
        while (guiKey.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
        }
        if (mc.player == null || mc.world == null) return;

        long window = mc.getWindow().getHandle();
        for (Mod m : modules.all) {
            if (m.key > 0) {
                boolean down = InputUtil.isKeyPressed(window, m.key);
                if (down && !m.keyDown && mc.currentScreen == null && m.toggleable) m.toggle();
                m.keyDown = down;
            }
            if (m.enabled) {
                try {
                    m.onTick();
                } catch (Throwable t) {
                    LOGGER.error("Module {} crashed in tick, disabling", m.name, t);
                    m.enabled = false;
                }
            }
        }
    }
}
