package dev.lumina.module;

public enum Category {
    COMBAT("Combat", true),
    MOVEMENT("Movement", true),
    RENDER("Render", true),
    PLAYER("Player", true),
    UTIL("Util", false);

    public final String label;
    public final boolean main;

    Category(String label, boolean main) {
        this.label = label;
        this.main = main;
    }
}
