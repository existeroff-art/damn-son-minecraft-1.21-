package dev.lumina.module.player;

import dev.lumina.mixin.MinecraftClientAccessor;
import dev.lumina.module.*;
import dev.lumina.setting.Setting;

public class FastPlace extends Mod {
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between uses", 0, 0, 4, 1));

    public FastPlace() {
        super("FastPlace", "Removes the right-click delay", Category.PLAYER);
    }

    @Override
    public void onTick() {
        MinecraftClientAccessor acc = (MinecraftClientAccessor) mc;
        int max = (int) delay.value;
        if (acc.lumina$getItemUseCooldown() > max) acc.lumina$setItemUseCooldown(max);
    }
}
