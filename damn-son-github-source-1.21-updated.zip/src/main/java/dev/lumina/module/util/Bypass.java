package dev.lumina.module.util;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;

/**
 * Bypass — reduces server-side detection.
 *
 * What it actually does when enabled:
 *   - SpoofBrand : re-sends the Minecraft brand packet as "vanilla" right
 *                  after you connect, overriding Fabric's "fabric" brand.
 *                  This hides the fact that you are running a Fabric client
 *                  from vanilla-brand checks (e.g. Grim, most anti-cheats,
 *                  and server-side brand logging plugins).
 *
 *   - HideChannels: attempts to suppress the fabric:registry/sync channel
 *                   registration packet that tells a server which Fabric
 *                   networking channels this client supports — a secondary
 *                   fingerprint used by some detection plugins.
 *                   (Implemented in LuminaClient via a packet send hook.)
 *
 * The logic runs in LuminaClient (ClientPlayConnectionEvents.JOIN).
 * Modules settings are never touched; this module only manages these two flags.
 */
public class Bypass extends Mod {
    public final Setting.Bool spoofBrand    = add(new Setting.Bool("Spoof Brand",    "Send 'vanilla' brand instead of 'fabric'", true));
    public final Setting.Bool hideChannels  = add(new Setting.Bool("Hide Channels",  "Suppress Fabric channel registration",     true));

    public Bypass() {
        super("Bypass", "Prevents server detection of your client", Category.UTIL);
        // Not toggleable in the usual sense — it has to be on before you join.
        // But we allow toggling so users can turn it on in-game and reconnect.
    }
}
