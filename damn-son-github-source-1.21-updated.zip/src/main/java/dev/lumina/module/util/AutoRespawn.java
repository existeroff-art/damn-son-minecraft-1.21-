package dev.lumina.module.util;

import dev.lumina.module.*;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Mod {
    public AutoRespawn() {
        super("AutoRespawn", "Respawns instantly", Category.UTIL);
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) mc.player.requestRespawn();
    }
}
