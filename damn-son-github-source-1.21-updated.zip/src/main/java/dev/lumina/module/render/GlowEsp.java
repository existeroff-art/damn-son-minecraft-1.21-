package dev.lumina.module.render;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class GlowEsp extends Mod {
    private final Setting.Bool players = add(new Setting.Bool("Players", "Highlight players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Highlight hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Highlight animals", false));

    public GlowEsp() {
        super("ESP", "Outlines entities through walls", Category.RENDER);
    }

    @Override public String suffix() { return "Glow"; }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity le) {
                boolean want = Targets.valid(le, players.value, mobs.value, animals.value);
                if (le.isGlowing() != want) le.setGlowing(want);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity le && le.isGlowing()) le.setGlowing(false);
        }
    }
}
