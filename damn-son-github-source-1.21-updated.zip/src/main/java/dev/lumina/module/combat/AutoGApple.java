package dev.lumina.module.combat;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoGApple extends Mod {
    private final Setting.Num health = add(new Setting.Num("Health", "Eat at or below", 10, 1, 20, 1));
    private int prev = -1, eatTicks, cooldown;

    public AutoGApple() {
        super("AutoGApple", "Eats a golden apple when low", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (prev >= 0) {
            eatTicks++;
            mc.options.useKey.setPressed(true);
            if (eatTicks > 4 && !mc.player.isUsingItem()) finish();
            return;
        }
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;
        if (mc.player.getHealth() > health.value) return;

        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) {
                prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                eatTicks = 0;
                return;
            }
        }
    }

    private void finish() {
        mc.options.useKey.setPressed(false);
        if (mc.player != null && prev >= 0) mc.player.getInventory().selectedSlot = prev;
        prev = -1;
        cooldown = 40;
    }

    @Override public void onDisable() { if (prev >= 0) finish(); }
}
