package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Mod {
    private final Setting.Num range     = add(new Setting.Num("Range",       "Max target distance",          4.0,  1.0,  8.0, 0.1));
    private final Setting.Num speed     = add(new Setting.Num("Speed",       "Rotation speed (deg/tick)",    3.0,  0.5, 15.0, 0.5));
    private final Setting.Num fov       = add(new Setting.Num("FOV",         "Max angle to snap onto",       90.0, 10.0,180.0, 5.0));
    private final Setting.Bool players  = add(new Setting.Bool("Players",    "Target players",               true));
    private final Setting.Bool mobs     = add(new Setting.Bool("Mobs",       "Target hostile mobs",          true));
    private final Setting.Bool animals  = add(new Setting.Bool("Animals",    "Target passive animals",       false));
    private final Setting.Bool weapOnly = add(new Setting.Bool("Weapon Only","Only when holding a weapon",   true));

    public AimAssist() {
        super("AimAssist", "Smoothly rotates toward nearest entity", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (weapOnly.value && !holdingWeapon()) return;

        LivingEntity target = findTarget();
        if (target == null) return;

        Vec3d eye  = mc.player.getEyePos();
        Vec3d tpos = target.getBoundingBox().getCenter();
        Vec3d diff = tpos.subtract(eye);

        double h = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw   = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, h));

        float curYaw   = mc.player.getYaw();
        float curPitch = mc.player.getPitch();

        float dYaw   = MathHelper.wrapDegrees(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        float step = (float) speed.value;
        mc.player.setYaw(curYaw + MathHelper.clamp(dYaw, -step, step));
        mc.player.setPitch(MathHelper.clamp(curPitch + MathHelper.clamp(dPitch, -step, step), -90f, 90f));
    }

    private LivingEntity findTarget() {
        Vec3d eye     = mc.player.getEyePos();
        double maxR   = range.value;
        float  maxFov = (float) fov.value;

        LivingEntity best = null;
        float bestAngle = maxFov;

        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(maxR + 1),
                le -> Targets.valid(le, players.value, mobs.value, animals.value))) {

            if (Targets.distance(e) > maxR) continue;

            Vec3d diff  = e.getBoundingBox().getCenter().subtract(eye);
            double dist2d = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
            float tYaw   = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
            float tPitch = (float) -Math.toDegrees(Math.atan2(diff.y, dist2d));

            float dYaw   = Math.abs(MathHelper.wrapDegrees(tYaw - mc.player.getYaw()));
            float dPitch = Math.abs(tPitch - mc.player.getPitch());
            float angle  = (float) Math.sqrt(dYaw * dYaw + dPitch * dPitch);

            if (angle < bestAngle) {
                bestAngle = angle;
                best = e;
            }
        }
        return best;
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem
            || item instanceof AxeItem
            || item instanceof TridentItem
            || item instanceof BowItem
            || item instanceof CrossbowItem
            || item instanceof MaceItem;
    }
}
