package dev.lumina.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Targets() {}

    public static boolean valid(LivingEntity e, boolean players, boolean mobs, boolean animals) {
        if (e == mc.player || !e.isAlive()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity pe) return players && !pe.isSpectator();
        if (e instanceof Monster) return mobs;
        if (e instanceof AnimalEntity) return animals;
        return false;
    }

    /** Distance from the player's eyes to the closest point of the entity hitbox. */
    public static double distance(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    public static boolean critOk(boolean onlyCrits, boolean smart) {
        if (!onlyCrits) return true;
        ClientPlayerEntity p = mc.player;
        boolean crit = p.fallDistance > 0f && !p.isOnGround() && !p.isClimbing()
                && !p.isTouchingWater() && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS);
        if (crit) return true;
        return smart && p.isOnGround();
    }
}
