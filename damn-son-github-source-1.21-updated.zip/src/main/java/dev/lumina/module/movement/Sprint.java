package dev.lumina.module.movement;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;

public class Sprint extends Mod {
    private final Setting.Bool omni = add(new Setting.Bool("Omni", "Sprint in every direction", false));

    public Sprint() {
        super("Sprint", "Always sprinting", Category.MOVEMENT);
    }

    @Override public String suffix() { return omni.value ? "Omni" : ""; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        boolean moving = omni.value
                ? (p.input.movementForward != 0 || p.input.movementSideways != 0)
                : p.input.movementForward > 0;
        if (moving && !p.isSneaking() && !p.horizontalCollision && !p.isUsingItem()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
