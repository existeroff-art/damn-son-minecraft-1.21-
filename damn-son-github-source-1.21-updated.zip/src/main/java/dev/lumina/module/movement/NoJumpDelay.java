package dev.lumina.module.movement;

import dev.lumina.mixin.LivingEntityAccessor;
import dev.lumina.module.*;

public class NoJumpDelay extends Mod {
    public NoJumpDelay() {
        super("Jump Cooldown", "Removes the jump delay", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player != null) ((LivingEntityAccessor) mc.player).lumina$setJumpingCooldown(0);
    }
}
