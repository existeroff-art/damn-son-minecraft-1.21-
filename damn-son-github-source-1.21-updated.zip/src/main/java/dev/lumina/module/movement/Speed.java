package dev.lumina.module.movement;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Speed extends Mod {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Movement style", "Strafe", "Hop"));
    private final Setting.Num speed = add(new Setting.Num("Speed", "Multiplier", 1.4, 0.5, 4.0, 0.1));
    private final Setting.Bool ground = add(new Setting.Bool("Ground Only", "Only apply on the ground", false));

    public Speed() {
        super("Speed", "Move faster", Category.MOVEMENT);
    }

    @Override public String suffix() { return mode.get(); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        float f = p.input.movementForward, s = p.input.movementSideways;
        if (f == 0 && s == 0) return;
        if (p.getAbilities().flying || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        boolean onGround = p.isOnGround();
        if (ground.value && !onGround) return;

        double yaw = Math.toRadians(p.getYaw());
        double mx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double mz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len < 1e-4) return;
        mx /= len;
        mz /= len;

        double sp = 0.28 * speed.value;
        Vec3d v = p.getVelocity();
        double vy = v.y;
        if (mode.is("Hop") && onGround) vy = 0.42;
        p.setVelocity(mx * sp, vy, mz * sp);
    }
}
