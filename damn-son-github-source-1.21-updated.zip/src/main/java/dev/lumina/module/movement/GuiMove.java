package dev.lumina.module.movement;

import dev.lumina.module.*;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class GuiMove extends Mod {
    public GuiMove() {
        super("Gui Move", "Walk while inventories are open", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (!(mc.currentScreen instanceof InventoryScreen) && !(mc.currentScreen instanceof GenericContainerScreen)) return;
        GameOptions o = mc.options;
        long w = mc.getWindow().getHandle();
        for (KeyBinding k : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sprintKey}) {
            k.setPressed(InputUtil.isKeyPressed(w, KeyBindingHelper.getBoundKeyOf(k).getCode()));
        }
    }
}
