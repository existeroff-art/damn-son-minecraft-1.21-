#version 150

in vec4 vertexColor;
in vec2 fragPos;

uniform vec4 ColorModulator;
uniform vec4 Rect;    // x, y, w, h  (gui coordinates)
uniform vec4 Params;  // radius, softness, outline thickness, unused

out vec4 fragColor;

float sdRoundBox(vec2 p, vec2 b, float r) {
    vec2 q = abs(p) - b + r;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

void main() {
    vec2 hs = Rect.zw * 0.5;
    vec2 p = fragPos - (Rect.xy + hs);
    float d = sdRoundBox(p, hs, Params.x);
    float aa = max(fwidth(d), 0.0001) * 0.75;
    float alpha;

    if (Params.z > 0.0) {
        float t = Params.z;
        float ring = abs(d + t * 0.5) - t * 0.5;
        alpha = 1.0 - smoothstep(-aa, aa, ring);
    } else if (Params.y > 0.0) {
        float s = Params.y;
        alpha = 1.0 - smoothstep(-s, s, d);
        alpha *= alpha;
    } else {
        alpha = 1.0 - smoothstep(-aa, aa, d);
    }

    vec4 col = vec4(vertexColor.rgb, vertexColor.a * alpha) * ColorModulator;
    if (col.a < 0.003) discard;
    fragColor = col;
}
