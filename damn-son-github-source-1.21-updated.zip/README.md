# Lumina (Fabric 1.21, single-player)

## Build
Requirements: JDK 21 and Gradle 8.8+ (or open the folder in IntelliJ and let it import the Gradle project).

    gradle build

The mod jar is created at `build/libs/lumina-1.0.0.jar`.
Drop it in `.minecraft/mods` together with **Fabric API 0.102.0+1.21** and Fabric Loader 0.16+.

## Use
- **Right Shift** opens the menu (rebindable in Controls -> Lumina).
- Click a module to open its settings, click the switch (or right-click) to toggle it.
- Mode pills: left click = next, right click = previous.
- Keybind row inside each module: click, then press a key (Esc/Backspace clears).
- Accent colors and panel opacity live in Util -> Theme.
- Config is stored in `.minecraft/config/lumina.json`.
- The frosted-glass backdrop uses vanilla's menu blur: Options -> Video Settings -> Menu Background Blur.
